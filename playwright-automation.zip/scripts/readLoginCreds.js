const xlsx = require('xlsx');
const path = require('path');

// Path to the Excel file
const filePath = path.resolve(__dirname, '../tests/data/Login Creds Data.xlsx');

// Read the Excel file
const workbook = xlsx.readFile(filePath);

// Get the first sheet
const sheetName = workbook.SheetNames[0];
const sheet = workbook.Sheets[sheetName];

// Convert sheet to JSON
const data = xlsx.utils.sheet_to_json(sheet);

// Log the data
console.log('Login Credentials Data:', data);
