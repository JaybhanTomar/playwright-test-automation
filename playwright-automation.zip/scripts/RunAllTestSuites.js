const { runUsersCreationUpdationSuite } = require('./UsersCreationUpdationSuite.js');
const { runVerifyTabsSystemSetupSuite } = require('./VerifyTabsSystemSetupSuite.js');
const { runVerifyTabsHomeSuite } = require('./VerifyTabsHomeSuite.js');
const { runSetupFieldSuite } = require('./SetupFieldSuite.js');
const { runSetupSkillSuite } = require('./SetupSkillSuite.js');
const { runSetupDocumentSuite } = require('./SetupDocumentSuite.js');

/**
 * Master Test Suite Runner
 * Executes all test suites in sequence
 */
async function runAllTestSuites() {
  console.log('🚀 Starting All Test Suites Execution...');
  console.log('='.repeat(80));
  
  const testSuites = [
    { name: 'UsersCreationUpdation', runner: runUsersCreationUpdationSuite },
    { name: 'VerifyTabsSystemSetup', runner: runVerifyTabsSystemSetupSuite },
    { name: 'VerifyTabsHome', runner: runVerifyTabsHomeSuite },
    { name: 'SetupField', runner: runSetupFieldSuite },
    { name: 'SetupSkill', runner: runSetupSkillSuite },
    { name: 'SetupDocument', runner: runSetupDocumentSuite }
  ];
  
  const results = [];
  let totalPassed = 0;
  let totalFailed = 0;
  
  for (let i = 0; i < testSuites.length; i++) {
    const suite = testSuites[i];
    const startTime = Date.now();
    
    try {
      console.log(`\n📋 Running Test Suite ${i + 1}/${testSuites.length}: ${suite.name}`);
      console.log('-'.repeat(60));
      
      await suite.runner();
      
      const duration = Date.now() - startTime;
      results.push({
        name: suite.name,
        status: 'PASSED',
        duration: duration
      });
      totalPassed++;
      
      console.log(`✅ ${suite.name} completed successfully in ${duration}ms`);
      
    } catch (error) {
      const duration = Date.now() - startTime;
      results.push({
        name: suite.name,
        status: 'FAILED',
        duration: duration,
        error: error.message
      });
      totalFailed++;
      
      console.error(`❌ ${suite.name} failed in ${duration}ms: ${error.message}`);
      
      // Continue with next test suite instead of stopping
      console.log('⚠️ Continuing with next test suite...');
    }
  }
  
  // Print final summary
  console.log('\n' + '='.repeat(80));
  console.log('📊 TEST EXECUTION SUMMARY');
  console.log('='.repeat(80));
  
  results.forEach((result, index) => {
    const status = result.status === 'PASSED' ? '✅' : '❌';
    const duration = (result.duration / 1000).toFixed(2);
    console.log(`${status} ${index + 1}. ${result.name} - ${result.status} (${duration}s)`);
    
    if (result.error) {
      console.log(`   Error: ${result.error}`);
    }
  });
  
  console.log('-'.repeat(80));
  console.log(`📈 Total Suites: ${testSuites.length}`);
  console.log(`✅ Passed: ${totalPassed}`);
  console.log(`❌ Failed: ${totalFailed}`);
  console.log(`📊 Success Rate: ${((totalPassed / testSuites.length) * 100).toFixed(1)}%`);
  
  if (totalFailed === 0) {
    console.log('\n🎉 All test suites completed successfully!');
  } else {
    console.log(`\n⚠️ ${totalFailed} test suite(s) failed. Check logs for details.`);
  }
  
  console.log('='.repeat(80));
}

// Execute if run directly
if (require.main === module) {
  runAllTestSuites().catch(error => {
    console.error(`❌ Test execution failed: ${error.message}`);
    process.exit(1);
  });
}

module.exports = { runAllTestSuites };
