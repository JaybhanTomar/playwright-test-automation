const SetupField = require('../tests/SetupField.js');

/**
 * Simple runner for SetupField test
 * Just runs the test directly - no flows, everything under tests/
 */
async function runSetupFieldSuite() {
  try {
    console.log('🚀 Running SetupField Test...');
    console.log('='.repeat(50));

    // Run the test directly
    const test = new SetupField();
    await test.runAllTests();

    console.log('\n🎉 SetupField completed successfully!');

  } catch (error) {
    console.error(`❌ SetupField failed: ${error.message}`);
    console.error(error.stack);
    process.exit(1);
  }
}

// Run the suite
if (require.main === module) {
  runSetupFieldSuite();
}

module.exports = { runSetupFieldSuite };
