const SetupDocument = require('../tests/SetupDocument.js');

/**
 * Simple runner for SetupDocument test
 * Just runs the test directly - no flows, everything under tests/
 */
async function runSetupDocumentSuite() {
  try {
    console.log('🚀 Running SetupDocument Test...');
    console.log('='.repeat(50));

    // Run the test directly
    const test = new SetupDocument();
    await test.runAllTests();

    console.log('\n🎉 SetupDocument completed successfully!');

  } catch (error) {
    console.error(`❌ SetupDocument failed: ${error.message}`);
    console.error(error.stack);
    process.exit(1);
  }
}

// Run the suite
if (require.main === module) {
  runSetupDocumentSuite();
}

module.exports = { runSetupDocumentSuite };
