#!/usr/bin/env node

/**
 * Check Excel Data Script
 * This script checks if your Excel files have been populated with test data
 */

const path = require('path');
const fs = require('fs');

/**
 * Check if Excel files have data
 */
function checkExcelData() {
  console.log('🔍 Checking Excel files for test data...\n');
  
  try {
    const ExcelUtils = require('../tests/utils/ExcelUtils.js');
    
    const filesToCheck = [
      { file: 'Login Creds Data.xlsx', sheet: 'UserLoginData', description: 'User login credentials' },
      { file: 'WorkFlow Test Data.xlsx', sheet: 'UserCreationData', description: 'User creation data' },
      { file: 'Field Test Data.xlsx', sheet: 'Category', description: 'Category data' },
      { file: 'Field Test Data.xlsx', sheet: 'Skill', description: 'Skill data' },
      { file: 'Field Test Data.xlsx', sheet: 'Field', description: 'Field data' },
      { file: 'IVR Test Data.xlsx', sheet: 'IVR Setup', description: 'IVR configuration data' }
    ];
    
    let totalFiles = 0;
    let filesWithData = 0;
    let emptyFiles = [];
    
    for (const { file, sheet, description } of filesToCheck) {
      totalFiles++;
      const filePath = path.join(process.cwd(), 'tests', 'data', file);
      
      if (!fs.existsSync(filePath)) {
        console.log(`❌ ${file} - ${sheet}: File not found`);
        emptyFiles.push(`${file} (${description})`);
        continue;
      }
      
      try {
        const data = ExcelUtils.readExcelData(filePath, sheet);
        
        if (data.length > 0) {
          console.log(`✅ ${file} - ${sheet}: ${data.length} data rows found`);
          filesWithData++;
        } else {
          console.log(`⚠️  ${file} - ${sheet}: No data rows (headers only)`);
          emptyFiles.push(`${file} - ${sheet} (${description})`);
        }
      } catch (error) {
        console.log(`❌ ${file} - ${sheet}: Error reading data - ${error.message}`);
        emptyFiles.push(`${file} - ${sheet} (${description})`);
      }
    }
    
    console.log('\n📊 Summary:');
    console.log(`✅ Files with data: ${filesWithData}/${totalFiles}`);
    
    if (emptyFiles.length > 0) {
      console.log(`⚠️  Files needing data: ${emptyFiles.length}`);
      console.log('\n📝 Files that need to be populated:');
      emptyFiles.forEach(file => console.log(`   • ${file}`));
      
      console.log('\n💡 Next steps:');
      console.log('1. Open the Excel files in Excel, LibreOffice Calc, or Google Sheets');
      console.log('2. Add test data rows below the header row');
      console.log('3. See tests/data/ExcelDataGuide.md for detailed examples');
      console.log('4. Run this check again: npm run check-data');
      
      return false;
    } else {
      console.log('🎉 All Excel files have test data!');
      console.log('✅ You can now run your tests: npm test');
      return true;
    }
    
  } catch (error) {
    console.error(`❌ Error checking Excel data: ${error.message}`);
    console.log('\n💡 Make sure to run "npm run setup-data" first to create Excel template files.');
    return false;
  }
}

/**
 * Show sample data for a specific file
 */
function showSampleData(fileName, sheetName) {
  try {
    const ExcelUtils = require('../tests/utils/ExcelUtils.js');
    const filePath = path.join(process.cwd(), 'tests', 'data', fileName);
    
    if (!fs.existsSync(filePath)) {
      console.log(`❌ File not found: ${fileName}`);
      return;
    }
    
    console.log(`📊 Sample data from ${fileName} - ${sheetName}:`);
    
    const data = ExcelUtils.readExcelData(filePath, sheetName);
    
    if (data.length === 0) {
      console.log('⚠️  No data found (headers only)');
      return;
    }
    
    // Show first few rows
    const rowsToShow = Math.min(3, data.length);
    for (let i = 0; i < rowsToShow; i++) {
      console.log(`   Row ${i + 1}: ${data[i].join(' | ')}`);
    }
    
    if (data.length > rowsToShow) {
      console.log(`   ... and ${data.length - rowsToShow} more rows`);
    }
    
  } catch (error) {
    console.error(`❌ Error reading sample data: ${error.message}`);
  }
}

/**
 * Main execution
 */
function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    // Check all files
    checkExcelData();
  } else if (args.length === 2) {
    // Show sample data for specific file
    const [fileName, sheetName] = args;
    showSampleData(fileName, sheetName);
  } else {
    console.log('Usage:');
    console.log('  node scripts/checkExcelData.js                           # Check all files');
    console.log('  node scripts/checkExcelData.js "Login Creds Data.xlsx" "UserLoginData"  # Show sample data');
  }
}

// Check if XLSX package is installed
function checkDependencies() {
  try {
    require('xlsx');
    return true;
  } catch (error) {
    console.error('❌ XLSX package not found. Please install it:');
    console.error('   npm install xlsx');
    return false;
  }
}

// Main execution
if (require.main === module) {
  if (checkDependencies()) {
    main();
  } else {
    process.exit(1);
  }
}

module.exports = {
  checkExcelData,
  showSampleData
};
