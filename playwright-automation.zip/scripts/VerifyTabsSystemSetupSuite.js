const VerifyTabsSystemSetup = require('../tests/VerifyTabsSystemSetup.js');

/**
 * Simple runner for VerifyTabsSystemSetup test
 * Just runs the test directly - no flows, everything under tests/
 */
async function runVerifyTabsSystemSetupSuite() {
  try {
    console.log('🚀 Running VerifyTabsSystemSetup Test...');
    console.log('='.repeat(50));

    // Run the test directly
    const test = new VerifyTabsSystemSetup();
    await test.runAllTests();

    console.log('\n🎉 VerifyTabsSystemSetup completed successfully!');

  } catch (error) {
    console.error(`❌ VerifyTabsSystemSetup failed: ${error.message}`);
    console.error(error.stack);
    process.exit(1);
  }
}

// Run the suite
if (require.main === module) {
  runVerifyTabsSystemSetupSuite();
}

module.exports = { runVerifyTabsSystemSetupSuite };
