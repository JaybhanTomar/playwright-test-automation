const SetupSkill = require('../tests/SetupSkill.js');

/**
 * Simple runner for SetupSkill test
 * Just runs the test directly - no flows, everything under tests/
 */
async function runSetupSkillSuite() {
  try {
    console.log('🚀 Running SetupSkill Test...');
    console.log('='.repeat(50));

    // Run the test directly
    const test = new SetupSkill();
    await test.runAllTests();

    console.log('\n🎉 SetupSkill completed successfully!');

  } catch (error) {
    console.error(`❌ SetupSkill failed: ${error.message}`);
    console.error(error.stack);
    process.exit(1);
  }
}

// Run the suite
if (require.main === module) {
  runSetupSkillSuite();
}

module.exports = { runSetupSkillSuite };
