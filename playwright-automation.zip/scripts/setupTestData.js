#!/usr/bin/env node

/**
 * Setup Test Data Script
 * This script creates Excel template files for your Playwright tests
 * You need to populate these templates with your actual test data
 */

const path = require('path');
const fs = require('fs');

// Import the Excel file creator
const { createAllExcelFiles, validateExcelFiles } = require('../tests/data/createExcelFiles.js');

/**
 * Main setup function
 */
async function setupTestData() {
  console.log('🚀 Setting up Excel template files for Playwright automation...\n');

  try {
    // Check if data directory exists
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      console.log('📁 Creating data directory...');
      fs.mkdirSync(dataDir, { recursive: true });
      console.log('✅ Data directory created\n');
    }

    // Create Excel template files
    console.log('📊 Creating Excel template files...');
    createAllExcelFiles();

    // Validate created files
    validateExcelFiles();

    // Show usage instructions
    showUsageInstructions();

  } catch (error) {
    console.error(`❌ Error setting up test data: ${error.message}`);
    process.exit(1);
  }
}

/**
 * Show usage instructions
 */
function showUsageInstructions() {
  console.log('\n📚 IMPORTANT: Next Steps to Complete Setup:');
  console.log('');

  console.log('🔥 STEP 1: Populate Excel Files with Your Test Data');
  console.log('   The created Excel files contain HEADERS ONLY.');
  console.log('   You MUST add your test data rows to these files:');
  console.log('');
  console.log('   📄 Login Creds Data.xlsx → Add user login credentials');
  console.log('   📄 WorkFlow Test Data.xlsx → Add user creation data');
  console.log('   📄 Field Test Data.xlsx → Add field setup data');
  console.log('   📄 IVR Test Data.xlsx → Add IVR configuration data');
  console.log('');

  console.log('📖 STEP 2: See Detailed Population Guide');
  console.log('   Open tests/data/ExcelDataGuide.md for detailed examples');
  console.log('   This guide shows exactly what data to add to each sheet');
  console.log('');

  console.log('💻 STEP 3: Use Excel Data in Your Tests');
  console.log('');
  console.log('   Import ExcelUtils in your test:');
  console.log('   const ExcelUtils = require("../utils/ExcelUtils.js");');
  console.log('');
  console.log('   Read data from Excel file:');
  console.log('   const loginData = ExcelUtils.readExcelData("tests/data/Login Creds Data.xlsx", "UserLoginData");');
  console.log('');
  console.log('   Use data in your test:');
  console.log('   for (const [email, password, role] of loginData) {');
  console.log('     await loginPage.login(email, password);');
  console.log('   }');
  console.log('');

  console.log('🎯 Example: Login Test with Excel Data');
  console.log('');
  console.log('   test("Login with Excel data", async ({ page }) => {');
  console.log('     const loginData = LoginPage.getLoginTestDataAsObjects();');
  console.log('     for (const user of loginData) {');
  console.log('       await loginPage.login(user.email, user.password);');
  console.log('     }');
  console.log('   });');
  console.log('');

  console.log('⚠️  REMEMBER: Tests will FAIL until you add data to Excel files!');
  console.log('✅ After populating Excel files, run: npm run test:login');
}

/**
 * Check if XLSX package is installed
 */
function checkDependencies() {
  try {
    require('xlsx');
    return true;
  } catch (error) {
    console.error('❌ XLSX package not found. Please install it:');
    console.error('   npm install xlsx');
    return false;
  }
}

// Main execution
if (require.main === module) {
  if (checkDependencies()) {
    setupTestData();
  } else {
    process.exit(1);
  }
}

module.exports = {
  setupTestData,
  showUsageInstructions
};
