const { chromium } = require('playwright');
const { runLogin } = require('../tests/flows/loginFlow');
//const { runSetupDoc } = require('../tests/flows/setupDocFlow');
const { runVerifyTabsSystemSetup } = require('../tests/flows/verifyTabsSystemSetupFlow');

(async () => {
  const browser = await chromium.launch({ headless: false });
  const page = await browser.newPage();

  try {
    console.log('=== Running Login Flow ===');
    await runLogin(page);
    console.log('=== Login Flow Complete ===');
/*
    console.log('=== Running SetupDoc Flow ===');
    //await runSetupDoc(page);
    console.log('=== SetupDoc Flow Complete ===');
*/
    console.log('=== Running Verify Tabs System Setup Flow ===');
    await runVerifyTabsSystemSetup(page);
    console.log('=== Verify Tabs System Setup Flow Complete ===');

  }
    
  catch (err) {
    console.error('❌ Suite failed:', err);
  }
    
  finally {
    await browser.close();
  }
})();
