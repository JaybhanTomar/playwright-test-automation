const path = require('path');
const BaseURL = require('./tests/utils/BaseURL.js');
const baseUrlUtil = new BaseURL();
const baseURL = baseUrlUtil.getEnvironmentUrl('qc2') || 'https://qc2.devaavaz.biz/';

// playwright.config.js
module.exports = {
  timeout: 180000,            // Increase test timeout to 3 minutes for detailed testing

  globalSetup: require.resolve('./playwright/global-setup.js'),

  // Define projects with different test types
  projects: [
    // Login tests project - for login and basic authentication tests
    {
      name: 'login-tests',
      testMatch: /.*loginTest\.spec\.js/,
      use: {
        baseURL: baseURL, // Uses the URL from BaseURL utility
        headless: false,          // So you can see the UI
        viewport: { width: 1920, height: 1080 }, // Fixed viewport
        javaScriptEnabled: true,  // Ensure JavaScript is enabled
        launchOptions: {
          slowMo: 1000,           // Slow down actions by 1 second
        }
      }
    },

    // Admin setup documentation tests project
    {
      name: 'admin',
      testMatch: /.*SetupDocTest\.spec\.js/,
      use: {
        baseURL: baseURL, // Uses the URL from BaseURL utility
        headless: false,
        viewport: { width: 1920, height: 1080 },
        javaScriptEnabled: true,
        launchOptions: { slowMo: 1000 },
        storageState: path.join(__dirname, 'playwright/.auth/admin.json'),
      }
    }
  ],               // Run tests sequentially
};
