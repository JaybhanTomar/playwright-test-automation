# 🎭 Playwright Test Automation Framework

A comprehensive test automation framework built with Playwright for web application testing, featuring Page Object Model (POM) architecture and Excel-based test data management.

## 🚀 Quick Start

### Prerequisites
- **Node.js** (v16 or higher)
- **npm** or **yarn**
- **Git** (for cloning)

### Installation
```bash
# 1. Clone the repository
git clone https://github.com/yourusername/playwright-test-automation.git
cd playwright-test-automation

# 2. Install dependencies
npm install

# 3. Install Playwright browsers
npx playwright install

# 4. Update test data (see Test Data section below)
```

## 🧪 Available Test Suites

### **SetupDocument Test**
Tests document management functionality with complete workflow.
```bash
node scripts/SetupDocumentSuite.js
```

### **VerifyTabsHome Test**
Verifies home page tabs and navigation functionality.
```bash
node scripts/VerifyTabsHomeSuite.js
```

### **VerifyTabsSystemSetup Test**
Tests System Setup page tabs and sub-elements.
```bash
node scripts/VerifyTabsSystemSetupSuite.js
```

### **User Creation Tests**
Tests user creation and management functionality.
```bash
node scripts/UsersCreationUpdationSuite.js
```

### **Field Setup Tests**
Tests field creation and configuration.
```bash
node scripts/SetupFieldSuite.js
node scripts/SetupSkillSuite.js
```

### **Run All Tests**
Execute all test suites in sequence.
```bash
node scripts/RunAllTestSuites.js
```

## 📊 Test Data Configuration

### **Excel Files Location**
All test data is stored in Excel files under `tests/data/` folder:

- `Login Creds Data.xlsx` - Login credentials
- `Field Test Data.xlsx` - Field and document test data
- `WorkFlow Test Data.xlsx` - Workflow test data
- `IVR Test Data.xlsx` - IVR test data

### **Update Login Credentials**
1. Open `tests/data/Login Creds Data.xlsx`
2. Update the `UserLoginData` sheet with your environment credentials:
   - **email**: Your login email
   - **password**: Your login password
   - **environment**: Target environment (qc2, qc4, qc5, qc7)

### **Environment URLs**
The framework supports multiple environments:
- **qc2**: https://qc2.devaavaz.biz/
- **qc4**: https://qc4.devaavaz.biz/
- **qc5**: https://qc5.devaavaz.biz/
- **qc7**: https://qc7.devaavaz.biz/

## 🏗️ Framework Architecture

### **Page Object Model (POM)**
- All page interactions are encapsulated in POM classes
- Located in `tests/pages/` directory
- High-level business methods for clean test code

### **Test Structure**
```
tests/
├── pages/           # Page Object Models
├── utils/           # Utility classes
├── data/            # Excel test data files
└── *.js             # Test classes

scripts/
└── *Suite.js        # Test suite runners

pageObjects/
└── loginPage.js     # Legacy login page object
```

### **Key Features**
- ✅ **Excel-based test data management**
- ✅ **Multi-environment support**
- ✅ **Comprehensive error handling**
- ✅ **Detailed logging and reporting**
- ✅ **Browser session reuse for faster execution**
- ✅ **TestNG-style test execution**

## 🔧 Configuration

### **Browser Settings**
Tests run with optimized browser settings:
- **Headless**: false (visible browser)
- **Viewport**: 1920x1080
- **Slow motion**: 1000ms for better visibility

### **Timeouts**
- **Test timeout**: 180 seconds
- **Element timeout**: 10 seconds
- **Navigation timeout**: 30 seconds

## 📋 Test Execution Flow

1. **@BeforeClass**: Browser setup and page object initialization
2. **Login**: Automatic login using Excel credentials
3. **@Test**: Execute test methods with proper dependencies
4. **@AfterClass**: Browser cleanup and session management

## 🛠️ Troubleshooting

### **Common Issues**

**Excel file not found:**
```bash
# Ensure Excel files exist in tests/data/ folder
ls tests/data/*.xlsx
```

**Login failures:**
- Verify credentials in `Login Creds Data.xlsx`
- Check environment URL accessibility
- Ensure VPN connection if required

**Element not found:**
- Tests include automatic retries and fallback mechanisms
- Check browser console for JavaScript errors
- Verify page load completion

## 🤝 Contributing

1. Create feature branch: `git checkout -b feature/new-test`
2. Make changes and test thoroughly
3. Commit: `git commit -m "Add new test feature"`
4. Push: `git push origin feature/new-test`
5. Create Pull Request

## 📞 Support

For questions or issues:
1. Check existing test logs for error details
2. Verify test data configuration
3. Review framework documentation
4. Contact the automation team

---

**Happy Testing! 🎭✨**
