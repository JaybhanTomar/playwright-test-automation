/**
 * Excel File Creator
 * This script creates Excel files with basic structure for testing
 * You should populate these Excel files with your actual test data
 */

const XLSX = require('xlsx');
const path = require('path');

/**
 * Create Excel file with multiple sheets
 * @param {string} fileName - Name of the Excel file
 * @param {Object} sheetsData - Object with sheet names as keys and data arrays as values
 */
function createExcelFile(fileName, sheetsData) {
  try {
    console.log(`📊 Creating Excel file: ${fileName}`);
    
    // Create a new workbook
    const workbook = XLSX.utils.book_new();
    
    // Add each sheet to the workbook
    for (const [sheetName, data] of Object.entries(sheetsData)) {
      console.log(`  📋 Adding sheet: ${sheetName} (${data.length - 1} data rows)`);
      
      // Create worksheet from array of arrays
      const worksheet = XLSX.utils.aoa_to_sheet(data);
      
      // Add the worksheet to the workbook
      XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
    }
    
    // Write the file
    const filePath = path.join(__dirname, fileName);
    XLSX.writeFile(workbook, filePath);
    
    console.log(`✅ Successfully created: ${filePath}`);
    return true;
  } catch (error) {
    console.error(`❌ Error creating Excel file ${fileName}: ${error.message}`);
    return false;
  }
}

/**
 * Define Excel file structures with headers only
 */
const excelStructures = {
  'Login Creds Data.xlsx': {
    'UserLoginData': [
      ['email', 'password', 'role']
    ],
    'Agent': [
      ['email', 'password', 'role']
    ]
  },
  'WorkFlow Test Data.xlsx': {
    'UserCreationData': [
      ['firstname', 'lastname', 'role', 'email', 'password', 'timezone', 'extension', 'phonenumber', 'userskill']
    ]
  },
  'Field Test Data.xlsx': {
    'Category': [
      ['Category']
    ],
    'Skill': [
      ['Category', 'Skill']
    ],
    'Field': [
      ['Category', 'Level', 'DisplayName', 'FieldName', 'Type', 'InputType', 'Min', 'Max', 'NoOfLines', 'Options', 'OptionValues', 'AllowOther', 'Tooltip']
    ],
    'LeadStage': [
      ['Category', 'Stage', 'Probability', 'Default']
    ],
    'LeadStatus': [
      ['Category', 'Status', 'Default']
    ],
    'LeadLostReason': [
      ['Category', 'LostReason']
    ],
    'LeadField': [
      ['Category', 'DisplayName', 'FieldName', 'Type', 'InputType', 'Min', 'Max', 'NoOfLines', 'Options', 'OptionValues', 'AllowOther', 'Tooltip']
    ],
    'TicketType': [
      ['Category', 'Type', 'Default']
    ],
    'TicketPriority': [
      ['Category', 'Priority', 'Default', 'FirstResponseWithin', 'firstResponseTime', 'TrailResponseWithin', 'trailResponseTime', 'ResolveWithin', 'resoveTime']
    ],
    'TicketStage': [
      ['Category', 'Stage', 'Default', 'Order', 'IsClosed']
    ],
    'TicketField': [
      ['Category', 'DisplayName', 'FieldName', 'Type', 'InputType', 'Min', 'Max', 'NoOfLines', 'Options', 'OptionValues', 'AllowOther', 'Tooltip']
    ]
  },
  'IVR Test Data.xlsx': {
    'IVR Setup': [
      ['IVRName', 'WelcomeMessage', 'MusicOnHold', 'OfficeHours', 'WorkingDays', 'StartTime', 'EndTime']
    ]
  }
};

/**
 * Create all Excel files needed for testing
 */
function createAllExcelFiles() {
  console.log('🚀 Creating Excel file templates for testing...\n');
  console.log('📝 Note: These files will contain headers only. You need to add your test data.\n');

  let successCount = 0;
  let totalFiles = 0;

  // Create each Excel file with its structure
  for (const [fileName, sheetsData] of Object.entries(excelStructures)) {
    totalFiles++;
    if (createExcelFile(fileName, sheetsData)) {
      successCount++;
    }
    console.log(''); // Empty line
  }

  // Summary
  console.log('📊 Excel File Creation Summary:');
  console.log(`✅ Successfully created: ${successCount}/${totalFiles} files`);

  if (successCount === totalFiles) {
    console.log('🎉 All Excel template files created successfully!');
    console.log('\n📋 Created files:');
    console.log('  • Login Creds Data.xlsx (UserLoginData, Agent sheets)');
    console.log('  • WorkFlow Test Data.xlsx (UserCreationData sheet)');
    console.log('  • Field Test Data.xlsx (11 sheets for various field types)');
    console.log('  • IVR Test Data.xlsx (IVR Setup sheet)');
    console.log('\n📝 IMPORTANT: These files contain headers only!');
    console.log('   You need to add your actual test data rows to these Excel files.');
    console.log('\n💡 Example: Open Login Creds Data.xlsx and add rows like:');
    console.log('   jayadmin@tekege.com | @Tekege321 | Admin');
    console.log('   jayagent@tekege.com | @Tekege321 | Agent');
  } else {
    console.log('⚠️ Some files failed to create. Check the error messages above.');
  }
}

/**
 * Validate created Excel files
 */
function validateExcelFiles() {
  console.log('\n🔍 Validating created Excel files...');
  
  const ExcelUtils = require('../tests/utils/ExcelUtils.js');
  const filesToValidate = [
    { file: 'Login Creds Data.xlsx', sheet: 'UserLoginData' },
    { file: 'WorkFlow Test Data.xlsx', sheet: 'UserCreationData' },
    { file: 'Field Test Data.xlsx', sheet: 'Category' },
    { file: 'IVR Test Data.xlsx', sheet: 'IVR Setup' }
  ];
  
  let validCount = 0;
  
  for (const { file, sheet } of filesToValidate) {
    const filePath = path.join(__dirname, file);
    if (ExcelUtils.validateExcelFile(filePath, sheet)) {
      console.log(`✅ ${file} - ${sheet} sheet: Valid`);
      validCount++;
    } else {
      console.log(`❌ ${file} - ${sheet} sheet: Invalid`);
    }
  }
  
  console.log(`\n📊 Validation Summary: ${validCount}/${filesToValidate.length} files valid`);
}

// Main execution
if (require.main === module) {
  createAllExcelFiles();
  validateExcelFiles();
}

module.exports = {
  createExcelFile,
  createAllExcelFiles,
  validateExcelFiles
};
