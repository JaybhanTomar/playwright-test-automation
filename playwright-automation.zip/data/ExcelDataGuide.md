# Excel Data Population Guide

This guide shows you exactly how to populate your Excel files with test data for your Playwright automation tests.

## 🚀 Quick Start

1. **Create Excel Templates:**
   ```bash
   npm run setup-data
   ```

2. **Open Excel Files and Add Your Data:**
   - Open the created Excel files in Microsoft Excel, LibreOffice Calc, or Google Sheets
   - Add your test data rows below the header row
   - Save the files

3. **Run Tests:**
   ```bash
   npm run test:login
   ```

## 📊 Excel Files to Populate

### 1. **Login Creds Data.xlsx**

#### **UserLoginData Sheet:**
```
| email                    | password   | role            |
|--------------------------|------------|-----------------|
| jayadmin@tekege.com      | @Tekege321 | Admin           |
| jayagent@tekege.com      | @Tekege321 | Agent           |
| jaysupervisor@tekege.com | @Tekege321 | Supervisor      |
| jaymanager@tekege.com    | @Tekege321 | Manager         |
| jayuser@tekege.com       | @Tekege321 | User            |
| jayteamlead@tekege.com   | @Tekege321 | Team Lead       |
| jayqualityanalyst@tekege.com | @Tekege321 | Quality Analyst |
| jaytrainer@tekege.com    | @Tekege321 | Trainer         |
```

#### **Agent Sheet:**
```
| email               | password   | role  |
|---------------------|------------|-------|
| jayagent@tekege.com | @Tekege321 | Agent |
| agent2@tekege.com   | @Tekege321 | Agent |
| agent3@tekege.com   | @Tekege321 | Agent |
```

### 2. **WorkFlow Test Data.xlsx**

#### **UserCreationData Sheet:**
```
| firstname | lastname   | role       | email                | password   | timezone          | extension | phonenumber | userskill        |
|-----------|------------|------------|----------------------|------------|-------------------|-----------|-------------|------------------|
| John      | Admin      | Admin      | john.admin@tekege.com| @Tekege123 | America/New_York  | 1001      | 1234567890  | Administration   |
| Jane      | Agent      | Agent      | jane.agent@tekege.com| @Tekege123 | America/Chicago   | 1002      | 1234567891  | Customer Service |
| Mike      | Supervisor | Supervisor | mike.super@tekege.com| @Tekege123 | America/Denver    | 1003      | 1234567892  | Team Management  |
| Sarah     | Manager    | Manager    | sarah.mgr@tekege.com | @Tekege123 | America/Los_Angeles| 1004     | 1234567893  | Project Management|
```

### 3. **Field Test Data.xlsx**

#### **Category Sheet:**
```
| Category         |
|------------------|
| General          |
| Technical        |
| Customer Service |
| Sales            |
| Support          |
```

#### **Skill Sheet:**
```
| Category         | Skill            |
|------------------|------------------|
| General          | Communication    |
| Technical        | Programming      |
| Customer Service | Problem Solving  |
| Sales            | Negotiation      |
| Support          | Troubleshooting  |
```

#### **Field Sheet:**
```
| Category | Level | DisplayName  | FieldName     | Type          | InputType | Min | Max | NoOfLines | Options | OptionValues        | AllowOther | Tooltip                    |
|----------|-------|--------------|---------------|---------------|-----------|-----|-----|-----------|---------|---------------------|------------|----------------------------|
| General  | Basic | Customer Name| customer_name | Text          | Text      | 2   | 50  | 1         |         |                     | No         | Enter customer full name   |
| General  | Basic | Contact Type | contact_type  | Single Select | Dropdown  |     |     |           | 3       | Phone,Email,Chat    | Yes        | Select contact method      |
| Technical| Advanced| Issue Category| issue_category| Multi Select  | Checkbox  |     |     |           | 5       | Hardware,Software,Network,Security,Other | Yes | Select all applicable categories |
```

#### **LeadStage Sheet:**
```
| Category | Stage       | Probability | Default |
|----------|-------------|-------------|---------|
| Sales    | New         | 10          | Yes     |
| Sales    | Qualified   | 25          | No      |
| Sales    | Proposal    | 50          | No      |
| Sales    | Negotiation | 75          | No      |
| Sales    | Closed Won  | 100         | No      |
| Sales    | Closed Lost | 0           | No      |
```

#### **LeadStatus Sheet:**
```
| Category | Status      | Default |
|----------|-------------|---------|
| General  | Open        | Yes     |
| General  | In Progress | No      |
| General  | On Hold     | No      |
| General  | Completed   | No      |
| General  | Cancelled   | No      |
```

#### **LeadLostReason Sheet:**
```
| Category | LostReason                    |
|----------|-------------------------------|
| Sales    | Price too high                |
| Sales    | Competitor chosen             |
| Sales    | No budget                     |
| Sales    | Timeline mismatch             |
| Sales    | Feature requirements not met  |
```

#### **LeadField Sheet:**
```
| Category        | DisplayName   | FieldName     | Type          | InputType | Min | Max | NoOfLines | Options | OptionValues                              | AllowOther | Tooltip                    |
|-----------------|---------------|---------------|---------------|-----------|-----|-----|-----------|---------|-------------------------------------------|------------|----------------------------|
| Lead Information| Lead Source   | lead_source   | Single Select | Dropdown  |     |     |           | 5       | Website,Phone,Email,Referral,Advertisement| Yes        | How did the lead find us?  |
| Lead Information| Interest Level| interest_level| Single Select | Radio     |     |     |           | 4       | High,Medium,Low,Unknown                   | No         | Lead interest level        |
| Lead Information| Budget Range  | budget_range  | Text          | Text      | 1   | 20  | 1         |         |                                           | No         | Expected budget range      |
```

#### **TicketType Sheet:**
```
| Category         | Type            | Default |
|------------------|-----------------|---------|
| General          | Bug Report      | Yes     |
| General          | Feature Request | No      |
| Technical        | System Issue    | No      |
| Customer Service | Complaint       | No      |
| Customer Service | Inquiry         | No      |
```

#### **TicketPriority Sheet:**
```
| Category | Priority | Default | FirstResponseWithin | firstResponseTime | TrailResponseWithin | trailResponseTime | ResolveWithin | resoveTime |
|----------|----------|---------|---------------------|-------------------|---------------------|-------------------|---------------|------------|
| General  | Critical | No      | Hours               | 1                 | Hours               | 2                 | Hours         | 4          |
| General  | High     | No      | Hours               | 2                 | Hours               | 4                 | Days          | 1          |
| General  | Medium   | Yes     | Hours               | 4                 | Hours               | 8                 | Days          | 3          |
| General  | Low      | No      | Days                | 1                 | Days                | 2                 | Days          | 7          |
```

#### **TicketStage Sheet:**
```
| Category | Stage       | Default | Order | IsClosed |
|----------|-------------|---------|-------|----------|
| General  | New         | Yes     | 1     | No       |
| General  | Assigned    | No      | 2     | No       |
| General  | In Progress | No      | 3     | No       |
| General  | Pending     | No      | 4     | No       |
| General  | Resolved    | No      | 5     | Yes      |
| General  | Closed      | No      | 6     | Yes      |
```

#### **TicketField Sheet:**
```
| Category          | DisplayName      | FieldName        | Type          | InputType | Min | Max | NoOfLines | Options | OptionValues                                                    | AllowOther | Tooltip                        |
|-------------------|------------------|------------------|---------------|-----------|-----|-----|-----------|---------|----------------------------------------------------------------|------------|--------------------------------|
| Ticket Information| Issue Category   | issue_category   | Single Select | Dropdown  |     |     |           | 6       | Hardware,Software,Network,Security,Performance,Other          | Yes        | Select the category of the issue|
| Customer Details  | Affected Systems | affected_systems | Multi Select  | Checkbox  |     |     |           | 8       | CRM,ERP,Email,Database,Website,Mobile App,Payment System,Reporting | Yes    | Select all affected systems    |
| Resolution        | Resolution Notes | resolution_notes | Text          | Textarea  | 10  | 500 | 5         |         |                                                                | No         | Detailed resolution notes      |
```

### 4. **IVR Test Data.xlsx**

#### **IVR Setup Sheet:**
```
| IVRName     | WelcomeMessage           | MusicOnHold    | OfficeHours | WorkingDays    | StartTime | EndTime  |
|-------------|--------------------------|----------------|-------------|----------------|-----------|----------|
| Main IVR    | Welcome to our company   | Classical Music| Yes         | Monday-Friday  | 09:00:00  | 17:00:00 |
| Support IVR | Technical support line   | Jazz Music     | Yes         | Monday-Saturday| 08:00:00  | 20:00:00 |
| Sales IVR   | Sales department         | Pop Music      | No          | Monday-Sunday  | 00:00:00  | 23:59:59 |
```

## 💡 Tips for Populating Excel Files

### **1. Data Types:**
- **Text:** Any string value
- **Numbers:** Use plain numbers (no formatting)
- **Time:** Use HH:MM:SS format (e.g., 09:00:00)
- **Boolean:** Use "Yes"/"No" or "True"/"False"

### **2. Option Values:**
- **Single values:** Just the value (e.g., "Admin")
- **Multiple values:** Comma-separated (e.g., "Phone,Email,Chat")
- **No spaces after commas** unless the space is part of the value

### **3. Empty Cells:**
- Leave cells empty if no value is needed
- Don't use "NULL" or "N/A" - just leave blank

### **4. Special Characters:**
- Avoid special characters in field names (use underscore instead of spaces)
- Use proper email format for email fields
- Use proper phone number format for phone fields

## 🔍 Validation

After populating your Excel files, you can validate them:

```bash
# This will check if your Excel files are properly formatted
node -e "
const ExcelUtils = require('./tests/utils/ExcelUtils.js');
console.log('Validating Login Data:', ExcelUtils.validateExcelFile('data/Login Creds Data.xlsx', 'UserLoginData'));
console.log('Validating Field Data:', ExcelUtils.validateExcelFile('data/Field Test Data.xlsx', 'Category'));
"
```

## 🚨 Common Issues

### **Issue: "Excel file not found"**
**Solution:** Run `npm run setup-data` first to create the template files.

### **Issue: "Sheet not found"**
**Solution:** Make sure sheet names match exactly (case-sensitive).

### **Issue: "No data found"**
**Solution:** Make sure you added data rows below the header row.

### **Issue: "Invalid data format"**
**Solution:** Check that your data matches the expected format for each column.

## ✅ Ready to Test

Once you've populated your Excel files with data, you can run your tests:

```bash
# Run specific tests
npm run test:login
npm run test:category
npm run test:field

# Run all tests
npm test
```

Your tests will now read data directly from your Excel files! 🎉
