const { chromium } = require('playwright');
const AdminSideBar = require('./utils/AdminSideBar.js');
const SystemSetupPage = require('./pages/SystemSetupPage.js');
const { LoginPage } = require('./pages/LoginPage.js');

/**
 * SetupSkill Test Class
 * Direct equivalent to your Java TestNG class
 * 
 * Structure:
 * - @BeforeClass -> setup()
 * - @Test(priority = 1) -> Click_On_SystemSetup()
 * - @Test(priority = 2, dependsOnMethods = "Click_On_SystemSetup") -> VerifyClickOnLibraryButton()
 * - @Test(priority = 3, dependsOnMethods = "VerifyClickOnLibraryButton") -> VerifyClickOnSkillsButton()
 * - @Test(priority = 4, dependsOnMethods = "VerifyClickOnSkillsButton", dataProvider = "skillData") -> Create_Skills()
 */
class SetupSkill {
  constructor() {
    this.driver = null; // equivalent to your static WebDriver driver
    this.Bar = null;    // equivalent to your AdminSideBar Bar
    this.Sys = null;    // equivalent to your SystemSetupElement_POM Sys
    this.loginPage = null;
  }

  /**
   * @BeforeClass equivalent
   * Setup method - Initialize all page objects
   */
  async setup() {
    console.log('🔧 @BeforeClass: Setting up SetupSkill test class...');
    
    // Initialize browser (equivalent to DriverUtils.getDriver())
    const browser = await chromium.launch({ 
      headless: false,
      args: ['--start-maximized']
    });
    
    const context = await browser.newContext({
      viewport: null
    });
    
    this.driver = await context.newPage();
    
    // Initialize page objects (equivalent to your @BeforeClass)
    this.Bar = new AdminSideBar(this.driver);           // AdminSideBar Bar
    this.Sys = new SystemSetupPage(this.driver);        // SystemSetupElement_POM Sys  
    this.loginPage = new LoginPage(this.driver);
    
    console.log('✅ @BeforeClass completed: All page objects initialized');
    return browser; // Return for cleanup
  }

  /**
   * Login prerequisite (run before tests)
   */
  async performLogin() {
    console.log('🔐 Performing login...');
    await this.loginPage.performLogin();
    console.log('✅ Login completed');
  }

  /**
   * @Test(priority = 1)
   * Click_On_SystemSetup() - Exact match to your Java method
   */
  async Click_On_SystemSetup() {
    console.log('🖱️ @Test(priority = 1): Click_On_SystemSetup()');
    
    await this.Bar.clickSystemSetup();
    
    console.log('✅ Test 1 completed: System Setup clicked');
  }

  /**
   * @Test(priority = 2, dependsOnMethods = "Click_On_SystemSetup")
   * VerifyClickOnLibraryButton() - Exact match to your Java method
   */
  async VerifyClickOnLibraryButton() {
    console.log('📚 @Test(priority = 2, dependsOnMethods = "Click_On_SystemSetup"): VerifyClickOnLibraryButton()');
    
    await this.Sys.clickOnLibraryButton();
    
    console.log('✅ Test 2 completed: Library Button clicked and verified');
  }

  /**
   * @Test(priority = 3, dependsOnMethods = "VerifyClickOnLibraryButton")
   * VerifyClickOnSkillsButton() - Exact match to your Java method
   */
  async VerifyClickOnSkillsButton() {
    console.log('🎯 @Test(priority = 3, dependsOnMethods = "VerifyClickOnLibraryButton"): VerifyClickOnSkillsButton()');
    
    await this.Sys.clickOnSkillsButton();
    
    console.log('✅ Test 3 completed: Skills Button clicked and verified');
  }

  /**
   * @Test(priority = 4, dependsOnMethods = "VerifyClickOnSkillsButton", dataProvider = "skillData")
   * Create_Skills() - Exact match to your Java method
   * ONE CALL - POM DOES EVERYTHING!
   */
  async Create_Skills() {
    console.log('🎯 @Test(priority = 4, dependsOnMethods = "VerifyClickOnSkillsButton", dataProvider = "skillData"): Create_Skills()');
    
    // ONE CALL - POM handles everything (Excel, skill creation, navigation, reporting)
    await this.Sys.createSkillsFromExcel();
    
    console.log('✅ Test 4 completed: Skill creation finished');
  }

  /**
   * Run all tests in TestNG order
   */
  async runAllTests() {
    let browser;
    
    try {
      console.log('🚀 Starting SetupSkill test execution...');
      console.log('='.repeat(60));

      // @BeforeClass
      browser = await this.setup();
      
      // Login prerequisite
      await this.performLogin();
      
      console.log('\n=== TestNG Test Execution ===');
      
      // @Test(priority = 1)
      await this.Click_On_SystemSetup();
      
      // @Test(priority = 2, dependsOnMethods = "Click_On_SystemSetup")
      await this.VerifyClickOnLibraryButton();
      
      // @Test(priority = 3, dependsOnMethods = "VerifyClickOnLibraryButton")
      await this.VerifyClickOnSkillsButton();
      
      // @Test(priority = 4, dependsOnMethods = "VerifyClickOnSkillsButton", dataProvider = "skillData")
      await this.Create_Skills();
      
      console.log('\n🎉 All tests completed successfully!');
      
    } catch (error) {
      console.error(`❌ Test execution failed: ${error.message}`);
      throw error;
    } finally {
      if (browser) {
        console.log('🔒 Closing browser...');
        await browser.close();
        console.log('🔒 Browser closed');
      }
    }
  }
}

// Export for direct execution
module.exports = SetupSkill;

// Direct execution support
if (require.main === module) {
  const test = new SetupSkill();
  test.runAllTests().catch(console.error);
}
