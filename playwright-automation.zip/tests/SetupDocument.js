const { chromium } = require('playwright');
const DocumentsPage = require('./pages/DocumentsPage.js');
const { LoginPage } = require('./pages/LoginPage.js');

class SetupDocument {
  constructor() {
    this.driver = null;
    this.Doc = null;    // DocumentsPage handles ALL document functionality
    this.loginPage = null;
  }

  // @BeforeClass equivalent - setup method
  async setup() {
    console.log('🔧 @BeforeClass: Setting up SetupDocument test class...');
    
    // Launch browser with optimized settings
    const browser = await chromium.launch({
      headless: false,
      args: ['--start-maximized', '--disable-web-security', '--disable-features=VizDisplayCompositor']
    });
    
    const context = await browser.newContext({
      viewport: null,
      ignoreHTTPSErrors: true
    });
    
    this.driver = await context.newPage();

    // Initialize page objects
    this.Doc = new DocumentsPage(this.driver);
    this.loginPage = new LoginPage(this.driver);
    
    console.log('✅ @BeforeClass completed: All page objects initialized');
    return browser;
  }

  // Login prerequisite
  async performLogin() {
    console.log('🔐 Performing login...');
    await this.loginPage.performLogin();
    console.log('✅ Login completed');
  }

  /**
   * @Test(priority = 1)
   * Complete Document Setup Test - Single POM method call
   */
  async Complete_Document_Setup() {
    console.log('📄 @Test(priority = 1): Complete_Document_Setup()');

    // Single method call to DocumentsPage POM handles ALL functionality
    await this.Doc.performCompleteDocumentSetup();

    console.log('✅ Test 1 completed: Complete document setup finished');
  }

  /**
   * Run all tests in TestNG order
   */
  async runAllTests() {
    let browser;

    try {
      console.log('🚀 Starting SetupDocument test execution...');
      console.log('='.repeat(60));

      // @BeforeClass - Setup browser and page objects
      browser = await this.setup();

      // Login prerequisite
      await this.performLogin();

      console.log('\n=== TestNG Test Execution ===');

      // @Test(priority = 1) - Complete Document Setup
      await this.Complete_Document_Setup();

      console.log('\n🎉 All tests completed successfully!');

    } catch (error) {
      console.error(`❌ Test execution failed: ${error.message}`);
      throw error;
    } finally {
      // @AfterClass - Cleanup
      if (browser) {
        console.log('🔒 Closing browser...');
        await browser.close();
        console.log('🔒 Browser closed');
      }
    }
  }
}

module.exports = SetupDocument;
