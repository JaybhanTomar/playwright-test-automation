const { chromium } = require('playwright');
const AdminSideBar = require('./utils/AdminSideBar.js');
const SystemSetupPage = require('./pages/SystemSetupPage.js');
const { LoginPage } = require('./pages/LoginPage.js');

/**
 * VerifyTabsSystemSetup Test Class
 * Direct equivalent to your Java TestNG class
 * 
 * Structure:
 * - @BeforeClass -> setup()
 * - @Test(priority = 1) -> Click_On_SystemSetup()
 * - @Test(priority = 2, dependsOnMethods = "Click_On_SystemSetup") -> VerifyUsers()
 * - @Test(priority = 3, dependsOnMethods = "VerifyUsers") -> VerifyChannels()
 * - @Test(priority = 4, dependsOnMethods = "VerifyChannels") -> VerifyManageAccount()
 * - @Test(priority = 5, dependsOnMethods = "VerifyManageAccount") -> VerifyLibrary()
 * - @Test(priority = 6, dependsOnMethods = "VerifyLibrary") -> VerifyWorkflows()
 */
class VerifyTabsSystemSetup {
  constructor() {
    this.driver = null; // equivalent to your static WebDriver driver
    this.Bar = null;    // equivalent to your AdminSideBar Bar
    this.Sys = null;    // equivalent to your SystemSetupElement_POM Sys
    this.loginPage = null;
  }

  /**
   * @BeforeClass equivalent
   * Setup method - Initialize all page objects
   */
  async setup() {
    console.log('🔧 @BeforeClass: Setting up VerifyTabsSystemSetup test class...');
    
    // Initialize browser (equivalent to DriverUtils.getDriver())
    const browser = await chromium.launch({ 
      headless: false,
      args: ['--start-maximized']
    });
    
    const context = await browser.newContext({
      viewport: null
    });
    
    this.driver = await context.newPage();
    
    // Initialize page objects (equivalent to your @BeforeClass)
    this.Bar = new AdminSideBar(this.driver);           // AdminSideBar Bar
    this.Sys = new SystemSetupPage(this.driver);        // SystemSetupElement_POM Sys  
    this.loginPage = new LoginPage(this.driver);
    
    console.log('✅ @BeforeClass completed: All page objects initialized');
    return browser; // Return for cleanup
  }

  /**
   * Login prerequisite (run before tests)
   */
  async performLogin() {
    console.log('🔐 Performing login...');
    await this.loginPage.performLogin();
    console.log('✅ Login completed');
  }

  /**
   * @Test(priority = 1)
   * Click_On_SystemSetup() - Exact match to your Java method
   */
  async Click_On_SystemSetup() {
    console.log('🖱️ @Test(priority = 1): Click_On_SystemSetup()');
    
    await this.Bar.clickSystemSetup();
    
    console.log('✅ Test 1 completed: System Setup clicked');
  }

  /**
   * @Test(priority = 2, dependsOnMethods = "Click_On_SystemSetup")
   * VerifyUsers() - Exact match to your Java method
   */
  async VerifyUsers() {
    console.log('👥 @Test(priority = 2, dependsOnMethods = "Click_On_SystemSetup"): VerifyUsers()');
    
    // ONE CALL - POM handles everything
    await this.Sys.verifyUsers();
    
    console.log('✅ Test 2 completed: Users verified');
  }

  /**
   * @Test(priority = 3, dependsOnMethods = "VerifyUsers")
   * VerifyChannels() - Exact match to your Java method
   */
  async VerifyChannels() {
    console.log('📡 @Test(priority = 3, dependsOnMethods = "VerifyUsers"): VerifyChannels()');
    
    // ONE CALL - POM handles everything
    await this.Sys.verifyChannels();
    
    console.log('✅ Test 3 completed: Channels verified');
  }

  /**
   * @Test(priority = 4, dependsOnMethods = "VerifyChannels")
   * VerifyManageAccount() - Exact match to your Java method
   */
  async VerifyManageAccount() {
    console.log('⚙️ @Test(priority = 4, dependsOnMethods = "VerifyChannels"): VerifyManageAccount()');
    
    // ONE CALL - POM handles everything
    await this.Sys.verifyManageAccount();
    
    console.log('✅ Test 4 completed: Manage Account verified');
  }

  /**
   * @Test(priority = 5, dependsOnMethods = "VerifyManageAccount")
   * VerifyLibrary() - Exact match to your Java method
   */
  async VerifyLibrary() {
    console.log('📚 @Test(priority = 5, dependsOnMethods = "VerifyManageAccount"): VerifyLibrary()');
    
    // ONE CALL - POM handles everything
    await this.Sys.verifyLibrary();
    
    console.log('✅ Test 5 completed: Library verified');
  }

  /**
   * @Test(priority = 6, dependsOnMethods = "VerifyLibrary")
   * VerifyWorkflows() - Exact match to your Java method
   */
  async VerifyWorkflows() {
    console.log('🔄 @Test(priority = 6, dependsOnMethods = "VerifyLibrary"): VerifyWorkflows()');
    
    // ONE CALL - POM handles everything
    await this.Sys.verifyWorkflows();
    
    console.log('✅ Test 6 completed: Workflows verified');
  }

  /**
   * Run all tests in TestNG order
   */
  async runAllTests() {
    let browser;
    
    try {
      console.log('🚀 Starting VerifyTabsSystemSetup test execution...');
      console.log('='.repeat(60));

      // @BeforeClass
      browser = await this.setup();
      
      // Login prerequisite
      await this.performLogin();
      
      console.log('\n=== TestNG Test Execution ===');
      
      // @Test(priority = 1)
      await this.Click_On_SystemSetup();
      
      // @Test(priority = 2, dependsOnMethods = "Click_On_SystemSetup")
      await this.VerifyUsers();
      
      // @Test(priority = 3, dependsOnMethods = "VerifyUsers")
      await this.VerifyChannels();
      
      // @Test(priority = 4, dependsOnMethods = "VerifyChannels")
      await this.VerifyManageAccount();
      
      // @Test(priority = 5, dependsOnMethods = "VerifyManageAccount")
      await this.VerifyLibrary();
      
      // @Test(priority = 6, dependsOnMethods = "VerifyLibrary")
      await this.VerifyWorkflows();
      
      console.log('\n🎉 All tests completed successfully!');
      
    } catch (error) {
      console.error(`❌ Test execution failed: ${error.message}`);
      throw error;
    } finally {
      if (browser) {
        console.log('🔒 Closing browser...');
        await browser.close();
        console.log('🔒 Browser closed');
      }
    }
  }
}

// Export for direct execution
module.exports = VerifyTabsSystemSetup;

// Direct execution support
if (require.main === module) {
  const test = new VerifyTabsSystemSetup();
  test.runAllTests().catch(console.error);
}
