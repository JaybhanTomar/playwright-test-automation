/**
 * ErrorUtil utility class for capturing and handling page error banners and alerts
 * Converted from Java Selenium to Playwright JavaScript
 */
class ErrorUtil {
  /**
   * Constructor to initialize page
   * @param {import('@playwright/test').Page} page - Playwright page object
   */
  constructor(page) {
    this.page = page;
    this.timeoutMs = 2000; // 2 seconds timeout (equivalent to TIMEOUT_SEC)
    
    // Known error locators (converted from your Java ERROR_LOCATORS)
    this.errorLocators = [
      '#pageMessages',
      'div.alert.animated.flipInX.alert-warning',
      "//*[contains(text(),'Oops!') or contains(text(),'unexpected error')]",
      // Additional common error selectors
      '.alert-danger',
      '.alert-error',
      '.error-message',
      '.error-banner',
      '[role="alert"]',
      '.notification.is-danger',
      '.toast-error'
    ];
  }

  /**
   * Quickly scans banners for common error messages
   * If any found, throws an error
   * Converted from your Java captureErrorIfPresent() method
   */
  async captureErrorIfPresent() {
    try {
      console.log('🔍 Scanning for error messages...');
      
      for (const locator of this.errorLocators) {
        try {
          // Use short timeout for quick scanning (equivalent to temporary implicit wait)
          const elements = await this.page.locator(locator).all();
          
          for (const element of elements) {
            // Check if element is visible and has content
            const isVisible = await element.isVisible();
            if (!isVisible) continue;
            
            const text = await element.textContent();
            const trimmedText = text?.trim().toLowerCase() || '';
            
            if (trimmedText && (trimmedText.includes('error') || trimmedText.includes('oops'))) {
              const errorMessage = `Captured error banner: "${text?.trim()}"`;
              console.error(`❌ ${errorMessage}`);
              throw new Error(errorMessage);
            }
          }
        } catch (error) {
          // If it's our error message, re-throw it
          if (error.message.includes('Captured error banner:')) {
            throw error;
          }
          // Otherwise, swallow the error and continue checking other locators
          // (equivalent to catch (Exception ignored) in Java)
        }
      }
      
      console.log('✅ No error messages found');
    } catch (error) {
      // If it's our captured error, re-throw it
      if (error.message.includes('Captured error banner:')) {
        throw error;
      }
      // Otherwise, log and continue
      console.log('ℹ️ Error scanning completed with some locator failures (normal)');
    }
  }

  /**
   * Enhanced error capture with more detailed information
   * @param {boolean} throwOnError - Whether to throw error or just log (default: true)
   * @returns {Object|null} Error details object or null if no errors
   */
  async captureErrorWithDetails(throwOnError = true) {
    try {
      console.log('🔍 Performing detailed error scan...');
      
      const errorDetails = {
        found: false,
        errors: [],
        timestamp: new Date().toISOString(),
        url: this.page.url()
      };
      
      for (const locator of this.errorLocators) {
        try {
          const elements = await this.page.locator(locator).all();
          
          for (let i = 0; i < elements.length; i++) {
            const element = elements[i];
            const isVisible = await element.isVisible();
            
            if (!isVisible) continue;
            
            const text = await element.textContent();
            const trimmedText = text?.trim() || '';
            
            if (trimmedText) {
              const lowerText = trimmedText.toLowerCase();
              
              // Check for various error indicators
              const isError = lowerText.includes('error') || 
                             lowerText.includes('oops') || 
                             lowerText.includes('failed') || 
                             lowerText.includes('exception') || 
                             lowerText.includes('invalid') ||
                             lowerText.includes('not found') ||
                             lowerText.includes('unauthorized');
              
              if (isError) {
                const errorInfo = {
                  locator: locator,
                  text: trimmedText,
                  elementIndex: i,
                  boundingBox: await element.boundingBox().catch(() => null)
                };
                
                errorDetails.errors.push(errorInfo);
                errorDetails.found = true;
                
                console.error(`❌ Error found with locator '${locator}': "${trimmedText}"`);
              }
            }
          }
        } catch (error) {
          // Continue with other locators
          continue;
        }
      }
      
      if (errorDetails.found) {
        const errorMessage = `Found ${errorDetails.errors.length} error(s) on page: ${errorDetails.errors.map(e => e.text).join('; ')}`;
        
        if (throwOnError) {
          throw new Error(errorMessage);
        } else {
          console.error(`❌ ${errorMessage}`);
          return errorDetails;
        }
      } else {
        console.log('✅ No error messages found in detailed scan');
        return null;
      }
    } catch (error) {
      if (throwOnError && error.message.includes('error(s) on page:')) {
        throw error;
      }
      console.log('ℹ️ Detailed error scanning completed');
      return null;
    }
  }

  /**
   * Capture screenshot when error is found
   * @param {string} screenshotPath - Path to save screenshot
   */
  async captureErrorWithScreenshot(screenshotPath = null) {
    try {
      await this.captureErrorIfPresent();
    } catch (error) {
      // Error found, take screenshot
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const defaultPath = screenshotPath || `test-results/error-${timestamp}.png`;
      
      await this.page.screenshot({ 
        path: defaultPath, 
        fullPage: true 
      });
      
      console.log(`📸 Error screenshot saved: ${defaultPath}`);
      
      // Re-throw the error with screenshot info
      throw new Error(`${error.message} | Screenshot: ${defaultPath}`);
    }
  }

  /**
   * Wait for errors to appear and capture them
   * Useful for operations that might show delayed error messages
   * @param {number} waitTimeMs - Time to wait for errors (default: 3000ms)
   */
  async waitAndCaptureErrors(waitTimeMs = 3000) {
    try {
      console.log(`⏳ Waiting ${waitTimeMs}ms for potential error messages...`);
      
      // Wait for the specified time
      await this.page.waitForTimeout(waitTimeMs);
      
      // Then check for errors
      await this.captureErrorIfPresent();
      
      console.log('✅ No errors appeared during wait period');
    } catch (error) {
      console.error(`❌ Error appeared during wait period: ${error.message}`);
      throw error;
    }
  }

  /**
   * Check for specific error message
   * @param {string} expectedError - Expected error message to look for
   * @param {boolean} shouldExist - Whether the error should exist (default: true)
   */
  async checkForSpecificError(expectedError, shouldExist = true) {
    try {
      console.log(`🔍 Checking for specific error: "${expectedError}"`);
      
      let errorFound = false;
      
      for (const locator of this.errorLocators) {
        try {
          const elements = await this.page.locator(locator).all();
          
          for (const element of elements) {
            const isVisible = await element.isVisible();
            if (!isVisible) continue;
            
            const text = await element.textContent();
            const trimmedText = text?.trim() || '';
            
            if (trimmedText.toLowerCase().includes(expectedError.toLowerCase())) {
              errorFound = true;
              console.log(`✅ Found expected error: "${trimmedText}"`);
              break;
            }
          }
          
          if (errorFound) break;
        } catch (error) {
          continue;
        }
      }
      
      if (shouldExist && !errorFound) {
        throw new Error(`Expected error message "${expectedError}" was not found`);
      } else if (!shouldExist && errorFound) {
        throw new Error(`Unexpected error message "${expectedError}" was found`);
      }
      
      console.log(`✅ Error check completed successfully`);
      return errorFound;
    } catch (error) {
      console.error(`❌ Error during specific error check: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get all visible error messages without throwing
   * @returns {Array} Array of error message strings
   */
  async getAllErrorMessages() {
    const errorMessages = [];
    
    try {
      console.log('📋 Collecting all error messages...');
      
      for (const locator of this.errorLocators) {
        try {
          const elements = await this.page.locator(locator).all();
          
          for (const element of elements) {
            const isVisible = await element.isVisible();
            if (!isVisible) continue;
            
            const text = await element.textContent();
            const trimmedText = text?.trim() || '';
            
            if (trimmedText) {
              const lowerText = trimmedText.toLowerCase();
              
              if (lowerText.includes('error') || 
                  lowerText.includes('oops') || 
                  lowerText.includes('failed') || 
                  lowerText.includes('exception')) {
                errorMessages.push(trimmedText);
              }
            }
          }
        } catch (error) {
          continue;
        }
      }
      
      console.log(`📋 Found ${errorMessages.length} error messages`);
      return errorMessages;
    } catch (error) {
      console.error(`❌ Error collecting error messages: ${error.message}`);
      return errorMessages;
    }
  }
}

// Static method for quick error checking (equivalent to your Java static method)
ErrorUtil.captureErrorIfPresent = async function(page) {
  const errorUtil = new ErrorUtil(page);
  return await errorUtil.captureErrorIfPresent();
};

module.exports = ErrorUtil;
