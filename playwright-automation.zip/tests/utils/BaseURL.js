/**
 * BaseURL - Utility class for managing environment URLs
 * Provides centralized URL configuration for different test environments
 */
class BaseURL {
  constructor() {
    this.environments = {
      qc2: 'https://qc2.devaavaz.biz/',
      qc4: 'https://qc4.devaavaz.biz/',
      qc5: 'https://qc5.devaavaz.biz/',
      qc7: 'https://qc7.devaavaz.biz/'
    };
  }

  /**
   * Get the URL for a specific environment
   * @param {string} environment - The environment key (e.g., 'qc2', 'qc4', 'qc5', 'qc7')
   * @returns {string} The URL for the specified environment
   */
  getEnvironmentUrl(environment) {
    const url = this.environments[environment.toLowerCase()];
    if (!url) {
      console.warn(`⚠️ Environment '${environment}' not found. Available environments: ${Object.keys(this.environments).join(', ')}`);
      return this.environments.qc2; // Default to qc2
    }
    return url;
  }

  /**
   * Get all available environments
   * @returns {Object} Object containing all environment URLs
   */
  getAllEnvironments() {
    return { ...this.environments };
  }

  /**
   * Add or update an environment URL
   * @param {string} environment - The environment key
   * @param {string} url - The URL for the environment
   */
  setEnvironmentUrl(environment, url) {
    this.environments[environment.toLowerCase()] = url;
  }
}

module.exports = BaseURL;
