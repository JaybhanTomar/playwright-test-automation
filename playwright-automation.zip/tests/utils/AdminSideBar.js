const { expect } = require('@playwright/test');

/**
 * AdminSideBar utility class for handling admin sidebar navigation
 * Converted from Java Selenium to Playwright JavaScript
 */
class AdminSideBar {
  /**
   * Constructor to initialize page
   * @param {import('@playwright/test').Page} page - Playwright page object
   */
  constructor(page) {
    this.page = page;
    
    // Define locators - using first() to handle multiple matches
    this.systemSetupLocator = page.locator("//a[normalize-space()='System Setup']").first();
    this.backButtonLocator = page.locator("//i[@class='fa fa-arrow-circle-left fa-lg']");
  }

  /**
   * Scroll element into view (equivalent to JavascriptExecutor scrollIntoView)
   * @param {import('@playwright/test').Locator} element - Element to scroll into view
   */
  async scrollIntoView(element) {
    try {
      await element.scrollIntoViewIfNeeded();
    } catch (error) {
      // Fallback to JavaScript execution if scrollIntoViewIfNeeded fails
      await this.page.evaluate((el) => {
        el.scrollIntoView({ block: 'center', inline: 'center' });
      }, await element.elementHandle());
    }
  }

  /**
   * Click on System Setup from admin sidebar
   * Converted from your Java clickSystemSetup() method
   */
  async clickSystemSetup() {
    try {
      console.log('🖱️ Clicking on System Setup...');
      
      // Wait for element to be clickable (equivalent to ExpectedConditions.elementToBeClickable)
      await expect(this.systemSetupLocator).toBeVisible({ timeout: 20000 });
      
      // Scroll into view (equivalent to JavascriptExecutor scrollIntoView)
      await this.scrollIntoView(this.systemSetupLocator);
      
      // Click the element
      await this.systemSetupLocator.click();
      
      console.log('✅ Clicked on System Setup successfully');
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in clickSystemSetup: ${error.message}`);
      throw error;
    }
  }

  /**
   * Click on Back Button
   * Converted from your Java clickOnBackButton() method
   */
  async clickOnBackButton() {
    try {
      console.log('🔙 Clicking on Back Button...');
      
      // Wait for element to be clickable (equivalent to ExpectedConditions.elementToBeClickable)
      await expect(this.backButtonLocator).toBeEnabled({ timeout: 20000 });
      
      // Wait for visibility (equivalent to ExpectedConditions.visibilityOf)
      await expect(this.backButtonLocator).toBeVisible({ timeout: 20000 });
      
      // Scroll into view (equivalent to JavascriptExecutor scrollIntoView)
      await this.scrollIntoView(this.backButtonLocator);
      
      // Additional wait for clickability
      await expect(this.backButtonLocator).toBeEnabled({ timeout: 20000 });
      
      // Click the element
      await this.backButtonLocator.click();
      
      // Wait a moment for navigation
      await this.page.waitForTimeout(1000);
      
      console.log('✅ Clicked on Back Button successfully');
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in clickOnBackButton: ${error.message}`);
      throw error;
    }
  }

  /**
   * Alternative back button click with retry mechanism
   * Enhanced version with better error handling
   */
  async clickBackButtonWithRetry(maxRetries = 3) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`🔙 Attempting to click Back Button (attempt ${attempt}/${maxRetries})...`);
        
        await this.clickOnBackButton();
        return true;
      } catch (error) {
        console.log(`⚠️ Back button click attempt ${attempt} failed: ${error.message}`);
        
        if (attempt === maxRetries) {
          console.error(`❌ All ${maxRetries} attempts to click back button failed`);
          throw error;
        }
        
        // Wait before retry
        await this.page.waitForTimeout(1000);
      }
    }
  }

  /**
   * Navigate back using browser back button as fallback
   * Useful when back button element is not available
   */
  async navigateBack() {
    try {
      console.log('🔙 Navigating back using browser back...');
      
      await this.page.goBack();
      await this.page.waitForTimeout(2000);
      
      console.log('✅ Navigated back successfully');
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in navigateBack: ${error.message}`);
      throw error;
    }
  }

  /**
   * Smart back navigation - tries back button first, then browser back
   * Enhanced method that combines both approaches
   */
  async smartBack() {
    try {
      // First try clicking the back button
      await this.clickOnBackButton();
    } catch (error) {
      console.log('ℹ️ Back button not available, using browser back navigation');
      await this.navigateBack();
    }
  }

  /**
   * Wait for System Setup page to load
   * Helper method to ensure System Setup page is ready
   */
  async waitForSystemSetupPage() {
    try {
      console.log('⏳ Waiting for System Setup page to load...');
      
      // Wait for System Setup page indicators
      const systemSetupIndicators = [
        this.page.locator("//label[normalize-space()='System Setup']"),
        this.page.locator("//h1[contains(text(),'System Setup')]"),
        this.page.locator("//div[contains(@class,'system-setup')]")
      ];
      
      // Wait for any of the indicators to be visible
      for (const indicator of systemSetupIndicators) {
        try {
          await expect(indicator).toBeVisible({ timeout: 5000 });
          console.log('✅ System Setup page loaded successfully');
          return true;
        } catch (error) {
          // Continue to next indicator
          continue;
        }
      }
      
      // If no specific indicators found, wait for general page load
      await this.page.waitForLoadState('networkidle', { timeout: 10000 });
      console.log('✅ System Setup page loaded (general)');
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred waiting for System Setup page: ${error.message}`);
      throw error;
    }
  }

  /**
   * Click System Setup and wait for page load
   * Combined method for better reliability
   */
  async clickSystemSetupAndWait() {
    try {
      await this.clickSystemSetup();
      await this.waitForSystemSetupPage();
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in clickSystemSetupAndWait: ${error.message}`);
      throw error;
    }
  }
}

module.exports = AdminSideBar;
