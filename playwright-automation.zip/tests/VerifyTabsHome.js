const { chromium } = require('playwright');
const HomePage_POM = require('./pages/HomePage_POM.js');
const { LoginPage } = require('./pages/LoginPage.js');

/**
 * VerifyTabsHome Test Class
 * Direct equivalent to your Java TestNG class
 * 
 * Structure:
 * - @BeforeClass -> setup()
 * - @Test(priority = 1) -> VerifyCampaigns()
 * - @Test(priority = 2, dependsOnMethods = "VerifyCampaigns") -> VerifyContacts()
 * - @Test(priority = 3, dependsOnMethods = "VerifyContacts") -> VerifyLeads()
 * - @Test(priority = 4, dependsOnMethods = "VerifyLeads") -> VerifyTickets()
 * - @Test(priority = 5, dependsOnMethods = "VerifyTickets") -> VerifyReports()
 */
class VerifyTabsHome {
  constructor() {
    this.driver = null; // equivalent to your static WebDriver driver
    this.homePage = null; // equivalent to your HomePage_POM
    this.loginPage = null;
  }

  /**
   * @BeforeClass equivalent
   * Setup method - Initialize all page objects
   */
  async setup() {
    console.log('🔧 @BeforeClass: Setting up VerifyTabsHome test class...');
    
    // Initialize browser (equivalent to DriverUtils.getDriver())
    const browser = await chromium.launch({ 
      headless: false,
      args: ['--start-maximized']
    });
    
    const context = await browser.newContext({
      viewport: null
    });
    
    this.driver = await context.newPage();
    
    // Initialize page objects (equivalent to your @BeforeClass)
    this.homePage = new HomePage_POM(this.driver);      // HomePage_POM
    this.loginPage = new LoginPage(this.driver);
    
    console.log('✅ @BeforeClass completed: All page objects initialized');
    return browser; // Return for cleanup
  }

  /**
   * Login prerequisite (run before tests)
   */
  async performLogin() {
    console.log('🔐 Performing login...');
    await this.loginPage.performLogin();
    console.log('✅ Login completed');
  }

  /**
   * @Test(priority = 1)
   * VerifyCampaigns() - Exact match to your Java method
   */
  async VerifyCampaigns() {
    console.log('📢 @Test(priority = 1): VerifyCampaigns()');

    // ONE CALL - POM handles everything
    await this.homePage.verifyCampaignsTab();

    console.log('✅ Test 1 completed: Campaigns verified');
  }

  /**
   * @Test(priority = 2, dependsOnMethods = "VerifyCampaigns")
   * VerifyContacts() - Exact match to your Java method
   */
  async VerifyContacts() {
    console.log('👥 @Test(priority = 2, dependsOnMethods = "VerifyCampaigns"): VerifyContacts()');

    // ONE CALL - POM handles everything
    await this.homePage.verifyContactsTab();

    console.log('✅ Test 2 completed: Contacts verified');
  }

  /**
   * @Test(priority = 3, dependsOnMethods = "VerifyContacts")
   * VerifyLeads() - Exact match to your Java method
   */
  async VerifyLeads() {
    console.log('🎯 @Test(priority = 3, dependsOnMethods = "VerifyContacts"): VerifyLeads()');

    // ONE CALL - POM handles everything
    await this.homePage.verifyLeadsTab();

    console.log('✅ Test 3 completed: Leads verified');
  }

  /**
   * @Test(priority = 4, dependsOnMethods = "VerifyLeads")
   * VerifyTickets() - Exact match to your Java method
   */
  async VerifyTickets() {
    console.log('🎫 @Test(priority = 4, dependsOnMethods = "VerifyLeads"): VerifyTickets()');

    // ONE CALL - POM handles everything
    await this.homePage.verifyTicketsTab();

    console.log('✅ Test 4 completed: Tickets verified');
  }

  /**
   * @Test(priority = 5, dependsOnMethods = "VerifyTickets")
   * VerifyReports() - Exact match to your Java method
   */
  async VerifyReports() {
    console.log('📊 @Test(priority = 5, dependsOnMethods = "VerifyTickets"): VerifyReports()');

    // ONE CALL - POM handles everything
    await this.homePage.verifyReportsTab();

    console.log('✅ Test 5 completed: Reports verified');
  }

  /**
   * Run all tests in TestNG order
   */
  async runAllTests() {
    let browser;
    
    try {
      console.log('🚀 Starting VerifyTabsHome test execution...');
      console.log('='.repeat(60));

      // @BeforeClass
      browser = await this.setup();
      
      // Login prerequisite
      await this.performLogin();
      
      console.log('\n=== TestNG Test Execution ===');
      
      // @Test(priority = 1)
      await this.VerifyCampaigns();
      
      // @Test(priority = 2, dependsOnMethods = "VerifyCampaigns")
      await this.VerifyContacts();
      
      // @Test(priority = 3, dependsOnMethods = "VerifyContacts")
      await this.VerifyLeads();
      
      // @Test(priority = 4, dependsOnMethods = "VerifyLeads")
      await this.VerifyTickets();
      
      // @Test(priority = 5, dependsOnMethods = "VerifyTickets")
      await this.VerifyReports();
      
      console.log('\n🎉 All tests completed successfully!');
      
    } catch (error) {
      console.error(`❌ Test execution failed: ${error.message}`);
      throw error;
    } finally {
      if (browser) {
        console.log('🔒 Closing browser...');
        await browser.close();
        console.log('🔒 Browser closed');
      }
    }
  }
}

// Export for direct execution
module.exports = VerifyTabsHome;

// Direct execution support
if (require.main === module) {
  const test = new VerifyTabsHome();
  test.runAllTests().catch(console.error);
}
