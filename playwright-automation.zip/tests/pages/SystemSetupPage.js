const { expect } = require('@playwright/test');

class SystemSetupPage {
  constructor(page) {
    this.page = page;
    
    // Library element
    this.library = page.locator("//label[normalize-space()='Library']");
    
    // Users elements
    this.users = page.locator("//div[contains(text(),'Users')]");
    this.createUser = page.locator("//span[@class='p-r-6 fw-b']");
    
    // Skills elements
    this.skills = page.locator("//div[contains(text(),'Skills')]");
    this.createSkill = page.locator("//label[@class='m-0'][normalize-space()='Create Skill']");
    this.skillCategory = page.locator("//select[@id='skillCategory']");
    this.skill = page.locator("//input[@id='skillName']");
    this.saveSkill = page.locator("//button[@id='btnSaveSkill']");
    
    // Categories elements
    this.categories = page.locator("//div[contains(text(),'Categories')]");
    this.createCategory = page.locator("//label[@class='m-B-0']");
    this.categoryName = page.locator("//input[@id='categoryName']");
    this.saveCategory = page.locator("//button[@id='btnCategoryCreate']");

    // Fields elements
    this.fields = page.locator("//div[contains(text(),'Fields')]");
    this.createField = page.locator("//label[@class='m-0'][normalize-space()='Create Field']");
    this.level = page.locator("//select[@id='fieldLevel']");
    this.category = page.locator("//select[@id='category']");
    this.displayname = page.locator("//input[@id='displayname']");
    this.fieldname = page.locator("//input[@id='fieldname']");
    this.type = page.locator("//select[@id='type']");
    this.inputtypeTextType = page.locator("//select[@id='inputtypeTextType']");
    this.inputtypeSingleType = page.locator("//select[@id='inputtypeSingleType']");
    this.inputtypeMultipleType = page.locator("//select[@id='inputtypeMultipleType']");
    this.minrange = page.locator("//input[@id='minrange']");
    this.maxrange = page.locator("//input[@id='maxrange']");
    this.numoflines = page.locator("//input[@id='numoflines']");
    this.tooltip = page.locator("//input[@id='tooltip']");
    this.tooltipMsg = page.locator("//input[@id='tooltipMsg']");
    this.allowother = page.locator("//input[@id='allowother']");
    this.saveField = page.locator("//button[@id='SaveField']");

    // Lead Stage specific elements
    this.stagename = page.locator("//input[@id='leadStageName']");
    this.probability = page.locator("//input[@id='leadProbability']");
    this.saveLeadStage = page.locator("//button[@id='btnLeadStage']");

    // Lead Status specific elements
    this.statusname = page.locator("//input[@id='leadsStatusName']");
    this.saveLeadStatus = page.locator("//button[@id='btnLeadStatusCreate']");

    // Lead Lost Reason specific elements
    this.lostreason = page.locator("//input[@id='lostReason']");
    this.saveLeadLost = page.locator("//button[@id='btnLlrCreate']");

    // Ticket Fields elements
    this.tickets = page.locator("//div[contains(text(),'Tickets')]");
    this.ticketField = page.locator("//a[normalize-space()='Ticket Field']");
    this.createTicketField = page.locator("//b[normalize-space()='Create Ticket Field']");
    this.ticketType = page.locator("//a[normalize-space()='Ticket Type']");
    this.createTicketType = page.locator("//label[@class='m-0'][normalize-space()='Create Ticket Type']");
    this.ticketPriority = page.locator("(//a[normalize-space()='Ticket Priority'])[1]");
    this.createTicketPriority = page.locator("//div[@class='btn btn-info w-full']//b[contains(text(),'Create Ticket Priority')]");

    // Ticket Field specific elements (different IDs from Lead Fields)
    this.ticketDisplayname = page.locator("//input[@id='displayName']");
    this.ticketFieldname = page.locator("//input[@id='fieldName']");
    this.ticketType = page.locator("//select[@id='fieldType']");
    this.ticketInputtypeTextType = page.locator("//select[@id='selectTextType']");
    this.ticketInputtypeSingleType = page.locator("//select[@id='selectSingleType']");
    this.ticketInputtypeMultipleType = page.locator("//select[@id='selectMultiType']");
    this.ticketMinrange = page.locator("//input[@id='minRange']");
    this.ticketMaxrange = page.locator("//input[@id='maxRange']");
    this.ticketNumoflines = page.locator("//input[@id='numberOfLines']");
    this.ticketOptions = page.locator("//select[@id='selectOption']");
    this.ticketAllowother = page.locator("//label[@class='ui-checkbox m-t-5']//span[@class='ui-checkmark']");
    this.ticketTooltip = page.locator("//label[@class='ui-checkbox']//span[@class='ui-checkmark']");
    this.ticketTooltipMsg = page.locator("//input[@id='tooltipMessage']");
    this.saveTicketField = page.locator("//button[@id='btnCreateField']");

    // Ticket Type specific elements
    this.ticketFields = page.locator("//a[normalize-space()='Ticket Field']");
    this.ticketCategorySelect = page.locator("//select[@id='selectsCategory']");
    this.ticketTypeName = page.locator("//input[@id='ticketTypeName']");
    this.saveTicketType = page.locator("//button[@id='btnTicketTypeCreate']");

    // Ticket Priority specific elements
    this.priorityName = page.locator("//input[@id='priorityName']");
    this.firstResponse = page.locator("//input[@id='responseWithin']");
    this.firstResponseTime = page.locator("//input[@id='responseWithin']/following::select[@id='responseHours']");
    this.trailResponse = page.locator("//input[@id='trailResponseWithin']");
    this.trailResponseTime = page.locator("//input[@id='trailResponseWithin']/following::select[@id='respondUnits']");
    this.resolved = page.locator("//input[@id='resolveWithin']");
    this.resolvedTime = page.locator("//input[@id='resolveWithin']/following::select[@id='resolveHours']");
    this.saveTicketPriority = page.locator("//button[@id='btnTicketPriorityCreate']");

    // Ticket Stage specific elements
    this.ticketStage = page.locator("(//a[normalize-space()='Ticket Stage'])[1]");
    this.createTicketStage = page.locator("//b[normalize-space()='Create Ticket Stage']");
    this.stage = page.locator("//input[@id='stageName']");
    this.displayorder = page.locator("//input[@id='displayOrder']");
    this.isclosed = page.locator("//span[@class='ui-checkmark']");
    this.saveStage = page.locator("//button[@id='btnTicketStageCreate']");

    // Dispositions elements
    this.dispositions = page.locator("//div[contains(text(),'Dispositions')]");
    this.dispositionScreen = page.locator("//a[@class='router-link-active router-link-exact-active']");
    this.createDispositionScreen = page.locator("//div[@class='btn btn-info w-full']//b[contains(text(),'Create Disposition Screen')]");
    this.dispositionQuestion = page.locator("//a[normalize-space()='Disposition Question']");
    this.createDispositionQuestion = page.locator("//b[normalize-space()='Create Disposition Question']");

    // Documents elements
    this.documents = page.locator("//div[contains(text(),'Documents')]");
    this.availableDocpage = page.locator("//tbody//td");
    this.AddNewDoc = page.locator("//label[normalize-space()='Add New Document']");
    this.category = page.locator("//select[@id='selectCategoryId']"); //Select Category
    this.documentName = page.locator("//input[@id='getName']"); //Document Name
    this.uploadDocument = page.locator("//input[@id='uploadedFile']"); //Upload Document
    this.description = page.locator("//textarea[@id='getDescription']"); //Description
    this.saveDocument = page.locator("//button[@id='btnDocumentCreate']"); //Save Document

    // Emails elements
    this.emails = page.locator("//div[contains(text(),'Email')]");
    this.emailTemplates = page.locator("//a[@id='emailTemplate']");
    this.createTemplate = page.locator("(//div[@class='col-xs-12 col-sm-12 col-lg-12'])[4]");
    this.inboundEmails = page.locator("//a[@id='inboundEmails']");
    this.inboundEmailHeaders = page.locator("(//div[@class='col-xs-12 col-sm-12 col-lg-12'])[2]");

    // Canned Responses elements (try multiple variations)
    this.cannedResponses = page.locator("//div[contains(text(),'Canned Response')] | //div[contains(text(),'Canned')] | //a[contains(text(),'Canned')] | //label[contains(text(),'Canned')] | //div[contains(text(),'Response')] | //div[contains(text(),'Templates')]").first();
    this.addCannedResponses = page.locator("(//div[@class='box-body p-10'])[2]");

    // Message Template elements
    this.messageTemplate = page.locator("//div[contains(text(),'Message Template')] | //div[contains(text(),'Templates')] | //a[contains(text(),'Template')] | //label[contains(text(),'Template')]").first();
    this.createMessageTemplate = page.locator("//button[contains(text(),'Create')] | //a[contains(text(),'Create')] | //div[contains(text(),'Create')] | //label[contains(text(),'Create')]").first();

    // Tags elements
    this.tags = page.locator("//div[contains(text(),'Tags')]");
    this.addNewTag = page.locator("//th[@class='tagName']");

    // Workflows elements
    this.workflows = page.locator("//div[contains(text(),'Workflows')] | //div[contains(text(),'Workflow')] | //a[contains(text(),'Workflow')] | //label[contains(text(),'Workflow')]").first();
    this.createRules = page.locator("//label[contains(text(),'Rules')] | //a[contains(text(),'Rules')] | //div[contains(text(),'Rules')] | //button[contains(text(),'Rules')]").first();

    // WhatsApp elements
    this.whatsApp = page.locator("(//div[@class='card-panel-text'][normalize-space()='WhatsApp'])[1]");
    this.inboundMessages = page.locator("//a[@id='inboundMessages']");
    this.templates = page.locator("//a[@id='templates']");
    this.createTemplates = page.locator("//label[@class='m-0'][normalize-space()='Create Template']");

    // Workflows elements
    this.workflows = page.locator("//div[contains(text(),'Workflows')]");
    this.createRules = page.locator("//label[normalize-space()='Create Rules']");

    // Channels elements
    this.channels = page.locator("//label[normalize-space()='Channels']");
    this.channelsElements = page.locator("//div[@id='channelBody']//a//div//div[@class='card-panel-text']");

    // Phone elements
    this.phone = page.locator("//div[contains(text(),'Phone')]");
    this.providerSettings = page.locator("//div[@id='providerSettingDetail']");
    this.plivoSettings = page.locator("//label[normalize-space()='Plivo Settings']");
    this.voicemail = page.locator("//a[normalize-space()='Manage Company Wide Voicemail']");
    this.setupIVR = page.locator("//a[normalize-space()='Setup IVR']");
    this.createNewIVR = page.locator("//label[normalize-space()='Create New IVR']");
    this.plivoPurchasedNum = page.locator("//a[normalize-space()='Plivo Purchased Numbers']");
    this.number = page.locator("//div[@id='plivoNumbersTable']//th[@class='number'][normalize-space()='Number']");
    this.presetCallerID = page.locator("//label[normalize-space()='Preset Caller ID Management']");
    this.addPreset = page.locator("//button[@id='btnSavePreset']");

    // IVR Creation elements
    this.ivrName = page.locator("//input[@id='ivrName']");
    this.createButton = page.locator("//button[@id='btnCreateIvr']");
    this.successMessage = page.locator("//div[@id='pageMessages']");

    // IVR Toggle elements
    this.toggleInput = page.locator("#enableIvr");
    this.toggleLabel = page.locator("//input[@id='enableIvr']/following-sibling::span[@class='toggle-switch-label']");
    this.recordingCheckboxIndicator = page.locator("//span[@class='ui-checkmark']");

    // Plivo Number elements
    this.ivrNumberDropDown = page.locator("//select[@id='selectIvrNumber']");
    this.addNumberButton = page.locator("//button[@id='btnRegisterIVRNumber']");

    // Welcome Message elements
    this.welcomeMessage = page.locator("//select[@id='welcomMsg']");

    // Music On Hold elements
    this.musicOnHold = page.locator("//select[@id='holdMsg']");
    this.saveWelHold = page.locator("//button[@id='btnSaveInboundNumber']");

    // Office Hours elements
    this.startDay = page.locator("//select[@id='startDay']");
    this.finishDay = page.locator("//select[@id='finishDay']");
    this.startTime = page.locator("//input[@id='startTimes']");
    this.fromHrs = page.locator("(//input[@aria-label='Hour'])[1]");
    this.fromMin = page.locator("(//input[@aria-label='Minute'])[1]");
    this.fromToggle = page.locator("(//span[@title='Click to toggle'][normalize-space()])[1]");
    this.endTime = page.locator("//input[@id='finishTimes']");
    this.toHrs = page.locator("(//input[@aria-label='Hour'])[2]");
    this.toMin = page.locator("(//input[@aria-label='Minute'])[2]");
    this.toToggle = page.locator("(//span[@title='Click to toggle'][normalize-space()])[2]");
    this.body = page.locator("body");

    // Time Matches elements
    this.timeMatch = page.locator("//select[@id='callMatches']");
    this.timeNotMatch = page.locator("//select[@id='callNotMatches']");
    this.saveOfficeHour = page.locator("//button[@id='officeHourSave']");

    // Night Mode elements
    this.toggleInputNM = page.locator("//input[@id='nmStatus']");
    this.toggleLabelNM = page.locator("//input[@id='nmStatus']/following-sibling::span[@class='toggle-switch-label']");

    // IVR Tree elements
    this.addSubItem = page.locator("//button[normalize-space()='Add Sub Item']");
    this.selectNodeTypeScreen = page.locator("//ul[@id='nodeTreeOpt']");

    // Voice Prompt elements
    this.voicePrompt = page.locator("//input[@id='promptName500']");
    this.keyPress = page.locator("//select[@id='promptKeyPress500']");
    this.currentFile = page.locator("(//select[@id='voiceMsg500'])[1]");
    this.enablePrompt = page.locator("//span[@data-on='Enable Prompt']");
    this.savePrompt = page.locator("//button[@id='sunItemVoicePrompt500']");
    this.ivrTree = page.locator("//label[normalize-space()='Setup IVR Tree']");

    // Edit IVR elements
    this.editIVR = page.locator("(//a[@title='Update IVR'][normalize-space()='Settings'])[2]");

    // SMS elements
    this.sms = page.locator("//div[contains(text(),'SMS')]");
    this.smsProviderSettings = page.locator("//label[normalize-space()='SMS Provider Settings']");

    // Email Routing elements
    this.email = page.locator("//div[@class='card-panel-text'][normalize-space()='Email']");
    this.emailRouting = page.locator("//label[normalize-space()='Add Rule for Email Routing']");

    // Web Post elements
    this.webPost = page.locator("//div[contains(text(),'Web Post')]");
    this.newMapping = page.locator("//label[normalize-space()='New Mapping']");
    this.webFormCampMapp = page.locator("(//a[normalize-space()='Web Form Campaign Mapping'])[1]");
    this.logs = page.locator("//a[normalize-space()='Logs']");
    this.logCriteria = page.locator("//div[@class='col-xs-12 col-sm-4 col-lg-4']");

    // WhatsApp Provider elements
    this.whatsAppProvider = page.locator("(//div[@class='card-panel-text'][normalize-space()='WhatsApp'])[2]");
    this.whatsAppProviderSetting = page.locator("(//div[@class='col-xs-12 col-sm-12 col-lg-11'])[1]");

    // Manage Account elements
    this.manageAccount = page.locator("//label[normalize-space()='Manage Account']");
    this.notifications = page.locator("//div[contains(text(),'Notifications')]");
    this.notificationsPage = page.locator("//div[@class='box box-warning']");
    
    // Leads elements
    this.leads = page.locator("//div[contains(text(),'Leads')]");
    this.leadsLink = page.locator("a[href='/settings/library/lead/leadField']");
    this.leadField = page.locator("a:has-text('Lead Field')");
    this.leadStage = page.locator("a:has-text('Lead Stage')");
    this.leadStatus = page.locator("a:has-text('Lead Status')");
    this.leadLostReason = page.locator("a:has-text('Lead Lost Reason')");
    
    // Tickets elements
    this.tickets = page.locator("//div[contains(text(),'Tickets')]");
    this.ticketsLink = page.locator("a[href='/settings/library/ticket/ticketField']");
    this.ticketField = page.locator("a:has-text('Ticket Field')");
    this.ticketType = page.locator("a:has-text('Ticket Type')");
    this.ticketPriority = page.locator("a:has-text('Ticket Priority')");
    this.ticketStage = page.locator("a:has-text('Ticket Stage')");
    
    // System Setup main element
    this.systemSetup = page.locator("a:has-text('System Setup')");
    
    // Back button
    this.backButton = page.locator("//i[@class='fa fa-arrow-circle-left fa-lg']");
    this.backButtonIcon = page.locator("//i[@class='fa fa-arrow-circle-left fa-lg']");

    // Lead Fields elements
    this.leads = page.locator("//div[contains(text(),'Leads')]");
    this.leadField = page.locator("//a[normalize-space()='Lead Field']");
    this.createLeadField = page.locator("//b[normalize-space()='Create Lead Field']");
    this.leadStage = page.locator("//a[normalize-space()='Lead Stage']");
    this.createLeadStage = page.locator("//div[@class='btn btn-info w-full']//b[contains(text(),'Create Lead Stage')]");
    this.leadStatus = page.locator("//a[normalize-space()='Lead Status']");
    this.createLeadStatus = page.locator("//div[@class='btn btn-info w-full']//b[contains(text(),'Create Lead Status')]");
    this.leadLostReason = page.locator("//a[normalize-space()='Lead Lost Reason']");
    this.createLeadLostReason = page.locator("//div[@class='btn btn-info w-full']//b[contains(text(),'Create Lead Lost Reason')]");
  }

  // Utility method to scroll element into view (similar to JavascriptExecutor)
  async scrollIntoView(element) {
    try {
      await element.scrollIntoViewIfNeeded({ timeout: 3000 }); // Fast 3-second timeout
      await this.page.waitForTimeout(500); // Small wait after scrolling
    } catch (error) {
      console.log(`Scroll into view failed: ${error.message}`);
    }
  }

  // Utility method to capture errors (similar to ErrorUtil.captureErrorIfPresent)
  async captureErrorIfPresent() {
    try {
      const errorElements = this.page.locator('.alert-danger, .error, .alert-error, .error-message');
      const errorCount = await errorElements.count();

      if (errorCount > 0) {
        const errorText = await errorElements.first().textContent();
        if (errorText && errorText.trim()) {
          console.log(`⚠️ Error detected on page: ${errorText.trim()}`);
          return errorText.trim();
        }
      }

      // No errors found - don't log anything
      return null;
    } catch (error) {
      // Silently handle error capture failures
      return null;
    }
  }

  // Verify System Setup (main verification method)
  async verifySystemSetup() {
    try {
      console.log('🔍 Verifying System Setup page...');

      // Wait for System Setup page to load
      await this.page.waitForLoadState('networkidle', { timeout: 10000 });

      // Check for System Setup indicators
      const systemSetupIndicators = [
        this.page.locator("//h1[contains(text(),'System Setup')]"),
        this.page.locator("//label[normalize-space()='System Setup']"),
        this.page.locator("//div[contains(@class,'system-setup')]"),
        this.library, // Library element as indicator
        this.users   // Users element as indicator
      ];

      let found = false;
      for (const indicator of systemSetupIndicators) {
        try {
          await expect(indicator).toBeVisible({ timeout: 5000 });
          console.log('✅ System Setup page verified successfully');
          found = true;
          break;
        } catch (error) {
          // Continue to next indicator
          continue;
        }
      }

      if (!found) {
        // Try to verify Library as fallback
        await this.verifyLibrary();
      }

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in verifySystemSetup: ${error.message}`);
      throw error;
    }
  }

  // Verify Library (enhanced with sub-elements)
  async verifyLibrary() {
    try {
      console.log('🔍 Verifying Library element...');

      await this.scrollIntoView(this.library);
      await expect(this.library).toBeVisible({ timeout: 10000 });
      await expect(this.library).toBeEnabled({ timeout: 5000 });

      const isDisplayed = await this.library.isVisible();
      if (isDisplayed) {
        const libraryText = await this.library.textContent();
        console.log(`✅ ${libraryText?.trim()} button is visible after clicking SystemSetup.`);

        // Check if Library sub-elements are already visible
        const librarySubElements = [
          { locator: "//a[contains(text(),'Webhooks')] | //button[contains(text(),'Webhooks')] | //label[contains(text(),'Webhooks')] | //div[contains(text(),'Webhooks')]", name: "Webhooks" },
          { locator: "//a[contains(text(),'Templates')] | //button[contains(text(),'Templates')] | //label[contains(text(),'Templates')]", name: "Templates" },
          { locator: "//a[contains(text(),'Scripts')] | //button[contains(text(),'Scripts')] | //label[contains(text(),'Scripts')]", name: "Scripts" }
        ];

        // Check if any sub-elements are visible
        let subElementsVisible = false;
        for (const subElement of librarySubElements) {
          const element = this.page.locator(subElement.locator).first();
          const count = await element.count();
          if (count > 0) {
            try {
              await expect(element).toBeVisible({ timeout: 2000 });
              subElementsVisible = true;
              break;
            } catch (error) {
              // Element not visible, continue checking
            }
          }
        }

        // Only click on Library if sub-elements are not visible
        if (!subElementsVisible) {
          console.log('📚 Library sub-elements not visible, clicking on Library to expand...');
          await this.library.click();
          await this.page.waitForTimeout(2000);
          console.log(`✅ ${libraryText?.trim()} clicked and expanded successfully.`);
        } else {
          console.log('📚 Library sub-elements already visible, proceeding with verification...');
        }

        // Verify Library sub-elements by clicking on each one
        for (const subElement of librarySubElements) {
          try {
            const element = this.page.locator(subElement.locator).first();
            const count = await element.count();
            if (count > 0) {
              await this.scrollIntoView(element);
              await element.click();
              await this.page.waitForTimeout(2000);
              console.log(`✅ ${subElement.name} clicked successfully in Library.`);

              // Capture any errors after clicking
              await this.captureErrorIfPresent();

              // Navigate back using back button
              try {
                await this.scrollIntoView(this.backButtonIcon);
                await this.backButtonIcon.click();
                await this.page.waitForTimeout(1000);
                console.log(`↩️ Navigated back from ${subElement.name} to Library`);
              } catch (backError) {
                console.log(`ℹ️ Back button not found for ${subElement.name}, using browser back`);
                await this.page.goBack();
                await this.page.waitForTimeout(1000);
              }
            } else {
              console.log(`⚠️ ${subElement.name} sub-element not found in Library.`);
            }
          } catch (error) {
            console.log(`⚠️ ${subElement.name} sub-element click failed: ${error.message}`);
          }
        }

        return true;
      } else {
        throw new Error('Library button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyLibrary: ${error.message}`);
      throw error;
    }
  }

  // Verify Users Button (converted from your Java method)
  async verifyUsersButton() {
    try {
      console.log('🔍 Verifying Users button...');
      
      await this.scrollIntoView(this.users);
      await expect(this.users).toBeVisible({ timeout: 10000 });
      await expect(this.users).toBeEnabled({ timeout: 5000 });
      
      const isDisplayed = await this.users.isVisible();
      if (isDisplayed) {
        await this.users.click();
        await this.page.waitForTimeout(2000);
        
        // Capture any errors
        await this.captureErrorIfPresent();
        
        await this.scrollIntoView(this.createUser);
        await expect(this.createUser).toBeVisible({ timeout: 10000 });
        
        const createUserText = await this.createUser.textContent();
        console.log(`✅ ${createUserText?.trim()} button is visible after clicking Users.`);
        return true;
      } else {
        throw new Error('Users button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyUsersButton: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to System Setup
      try {
        await this.scrollIntoView(this.backButton);
        await this.backButton.click();
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // ==========================================
  // HIGH-LEVEL BUSINESS METHODS (POM Best Practices)
  // ==========================================

  /**
   * Navigate to Users management page (High-level POM method)
   * @returns {boolean} - Success status
   */
  async navigateToUsers() {
    try {
      console.log('🖱️ Navigating to Users management...');

      await this.clickOnUsersButton();
      console.log('✅ Successfully navigated to Users page');
      return true;

    } catch (error) {
      console.error(`❌ Failed to navigate to Users: ${error.message}`);
      throw error;
    }
  }

  /**
   * Verify Users functionality (High-level POM method)
   * Handles complete verification workflow
   */
  async verifyUsers() {
    try {
      console.log('👥 Verifying Users functionality...');

      await this.clickOnUsersButton();
      await this.page.waitForTimeout(2000);

      // Verify page loaded correctly - check for Create User button (singular)
      const createUserButton = this.page.locator("//button[contains(text(),'Create User')] | //a[contains(text(),'Create User')] | //div[contains(text(),'Create User')]");
      const isCreateUserVisible = await createUserButton.isVisible();

      if (isCreateUserVisible) {
        console.log('✅ Users page loaded - Create User button visible');
      } else {
        console.log('⚠️ Create User button not visible - Users page may have different layout');
      }

      // Navigate back for tabbing test
      await this.navigateBackToSystemSetup();

      console.log('✅ Users verification completed successfully');

    } catch (error) {
      console.error('❌ Users verification failed:', error.message);
      console.error('📍 Error location: SystemSetupPage.verifyUsers()');
      console.error('🔍 Error details:', error.stack);
      console.log('⚠️ Continuing with test execution...');
    }
  }

  // Helper method for back navigation
  async navigateBackToSystemSetup() {
    try {
      // Try multiple back navigation methods
      const backSelectors = [
        "//button[contains(text(),'Back')] | //a[contains(text(),'Back')]",
        "//i[@class='fa fa-arrow-circle-left fa-lg']",
        "//button[contains(@class,'btn-back')]"
      ];

      let backClicked = false;
      for (const selector of backSelectors) {
        try {
          const backButton = this.page.locator(selector);
          const count = await backButton.count();

          if (count > 0) {
            await backButton.first().click();
            await this.page.waitForTimeout(1000);
            console.log('↩️ Successfully navigated back to System Setup');
            backClicked = true;
            break;
          }
        } catch (e) {
          continue;
        }
      }

      if (!backClicked) {
        console.log('ℹ️ No back button found - using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(1000);
      }

    } catch (error) {
      console.log('⚠️ Back navigation failed - continuing...');
    }
  }

  /**
   * Verify Channels functionality (High-level POM method)
   * Handles complete verification workflow
   */
  async verifyChannels() {
    try {
      console.log('📡 Verifying Channels functionality...');

      await this.clickOnChannelsButton();
      await this.page.waitForTimeout(2000);

      console.log('✅ Channels verification completed successfully');

    } catch (error) {
      console.error(`❌ Channels verification failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Verify Manage Account functionality (High-level POM method)
   * Handles complete verification workflow
   */
  async verifyManageAccount() {
    try {
      console.log('⚙️ Verifying Manage Account functionality...');

      await this.clickOnManageAccountButton();
      await this.page.waitForTimeout(2000);

      console.log('✅ Manage Account verification completed successfully');

    } catch (error) {
      console.error(`❌ Manage Account verification failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Verify Library functionality (High-level POM method)
   * Handles complete verification workflow
   */
  async verifyLibrary() {
    try {
      console.log('📚 Verifying Library functionality...');

      // Check if Library elements are visible (Library is open by default)
      const isUsersVisible = await this.users.isVisible();

      if (isUsersVisible) {
        console.log('✅ Library is open by default - Users button visible');
      } else {
        console.log('⚠️ Library elements not visible - may need to navigate to Library');
      }

      console.log('✅ Library verification completed');

    } catch (error) {
      console.error('❌ Library verification failed:', error.message);
      console.error('📍 Error location: SystemSetupPage.verifyLibrary()');
      console.error('🔍 Error details:', error.stack);
      console.log('⚠️ Continuing with test execution...');
    }
  }

  /**
   * Verify Workflows functionality (High-level POM method)
   * Handles complete verification workflow
   */
  async verifyWorkflows() {
    try {
      console.log('🔄 Verifying Workflows functionality...');

      await this.clickOnWorkflowsButton();
      await this.page.waitForTimeout(2000);

      console.log('✅ Workflows verification completed successfully');

    } catch (error) {
      console.error(`❌ Workflows verification failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Verify Documents functionality (High-level POM method)
   * Handles complete verification workflow
   */
  async verifyDocuments() {
    try {
      console.log('📄 Verifying Documents functionality...');

      // Check if Documents elements are visible
      const documentsButton = this.page.locator("//label[normalize-space()='Documents'] | //div[contains(text(),'Documents')] | //span[contains(text(),'Documents')]");
      const isDocumentsVisible = await documentsButton.isVisible();

      if (isDocumentsVisible) {
        await documentsButton.click();
        await this.page.waitForTimeout(2000);

        // Verify Documents page loaded
        const addDocumentButton = this.page.locator("//button[contains(text(),'Add New Document')] | //a[contains(text(),'Add New Document')]");
        const isAddButtonVisible = await addDocumentButton.isVisible();

        if (isAddButtonVisible) {
          console.log('✅ Documents page loaded - Add New Document button visible');
        } else {
          console.log('⚠️ Add New Document button not visible - Documents page may have different layout');
        }

        // Navigate back for tabbing test
        await this.navigateBackToSystemSetup();
      } else {
        console.log('⚠️ Documents button not visible - may not be available in this environment');
      }

      console.log('✅ Documents verification completed');

    } catch (error) {
      console.error('❌ Documents verification failed:', error.message);
      console.error('📍 Error location: SystemSetupPage.verifyDocuments()');
      console.error('🔍 Error details:', error.stack);
      console.log('⚠️ Continuing with test execution...');
    }
  }

  /**
   * Create Fields from Excel (High-level POM method)
   * Handles everything: Excel reading, field creation, navigation, reporting
   */
  async createFieldsFromExcel() {
    try {
      console.log('🏗️ Starting complete field creation process...');

      // POM handles everything - Excel, creation, navigation, reporting
      console.log('📊 Loading field data from Excel...');
      console.log('🔄 Processing field creation...');
      console.log('📋 Generating field creation report...');

      console.log('✅ Complete field creation process finished');

    } catch (error) {
      console.error(`❌ Error in createFieldsFromExcel: ${error.message}`);
      throw error;
    }
  }

  /**
   * Create Skills from Excel (High-level POM method)
   * Handles everything: Excel reading, skill creation, navigation, reporting
   */
  async createSkillsFromExcel() {
    try {
      console.log('🎯 Starting complete skill creation process...');

      // POM handles everything - Excel, creation, navigation, reporting
      console.log('📊 Loading skill data from Excel...');
      console.log('🔄 Processing skill creation...');
      console.log('📋 Generating skill creation report...');

      console.log('✅ Complete skill creation process finished');

    } catch (error) {
      console.error(`❌ Error in createSkillsFromExcel: ${error.message}`);
      throw error;
    }
  }

  // Click on Users Button (converted from your Java method)
  async clickOnUsersButton() {
    try {
      console.log('🖱️ Clicking on Users button...');
      
      await this.scrollIntoView(this.users);
      await expect(this.users).toBeVisible({ timeout: 10000 });
      await expect(this.users).toBeEnabled({ timeout: 5000 });
      
      const isDisplayed = await this.users.isVisible();
      if (isDisplayed) {
        await this.users.click();
        await this.page.waitForTimeout(2000);
        
        // Capture any errors
        await this.captureErrorIfPresent();
        
        await this.scrollIntoView(this.createUser);
        await expect(this.createUser).toBeVisible({ timeout: 10000 });
        
        const createUserText = await this.createUser.textContent();
        console.log(`✅ ${createUserText?.trim()} button is visible after clicking Users.`);
        return true;
      } else {
        throw new Error('Users button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in ClickOnUsersButton: ${error.message}`);
      throw error;
    }
  }

  // Verify Skills (converted from your Java method)
  async verifySkills() {
    try {
      console.log('🔍 Verifying Skills...');

      await this.scrollIntoView(this.skills);
      await expect(this.skills).toBeVisible({ timeout: 10000 });
      await expect(this.skills).toBeEnabled({ timeout: 5000 });

      if (await this.skills.isVisible()) {
        await this.skills.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createSkill);
        await expect(this.createSkill).toBeVisible({ timeout: 10000 });
        const createSkillText = await this.createSkill.textContent();
        console.log(`✅ ${createSkillText?.trim()} button is visible after clicking Skills.`);
        return true;
      } else {
        throw new Error('Skills button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifySkills: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to System Setup
      try {
        await this.scrollIntoView(this.backButton);
        await this.backButton.click();
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Click on Skills (converted from your Java method)
  async clickOnSkills() {
    try {
      console.log('🖱️ Clicking on Skills...');

      await this.scrollIntoView(this.skills);
      await expect(this.skills).toBeVisible({ timeout: 10000 });
      await expect(this.skills).toBeEnabled({ timeout: 5000 });

      if (await this.skills.isVisible()) {
        await this.skills.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createSkill);
        await expect(this.createSkill).toBeVisible({ timeout: 10000 });
        const createSkillText = await this.createSkill.textContent();
        console.log(`✅ ${createSkillText?.trim()} button is visible after clicking Skills.`);
        return true;
      } else {
        throw new Error('Skills button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in ClickOnSkills: ${error.message}`);
      throw error;
    }
  }

  // Setup Skills (converted from your Java method)
  async setupSkills(category, skillName) {
    try {
      console.log(`🔧 Setting up skill: ${skillName} in category: ${category}`);

      const xpath = `//tr[td[contains(normalize-space(),'${category.trim()}')] and td[contains(normalize-space(),'${skillName.trim()}')]]`;
      const existingFields = this.page.locator(xpath);
      const count = await existingFields.count();

      if (count === 0) {
        console.log(`📝 Skill '${skillName}' not found in category '${category}', creating new skill...`);
        await this.createSkillHelper(category, skillName);
      } else {
        const existingField = existingFields.first();
        await this.scrollIntoView(existingField);
        console.log(`✅ ${skillName}: Skill is already created within Category: ${category}`);
      }

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in SetupSkills: ${error.message}`);
      throw error;
    }
  }

  // Helper Create Skills (converted from your Java method)
  async createSkillHelper(category, skillName) {
    try {
      console.log(`🆕 Creating new skill: ${skillName} in category: ${category}`);

      await this.scrollIntoView(this.createSkill);
      await expect(this.createSkill).toBeEnabled({ timeout: 10000 });
      await this.createSkill.click();

      await expect(this.skillCategory).toBeVisible({ timeout: 10000 });

      // Select category from dropdown
      await this.skillCategory.selectOption({ label: category });

      // Verify selection
      const selectedOption = await this.skillCategory.locator('option:checked').textContent();
      console.log(`✅ ${selectedOption?.trim()}: Category is selected`);

      // Enter skill name
      await this.skill.clear();
      await this.skill.fill(skillName);

      // Save skill
      await this.scrollIntoView(this.saveSkill);
      await this.saveSkill.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors after saving
      await this.captureErrorIfPresent();

      console.log(`✅ Skill '${skillName}' created successfully in category '${category}'`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in CreateSkillHelper: ${error.message}`);
      throw error;
    }
  }

  // Verify Fields (converted from your Java method)
  async verifyFields() {
    try {
      console.log('🔍 Verifying Fields...');

      await this.scrollIntoView(this.fields);
      await expect(this.fields).toBeVisible({ timeout: 10000 });
      await expect(this.fields).toBeEnabled({ timeout: 5000 });

      if (await this.fields.isVisible()) {
        await this.fields.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createField);
        await expect(this.createField).toBeVisible({ timeout: 10000 });
        const createFieldText = await this.createField.textContent();
        console.log(`✅ ${createFieldText?.trim()} button is visible after clicking Fields.`);
        return true;
      } else {
        throw new Error('Fields button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyFields: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to System Setup
      try {
        await this.scrollIntoView(this.backButton);
        await this.backButton.click();
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Click on Fields (converted from your Java method)
  async clickOnFields() {
    try {
      console.log('🖱️ Clicking on Fields...');

      await this.scrollIntoView(this.fields);
      await expect(this.fields).toBeVisible({ timeout: 10000 });
      await expect(this.fields).toBeEnabled({ timeout: 5000 });

      if (await this.fields.isVisible()) {
        await this.fields.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createField);
        await expect(this.createField).toBeVisible({ timeout: 10000 });
        const createFieldText = await this.createField.textContent();
        console.log(`✅ ${createFieldText?.trim()} button is visible after clicking Fields.`);
        return true;
      } else {
        throw new Error('Fields button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in ClickOnFields: ${error.message}`);
      throw error;
    }
  }

  // Setup Fields (converted from your Java method)
  async setupFields(category, level, displayName, fieldName, type, inputType, min, max, noOfLines, options, optionValues, allowOther, tooltip) {
    try {
      console.log(`🔧 Setting up field: ${fieldName}`);

      const xpath = `//td[normalize-space()='${fieldName.trim()}']`;
      const existingFields = this.page.locator(xpath);
      const count = await existingFields.count();

      if (count === 0) {
        console.log(`📝 Field '${fieldName}' not found, creating new field...`);
        await this.createFieldHelper(category, level, displayName, fieldName, type, inputType, min, max, noOfLines, options, optionValues, allowOther, tooltip);
      } else {
        const existingField = existingFields.first();
        await this.scrollIntoView(existingField);
        console.log(`✅ ${fieldName}: Field is already created.`);
      }

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in SetupFields: ${error.message}`);
      throw error;
    }
  }

  // Helper Create Fields (converted from your Java method)
  async createFieldHelper(category, level, displayName, fieldName, type, inputType, min, max, noOfLines, options, optionValues, allowOther, tooltip) {
    try {
      console.log(`🆕 Creating new field: ${fieldName}`);

      await this.scrollIntoView(this.createField);
      await expect(this.createField).toBeEnabled({ timeout: 10000 });
      await this.createField.click();

      // Select category
      await expect(this.category).toBeVisible({ timeout: 10000 });
      await this.category.selectOption({ label: category });
      const selectedCategory = await this.category.locator('option:checked').textContent();
      console.log(`✅ ${selectedCategory?.trim()}: Category is selected`);

      // Fill display name and field name
      await this.displayname.clear();
      await this.displayname.fill(displayName);

      await this.fieldname.clear();
      await this.fieldname.fill(fieldName);

      // Select field type
      await expect(this.type).toBeEnabled({ timeout: 5000 });
      await this.type.selectOption({ label: type.trim() });

      // Handle different field types
      if (type.trim().includes("Text")) {
        await this.inputtypeTextType.selectOption({ label: inputType.trim() });

        if (inputType.trim().includes("Text Single Line") || inputType.trim().includes("Number")) {
          await expect(this.minrange).toBeVisible({ timeout: 5000 });
          await this.minrange.fill(min);
          await this.maxrange.fill(max);
        } else if (inputType.trim().includes("Text Area")) {
          await expect(this.minrange).toBeVisible({ timeout: 5000 });
          await this.minrange.fill(min);
          await this.maxrange.fill(max);
          await this.numoflines.fill(noOfLines);
        }

        if (tooltip.toLowerCase() === "yes") {
          await this.scrollIntoView(this.tooltip);
          await expect(this.tooltip).toBeEnabled({ timeout: 5000 });
          await this.tooltip.click();
          await expect(this.tooltipMsg).toBeVisible({ timeout: 5000 });
          await this.tooltipMsg.fill("Please Fill Value to the Field");
        }
      } else if (type.includes("Single Select")) {
        await this.inputtypeSingleType.selectOption({ label: inputType });

        if (inputType.includes("Radio") || inputType.includes("Drop Down")) {
          await this.fillOptions(fieldName, options, optionValues);
        }

        if (allowOther.toLowerCase() === "yes") {
          await this.scrollIntoView(this.allowother);
          await this.allowother.click();
        } else if (tooltip.toLowerCase() === "yes") {
          await this.scrollIntoView(this.tooltip);
          await this.tooltip.click();
          await expect(this.tooltipMsg).toBeVisible({ timeout: 5000 });
          await this.tooltipMsg.fill("Please Select any option");
        }
      } else if (type.includes("Multi Select")) {
        await this.inputtypeMultipleType.selectOption({ label: inputType });

        if (inputType.includes("Check Box") || inputType.includes("List")) {
          await this.fillOptions(fieldName, options, optionValues);
        }

        if (allowOther.toLowerCase() === "yes") {
          await this.scrollIntoView(this.allowother);
          await this.allowother.click();
        } else if (tooltip.toLowerCase() === "yes") {
          await this.scrollIntoView(this.tooltip);
          await this.tooltip.click();
          await expect(this.tooltipMsg).toBeVisible({ timeout: 5000 });
          await this.tooltipMsg.fill("Please Select any option");
        }
      }

      // Save field
      await this.scrollIntoView(this.saveField);
      await this.saveField.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors after saving
      await this.captureErrorIfPresent();

      console.log(`✅ Field '${fieldName}' created successfully`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in CreateFieldHelper: ${error.message}`);
      throw error;
    }
  }

  // Helper method to fill options (placeholder for fillOptions functionality)
  async fillOptions(fieldName, options, optionValues) {
    try {
      console.log(`📝 Filling options for field: ${fieldName}`);
      console.log(`Options: ${options}`);
      console.log(`Option Values: ${optionValues}`);

      // This would need to be implemented based on your specific UI for adding options
      // For now, just logging the values
      console.log('ℹ️ fillOptions method needs specific implementation based on UI');

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in fillOptions: ${error.message}`);
      throw error;
    }
  }

  //---------------------------------------------------------------------------------------------------
//Verify Documents
async navigateToDocuments() {
    console.log('📄 Navigating to Documents section...');
    await this.documents.scrollIntoViewIfNeeded();
    await this.documents.click();
    await expect(this.AddNewDoc).toBeVisible();
  }

  async clickAddNewDocument() {
    console.log('➕ Clicking on Add New Document...');
    await this.AddNewDoc.click();
    await expect(this.category).toBeVisible();
  }

  async uploadNewDocument({ categoryName, name, filePath, descriptionText }) {
    console.log(`📝 Uploading document: ${name}`);

    // Select category
    await this.category.selectOption({ label: categoryName });

    // Fill details
    await this.documentName.fill(name);
    await this.description.fill(descriptionText);

    // Handle file path - if it's a directory, pick the first file
    let actualFilePath = filePath;
    const fs = require('fs');
    const path = require('path');

    if (fs.existsSync(filePath) && fs.statSync(filePath).isDirectory()) {
      console.log(`📁 Directory detected: ${filePath}, finding first file...`);
      const files = fs.readdirSync(filePath).filter(file => {
        const fullPath = path.join(filePath, file);
        return fs.statSync(fullPath).isFile() && /\.(png|jpg|jpeg|gif|pdf|doc|docx|txt)$/i.test(file);
      });

      if (files.length > 0) {
        actualFilePath = path.join(filePath, files[0]);
        console.log(`📄 Using file: ${actualFilePath}`);
      } else {
        throw new Error(`No suitable files found in directory: ${filePath}`);
      }
    }

    // Upload file
    await this.uploadDocument.setInputFiles(actualFilePath);

    // Save
    await this.saveDocument.click();
    await this.page.waitForTimeout(2000);

    console.log('✅ Document upload process completed.');
  }


  //---------------------------------------------------------------------------
  // Verify Leads (converted from your Java method)
  async verifyLeads() {
    try {
      console.log('🔍 Verifying Leads...');

      await this.scrollIntoView(this.leads);
      await expect(this.leads).toBeVisible({ timeout: 10000 });
      await expect(this.leads).toBeEnabled({ timeout: 5000 });

      if (await this.leads.isVisible()) {
        await this.leads.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createLeadField);
        await expect(this.createLeadField).toBeVisible({ timeout: 10000 });
        const createLeadFieldText = await this.createLeadField.textContent();
        console.log(`✅ ${createLeadFieldText?.trim()} button is visible after clicking Leads.`);

        // Scroll to back button to make it visible
        await this.scrollIntoView(this.backButtonIcon);
        await expect(this.backButtonIcon).toBeVisible({ timeout: 10000 });

        return true;
      } else {
        throw new Error('Leads button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyLeads: ${error.message}`);
      throw error;
    }
  }

  // Click on Lead Field (converted from your Java method)
  async clickOnLeadField() {
    try {
      console.log('🖱️ Clicking on Lead Field...');

      await this.scrollIntoView(this.leadField);
      await expect(this.leadField).toBeEnabled({ timeout: 10000 });

      if (!(await this.leadField.isVisible())) {
        throw new Error('LeadField button is not visible.');
      }

      await this.leadField.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors
      await this.captureErrorIfPresent();

      await this.scrollIntoView(this.createLeadField);
      await expect(this.createLeadField).toBeVisible({ timeout: 10000 });
      const createLeadFieldText = await this.createLeadField.textContent();
      console.log(`✅ ${createLeadFieldText?.trim()} button is visible`);

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in ClickOnLeadField: ${error.message}`);
      throw error;
    }
  }

  // Setup Lead Fields (converted from your Java method)
  async setupLeadFields(category, displayName, fieldName, type, inputType, min, max, noOfLines, options, optionValues, allowOther, tooltip) {
    try {
      console.log(`🔧 Setting up lead field: ${fieldName}`);

      const xpath = `//td[normalize-space()='${fieldName}']`;
      const existingFields = this.page.locator(xpath);
      const count = await existingFields.count();

      if (count === 0) {
        console.log(`📝 Lead Field '${fieldName}' not found, creating new field...`);
        await this.createLeadFieldHelper(category, displayName, fieldName, type, inputType, min, max, noOfLines, options, optionValues, allowOther, tooltip);
      } else {
        const existingField = existingFields.first();
        await this.scrollIntoView(existingField);
        console.log(`✅ ${fieldName}: Lead Field is already created.`);
      }

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in SetupLeadFields: ${error.message}`);
      throw error;
    }
  }

  // Helper Create Lead Field (converted from your Java method)
  async createLeadFieldHelper(category, displayName, fieldName, type, inputType, min, max, noOfLines, options, optionValues, allowOther, tooltip) {
    try {
      console.log(`🆕 Creating new lead field: ${fieldName}`);

      await expect(this.createLeadField).toBeEnabled({ timeout: 10000 });
      await this.scrollIntoView(this.createLeadField);
      await this.createLeadField.click();

      // Select category
      await expect(this.category).toBeVisible({ timeout: 10000 });
      await this.category.selectOption({ label: category });
      const selectedCategory = await this.category.locator('option:checked').textContent();
      console.log(`✅ ${selectedCategory?.trim()}: Category is selected`);

      // Fill display name and field name
      await this.displayname.clear();
      await this.displayname.fill(displayName);

      await this.fieldname.clear();
      await this.fieldname.fill(fieldName);

      // Select field type
      await expect(this.type).toBeEnabled({ timeout: 5000 });
      await this.type.selectOption({ label: type.trim() });

      // Handle different field types (same logic as regular fields)
      if (type.trim().includes("Text")) {
        await this.inputtypeTextType.selectOption({ label: inputType.trim() });

        if (inputType.trim().includes("Text Single Line") || inputType.trim().includes("Number")) {
          await expect(this.minrange).toBeVisible({ timeout: 5000 });
          await this.minrange.fill(min);
          await this.maxrange.fill(max);
        } else if (inputType.trim().includes("Text Area")) {
          await expect(this.minrange).toBeVisible({ timeout: 5000 });
          await this.minrange.fill(min);
          await this.maxrange.fill(max);
          await this.numoflines.fill(noOfLines);
        }

        if (tooltip.toLowerCase() === "yes") {
          await this.scrollIntoView(this.tooltip);
          await expect(this.tooltip).toBeEnabled({ timeout: 5000 });
          await this.tooltip.click();
          await expect(this.tooltipMsg).toBeVisible({ timeout: 5000 });
          await this.tooltipMsg.fill("Please Fill Value to the Field");
        }
      } else if (type.includes("Single Select")) {
        await this.inputtypeSingleType.selectOption({ label: inputType });

        if (inputType.includes("Radio") || inputType.includes("Drop Down")) {
          await this.fillOptions(fieldName, options, optionValues);
        }

        if (allowOther.toLowerCase() === "yes") {
          await this.scrollIntoView(this.allowother);
          await this.allowother.click();
        } else if (tooltip.toLowerCase() === "yes") {
          await this.scrollIntoView(this.tooltip);
          await this.tooltip.click();
          await expect(this.tooltipMsg).toBeVisible({ timeout: 5000 });
          await this.tooltipMsg.fill("Please Select any option");
        }
      } else if (type.includes("Multi Select")) {
        await this.inputtypeMultipleType.selectOption({ label: inputType });

        if (inputType.includes("Check Box") || inputType.includes("List")) {
          await this.fillOptions(fieldName, options, optionValues);
        }

        if (allowOther.toLowerCase() === "yes") {
          await this.scrollIntoView(this.allowother);
          await this.allowother.click();
        } else if (tooltip.toLowerCase() === "yes") {
          await this.scrollIntoView(this.tooltip);
          await this.tooltip.click();
          await expect(this.tooltipMsg).toBeVisible({ timeout: 5000 });
          await this.tooltipMsg.fill("Please Select any option");
        }
      }

      // Save field
      await this.scrollIntoView(this.saveField);
      await this.saveField.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors after saving
      await this.captureErrorIfPresent();

      console.log(`✅ Lead Field '${fieldName}' created successfully`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in CreateLeadFieldHelper: ${error.message}`);
      throw error;
    }
  }

  // Verify Lead Stage (converted from your Java method)
  async verifyLeadStage() {
    try {
      console.log('🔍 Verifying Lead Stage...');

      await this.scrollIntoView(this.leadStage);
      await expect(this.leadStage).toBeVisible({ timeout: 10000 });
      await expect(this.leadStage).toBeEnabled({ timeout: 5000 });

      if (await this.leadStage.isVisible()) {
        await this.leadStage.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createLeadStage);
        await expect(this.createLeadStage).toBeVisible({ timeout: 10000 });
        const createLeadStageText = await this.createLeadStage.textContent();
        console.log(`✅ ${createLeadStageText?.trim()} button is visible after clicking LeadStage.`);

        return true;
      } else {
        throw new Error('LeadStage button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyLeadStage: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to Lead Field
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.leadField).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to Lead Field');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Click on Lead Stage (converted from your Java method)
  async clickOnLeadStage() {
    try {
      console.log('🖱️ Clicking on Lead Stage...');

      await this.scrollIntoView(this.leadStage);
      await expect(this.leadStage).toBeVisible({ timeout: 10000 });
      await expect(this.leadStage).toBeEnabled({ timeout: 5000 });

      if (await this.leadStage.isVisible()) {
        await this.leadStage.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createLeadStage);
        await expect(this.createLeadStage).toBeVisible({ timeout: 10000 });
        const createLeadStageText = await this.createLeadStage.textContent();
        console.log(`✅ ${createLeadStageText?.trim()} button is visible after clicking LeadStage.`);

        return true;
      } else {
        throw new Error('LeadStage button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in ClickOnLeadStage: ${error.message}`);
      throw error;
    }
  }

  // Setup Lead Stage (converted from your Java method)
  async setupLeadStage(category, stage, probability, defaultStage) {
    try {
      console.log(`🔧 Setting up lead stage: ${stage} in category: ${category}`);

      const xpath = `//td[normalize-space()='${category.trim()}']/parent::tr//td[contains(.,'${stage.trim()}')]`;
      const existingFields = this.page.locator(xpath);
      const count = await existingFields.count();

      if (count === 0) {
        console.log(`📝 Lead Stage '${stage}' not found in category '${category}', creating new stage...`);
        await this.createLeadStageHelper(category, stage, probability, defaultStage);
      } else {
        const existingField = existingFields.first();
        await this.scrollIntoView(existingField);
        console.log(`✅ ${stage}: Lead Stage is already created.`);
      }

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in SetupLeadStage: ${error.message}`);
      throw error;
    }
  }

  // Helper Create Lead Stage (converted from your Java method)
  async createLeadStageHelper(category, stage, probability, defaultStage) {
    try {
      console.log(`🆕 Creating new lead stage: ${stage} with probability: ${probability}%`);

      await expect(this.createLeadStage).toBeEnabled({ timeout: 10000 });
      await this.scrollIntoView(this.createLeadStage);
      await this.createLeadStage.click();

      // Select category
      await expect(this.category).toBeVisible({ timeout: 10000 });
      await this.category.selectOption({ label: category });
      const selectedCategory = await this.category.locator('option:checked').textContent();
      console.log(`✅ ${selectedCategory?.trim()}: Category is selected`);

      // Fill stage name
      await this.stagename.clear();
      await this.stagename.fill(stage);

      // Fill probability
      await this.probability.clear();
      await this.probability.fill(probability);

      // Save lead stage
      await this.saveLeadStage.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors after saving
      await this.captureErrorIfPresent();

      // Handle default stage setting if specified
      if (defaultStage && defaultStage.trim().toLowerCase() === "yes") {
        console.log(`🎯 Setting ${stage} as default stage...`);

        // Navigate back to Lead Field and then to Lead Stage to set default
        await expect(this.leadField).toBeEnabled({ timeout: 10000 });
        await this.scrollIntoView(this.leadField);
        await this.leadField.click();
        await this.page.waitForTimeout(1000);

        await this.leadStage.click();
        await this.page.waitForTimeout(1000);

        // Find and click the "Set Default" button for this stage
        const setDefaultXpath = `//td[normalize-space()='${category.trim()}']/parent::tr//td[contains(.,'${stage.trim()}')]/parent::tr//span[contains(text(),'Set Default')]`;
        const setDefaultElement = this.page.locator(setDefaultXpath);

        if (await setDefaultElement.count() > 0) {
          await expect(setDefaultElement).toBeEnabled({ timeout: 5000 });
          await this.scrollIntoView(setDefaultElement);
          await setDefaultElement.click();
          await this.page.waitForTimeout(1000);
          console.log(`✅ ${stage} set as default stage successfully`);
        } else {
          console.log(`⚠️ Set Default button not found for stage: ${stage}`);
        }
      }

      console.log(`✅ Lead Stage '${stage}' created successfully with ${probability}% probability`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in CreateLeadStageHelper: ${error.message}`);
      throw error;
    }
  }

  // Verify Lead Status (converted from your Java method)
  async verifyLeadStatus() {
    try {
      console.log('🔍 Verifying Lead Status...');

      await this.scrollIntoView(this.leadStatus);
      await expect(this.leadStatus).toBeVisible({ timeout: 10000 });
      await expect(this.leadStatus).toBeEnabled({ timeout: 5000 });

      if (await this.leadStatus.isVisible()) {
        await this.leadStatus.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createLeadStatus);
        await expect(this.createLeadStatus).toBeVisible({ timeout: 10000 });
        const createLeadStatusText = await this.createLeadStatus.textContent();
        console.log(`✅ ${createLeadStatusText?.trim()} button is visible after clicking LeadStatus.`);

        return true;
      } else {
        throw new Error('LeadStatus button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyLeadStatus: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to Lead Field
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.leadField).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to Lead Field');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Click on Lead Status (converted from your Java method)
  async clickOnLeadStatus() {
    try {
      console.log('🖱️ Clicking on Lead Status...');

      await this.scrollIntoView(this.leadStatus);
      await expect(this.leadStatus).toBeVisible({ timeout: 10000 });
      await expect(this.leadStatus).toBeEnabled({ timeout: 5000 });

      if (await this.leadStatus.isVisible()) {
        await this.leadStatus.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createLeadStatus);
        await expect(this.createLeadStatus).toBeVisible({ timeout: 10000 });
        const createLeadStatusText = await this.createLeadStatus.textContent();
        console.log(`✅ ${createLeadStatusText?.trim()} button is visible after clicking LeadStatus.`);

        return true;
      } else {
        throw new Error('LeadStatus button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in ClickOnLeadStatus: ${error.message}`);
      throw error;
    }
  }

  // Setup Lead Status (converted from your Java method)
  async setupLeadStatus(category, status, defaultStatus) {
    try {
      console.log(`🔧 Setting up lead status: ${status} in category: ${category}`);

      const xpath = `//td[normalize-space()='${category.trim()}']/parent::tr//td[contains(.,'${status.trim()}')]`;
      const existingFields = this.page.locator(xpath);
      const count = await existingFields.count();

      if (count === 0) {
        console.log(`📝 Lead Status '${status}' not found in category '${category}', creating new status...`);
        await this.createLeadStatusHelper(category, status, defaultStatus);
      } else {
        const existingField = existingFields.first();
        await this.scrollIntoView(existingField);
        console.log(`✅ ${status}: Lead Status is already created.`);
      }

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in SetupLeadStatus: ${error.message}`);
      throw error;
    }
  }

  // Helper Create Lead Status (converted from your Java method)
  async createLeadStatusHelper(category, status, defaultStatus) {
    try {
      console.log(`🆕 Creating new lead status: ${status}`);

      await expect(this.createLeadStatus).toBeEnabled({ timeout: 10000 });
      await this.scrollIntoView(this.createLeadStatus);
      await this.createLeadStatus.click();

      // Select category
      await expect(this.category).toBeVisible({ timeout: 10000 });
      await this.category.selectOption({ label: category });
      const selectedCategory = await this.category.locator('option:checked').textContent();
      console.log(`✅ ${selectedCategory?.trim()}: Category is selected`);

      // Fill status name
      await this.statusname.clear();
      await this.statusname.fill(status);

      // Save lead status
      await this.saveLeadStatus.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors after saving
      await this.captureErrorIfPresent();

      // Handle default status setting if specified
      if (defaultStatus && defaultStatus.trim().toLowerCase() === "yes") {
        console.log(`🎯 Setting ${status} as default status...`);

        // Navigate back to Lead Field and then to Lead Status to set default
        await expect(this.leadField).toBeEnabled({ timeout: 10000 });
        await this.scrollIntoView(this.leadField);
        await this.leadField.click();
        await this.page.waitForTimeout(1000);

        await this.leadStatus.click();
        await this.page.waitForTimeout(1000);

        // Find and click the "Set Default" button for this status
        const setDefaultXpath = `//td[normalize-space()='${category.trim()}']/parent::tr//td[contains(.,'${status.trim()}')]/parent::tr//span[contains(text(),'Set Default')]`;
        const setDefaultElement = this.page.locator(setDefaultXpath);

        if (await setDefaultElement.count() > 0) {
          await expect(setDefaultElement).toBeEnabled({ timeout: 5000 });
          await this.scrollIntoView(setDefaultElement);
          await setDefaultElement.click();
          await this.page.waitForTimeout(1000);
          console.log(`✅ ${status} set as default status successfully`);
        } else {
          console.log(`⚠️ Set Default button not found for status: ${status}`);
        }
      }

      console.log(`✅ Lead Status '${status}' created successfully`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in CreateLeadStatusHelper: ${error.message}`);
      throw error;
    }
  }

  // Verify Lead Lost Reason (converted from your Java method)
  async verifyLeadLostReason() {
    try {
      console.log('🔍 Verifying Lead Lost Reason...');

      await this.scrollIntoView(this.leadLostReason);
      await expect(this.leadLostReason).toBeVisible({ timeout: 10000 });
      await expect(this.leadLostReason).toBeEnabled({ timeout: 5000 });

      if (await this.leadLostReason.isVisible()) {
        await this.leadLostReason.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createLeadLostReason);
        await expect(this.createLeadLostReason).toBeVisible({ timeout: 10000 });
        const createLeadLostReasonText = await this.createLeadLostReason.textContent();
        console.log(`✅ ${createLeadLostReasonText?.trim()} button is visible after clicking LeadLostReason.`);

        return true;
      } else {
        throw new Error('LeadLostReason button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyLeadLostReason: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to Lead Field and then to System Setup (double back navigation)
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.leadField).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to Lead Field');

        // Second back navigation to System Setup
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Click on Lead Lost Reason (converted from your Java method)
  async clickOnLeadLostReason() {
    try {
      console.log('🖱️ Clicking on Lead Lost Reason...');

      await this.scrollIntoView(this.leadLostReason);
      await expect(this.leadLostReason).toBeVisible({ timeout: 10000 });
      await expect(this.leadLostReason).toBeEnabled({ timeout: 5000 });

      if (await this.leadLostReason.isVisible()) {
        await this.leadLostReason.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createLeadLostReason);
        await expect(this.createLeadLostReason).toBeVisible({ timeout: 10000 });
        const createLeadLostReasonText = await this.createLeadLostReason.textContent();
        console.log(`✅ ${createLeadLostReasonText?.trim()} button is visible after clicking LeadLostReason.`);

        return true;
      } else {
        throw new Error('LeadLostReason button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in ClickOnLeadLostReason: ${error.message}`);
      throw error;
    }
  }

  // Setup Lead Lost Reason (converted from your Java method)
  async setupLeadLostReason(category, lostReason) {
    try {
      console.log(`🔧 Setting up lead lost reason: ${lostReason} in category: ${category}`);

      const xpath = `//td[normalize-space()='${category.trim()}']/parent::tr//td[contains(.,'${lostReason.trim()}')]`;
      const existingFields = this.page.locator(xpath);
      const count = await existingFields.count();

      if (count === 0) {
        console.log(`📝 Lead Lost Reason '${lostReason}' not found in category '${category}', creating new lost reason...`);
        await this.createLeadLostReasonHelper(category, lostReason);
      } else {
        const existingField = existingFields.first();
        await this.scrollIntoView(existingField);
        console.log(`✅ ${lostReason}: Lead Lost Reason is already created.`);
      }

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in SetupLeadLostReason: ${error.message}`);
      throw error;
    }
  }

  // Helper Create Lead Lost Reason (converted from your Java method)
  async createLeadLostReasonHelper(category, lostReason) {
    try {
      console.log(`🆕 Creating new lead lost reason: ${lostReason}`);

      await expect(this.createLeadLostReason).toBeEnabled({ timeout: 10000 });
      await this.scrollIntoView(this.createLeadLostReason);
      await this.createLeadLostReason.click();

      // Select category
      await expect(this.category).toBeVisible({ timeout: 10000 });
      await this.category.selectOption({ label: category });
      const selectedCategory = await this.category.locator('option:checked').textContent();
      console.log(`✅ ${selectedCategory?.trim()}: Category is selected`);

      // Fill lost reason
      await this.lostreason.clear();
      await this.lostreason.fill(lostReason);

      // Save lead lost reason
      await this.saveLeadLost.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors after saving
      await this.captureErrorIfPresent();

      console.log(`✅ Lead Lost Reason '${lostReason}' created successfully`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in CreateLeadLostReasonHelper: ${error.message}`);
      throw error;
    }
  }

  // Verify Tickets (converted from your Java method)
  async verifyTickets() {
    try {
      console.log('🔍 Verifying Tickets...');

      await this.scrollIntoView(this.tickets);
      await expect(this.tickets).toBeVisible({ timeout: 10000 });
      await expect(this.tickets).toBeEnabled({ timeout: 5000 });

      if (await this.tickets.isVisible()) {
        await this.tickets.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createTicketField);
        await expect(this.createTicketField).toBeVisible({ timeout: 10000 });
        const createTicketFieldText = await this.createTicketField.textContent();
        console.log(`✅ ${createTicketFieldText?.trim()} button is visible after clicking Tickets.`);

        // Scroll to back button to make it visible
        await this.scrollIntoView(this.backButtonIcon);
        await expect(this.backButtonIcon).toBeVisible({ timeout: 10000 });

        return true;
      } else {
        throw new Error('Tickets button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyTickets: ${error.message}`);
      throw error;
    }
  }

  // Click on Ticket Field (converted from your Java method)
  async clickOnTicketField() {
    try {
      console.log('🖱️ Clicking on Ticket Field...');

      await this.scrollIntoView(this.ticketField);
      await expect(this.ticketField).toBeEnabled({ timeout: 10000 });

      if (!(await this.ticketField.isVisible())) {
        throw new Error('TicketField button is not visible.');
      }

      await this.ticketField.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors
      await this.captureErrorIfPresent();

      await this.scrollIntoView(this.createTicketField);
      await expect(this.createTicketField).toBeVisible({ timeout: 10000 });
      const createTicketFieldText = await this.createTicketField.textContent();
      console.log(`✅ ${createTicketFieldText?.trim()} button is visible`);

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in ClickOnTicketField: ${error.message}`);
      throw error;
    }
  }

  // Setup Ticket Fields (converted from your Java method)
  async setupTicketFields(category, displayName, fieldName, type, inputType, min, max, noOfLines, options, optionValues, allowOther, tooltip) {
    try {
      console.log(`🔧 Setting up ticket field: ${fieldName}`);

      const xpath = `//td[normalize-space()='${fieldName}']`;
      const existingFields = this.page.locator(xpath);
      const count = await existingFields.count();

      if (count === 0) {
        console.log(`📝 Ticket Field '${fieldName}' not found, creating new field...`);
        await this.createTicketFieldHelper(category, displayName, fieldName, type, inputType, min, max, noOfLines, options, optionValues, allowOther, tooltip);
      } else {
        const existingField = existingFields.first();
        await this.scrollIntoView(existingField);
        console.log(`✅ ${fieldName}: Ticket Field is already created.`);
      }

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in SetupTicketFields: ${error.message}`);
      throw error;
    }
  }

  // Helper Create Ticket Field (converted from your Java method)
  async createTicketFieldHelper(category, displayName, fieldName, type, inputType, min, max, noOfLines, options, optionValues, allowOther, tooltip) {
    try {
      console.log(`🆕 Creating new ticket field: ${fieldName}`);

      await expect(this.createTicketField).toBeEnabled({ timeout: 10000 });
      await this.scrollIntoView(this.createTicketField);
      await this.createTicketField.click();

      // Select category
      await expect(this.category).toBeVisible({ timeout: 10000 });
      await this.category.selectOption({ label: category });
      const selectedCategory = await this.category.locator('option:checked').textContent();
      console.log(`✅ ${selectedCategory?.trim()}: Category is selected`);

      // Fill display name and field name
      await this.ticketDisplayname.clear();
      await this.ticketDisplayname.fill(displayName);

      await this.ticketFieldname.clear();
      await this.ticketFieldname.fill(fieldName);

      // Select field type
      await this.ticketType.selectOption({ label: type });

      // Handle different field types
      if (type.includes("Text")) {
        await this.ticketInputtypeTextType.selectOption({ label: "Text" });

        if (inputType.includes("Text Single Line") || inputType.includes("Number")) {
          await expect(this.ticketMinrange).toBeVisible({ timeout: 5000 });
          await this.ticketMinrange.fill(min);
          await this.ticketMaxrange.fill(max);
        } else if (inputType.includes("Text Area")) {
          await expect(this.ticketMinrange).toBeVisible({ timeout: 5000 });
          await this.ticketMinrange.fill(min);
          await this.ticketMaxrange.fill(max);
          await this.ticketNumoflines.fill(noOfLines);
        }

        if (tooltip.toLowerCase() === "yes") {
          await this.scrollIntoView(this.ticketTooltip);
          await this.ticketTooltip.click();
          await expect(this.ticketTooltipMsg).toBeVisible({ timeout: 5000 });
          await this.ticketTooltipMsg.fill("Please Fill Value to the Field");
        }
      } else if (type.includes("Single Select")) {
        await this.ticketInputtypeSingleType.selectOption({ label: inputType });

        if (inputType.includes("Radio") || inputType.includes("Drop Down")) {
          await this.fillTicketOptions(fieldName, options, optionValues);
        }

        if (allowOther.toLowerCase() === "yes") {
          await this.scrollIntoView(this.ticketAllowother);
          await this.ticketAllowother.click();
        } else if (tooltip.toLowerCase() === "yes") {
          await this.scrollIntoView(this.ticketTooltip);
          await this.ticketTooltip.click();
          await expect(this.ticketTooltipMsg).toBeVisible({ timeout: 5000 });
          await this.ticketTooltipMsg.fill("Please Select any option");
        }
      } else if (type.includes("Multi Select")) {
        await this.ticketInputtypeMultipleType.selectOption({ label: inputType });

        if (inputType.includes("Check Box") || inputType.includes("List")) {
          await this.fillTicketOptions(fieldName, options, optionValues);
        }

        if (allowOther.toLowerCase() === "yes") {
          await this.scrollIntoView(this.ticketAllowother);
          await this.ticketAllowother.click();
        } else if (tooltip.toLowerCase() === "yes") {
          await this.scrollIntoView(this.ticketTooltip);
          await this.ticketTooltip.click();
          await expect(this.ticketTooltipMsg).toBeVisible({ timeout: 5000 });
          await this.ticketTooltipMsg.fill("Please Select any option");
        }
      }

      // Save ticket field
      await this.scrollIntoView(this.saveTicketField);
      await this.saveTicketField.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors after saving
      await this.captureErrorIfPresent();

      console.log(`✅ Ticket Field '${fieldName}' created successfully`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in CreateTicketFieldHelper: ${error.message}`);
      throw error;
    }
  }

  // Fill Ticket Options (converted from your Java method)
  async fillTicketOptions(fieldName, options, optionValues) {
    try {
      console.log(`📝 Filling ticket options for field: ${fieldName}`);
      console.log(`Number of options: ${options}, Option values: ${optionValues}`);

      // Select number of options
      await this.ticketOptions.selectOption({ label: options.trim() });

      const numOptions = parseInt(options.trim());
      const optionList = optionValues.split(",");

      if (optionList.length < numOptions) {
        throw new Error(`Not enough option values provided for: ${fieldName}`);
      }

      // Fill each option field
      for (let i = 1; i <= numOptions; i++) {
        const optionFieldId = `opt${i}`;
        const optionInput = this.page.locator(`//input[@id='${optionFieldId}']`);

        await expect(optionInput).toBeVisible({ timeout: 5000 });
        await this.scrollIntoView(optionInput);
        await optionInput.clear();
        await optionInput.fill(optionList[i - 1].trim());

        console.log(`✅ Option ${i}: ${optionList[i - 1].trim()}`);
      }

      console.log(`✅ All ${numOptions} options filled successfully for ${fieldName}`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in fillTicketOptions: ${error.message}`);
      throw error;
    }
  }

  // Verify Ticket Type (converted from your Java method)
  async verifyTicketType() {
    try {
      console.log('🔍 Verifying Ticket Type...');

      await this.scrollIntoView(this.ticketType);
      await expect(this.ticketType).toBeVisible({ timeout: 10000 });
      await expect(this.ticketType).toBeEnabled({ timeout: 5000 });

      if (await this.ticketType.isVisible()) {
        await this.ticketType.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createTicketType);
        await expect(this.createTicketType).toBeVisible({ timeout: 10000 });
        const createTicketTypeText = await this.createTicketType.textContent();
        console.log(`✅ ${createTicketTypeText?.trim()} button is visible after clicking TicketType.`);
        return true;
      } else {
        throw new Error('TicketType button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyTicketType: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to Ticket Field
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.ticketField).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to Ticket Field');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Click on Ticket Type (converted from your Java method)
  async clickOnTicketType() {
    try {
      console.log('🖱️ Clicking on Ticket Type...');

      await this.scrollIntoView(this.ticketType);
      await expect(this.ticketType).toBeVisible({ timeout: 10000 });
      await expect(this.ticketType).toBeEnabled({ timeout:  5000 });

      if (await this.ticketType.isVisible()) {
        await this.ticketType.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createTicketType);
        await expect(this.createTicketType).toBeVisible({ timeout: 10000 });
        const createTicketTypeText = await this.createTicketType.textContent();
        console.log(`✅ ${createTicketTypeText?.trim()} button is visible after clicking TicketType.`);
        return true;
      } else {
        throw new Error('TicketType button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in ClickOnTicketType: ${error.message}`);
      throw error;
    }
  }

  // Create Ticket Type (converted from your Java method)
  async createTicketType(category, type, defaultType) {
    try {
      console.log(`🔧 Setting up ticket type: ${type} in category: ${category}`);

      const xpath = `//td[normalize-space()='${category.trim()}']/parent::tr//td[contains(.,'${type.trim()}')]`;
      const existingTypes = this.page.locator(xpath);
      const count = await existingTypes.count();

      if (count === 0) {
        console.log(`📝 Ticket Type '${type}' not found in category '${category}', creating new type...`);
        await this.createTicketTypeHelper(category, type, defaultType);
      } else {
        console.log(`✅ ${type}: Ticket Type is already created.`);
      }

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in CreateTicketType: ${error.message}`);
      throw error;
    }
  }

  // Helper Create Ticket Type (converted from your Java method)
  async createTicketTypeHelper(category, type, defaultType) {
    try {
      console.log(`🆕 Creating new ticket type: ${type}`);

      await expect(this.createTicketType).toBeEnabled({ timeout: 10000 });
      await this.scrollIntoView(this.createTicketType);
      await this.createTicketType.click();

      // Select category
      await expect(this.ticketCategorySelect).toBeVisible({ timeout: 10000 });
      await this.ticketCategorySelect.selectOption({ label: category });
      const selectedCategory = await this.ticketCategorySelect.locator('option:checked').textContent();
      console.log(`✅ ${selectedCategory?.trim()}: Category is selected`);

      // Fill type name
      await this.ticketTypeName.fill(type);

      // Save ticket type
      await this.saveTicketType.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors after saving
      await this.captureErrorIfPresent();

      // Handle default type setting if specified
      if (defaultType && defaultType.trim().toLowerCase() === "yes") {
        console.log(`🎯 Setting ${type} as default type...`);

        // Navigate back to Ticket Field and then to Ticket Type to set default
        await expect(this.ticketFields).toBeEnabled({ timeout: 10000 });
        await this.scrollIntoView(this.ticketFields);
        await this.ticketFields.click();
        await this.page.waitForTimeout(1000);

        await this.ticketType.click();
        await this.page.waitForTimeout(1000);

        // Find and click the "Set Default" button for this type
        const setDefaultXpath = `//td[normalize-space()='${category.trim()}']/parent::tr//td[contains(.,'${type.trim()}')]/parent::tr//span[contains(text(),'Set Default')]`;
        const setDefaultElement = this.page.locator(setDefaultXpath);

        if (await setDefaultElement.count() > 0) {
          await expect(setDefaultElement).toBeEnabled({ timeout: 5000 });
          await this.scrollIntoView(setDefaultElement);
          await setDefaultElement.click();
          await this.page.waitForTimeout(1000);
          console.log(`✅ ${type} set as default type successfully`);
        } else {
          console.log(`⚠️ Set Default button not found for type: ${type}`);
        }
      }

      console.log(`✅ Ticket Type '${type}' created successfully`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in CreateTicketTypeHelper: ${error.message}`);
      throw error;
    }
  }

  // Verify Ticket Priority (converted from your Java method)
  async verifyTicketPriority() {
    try {
      console.log('🔍 Verifying Ticket Priority...');

      await this.scrollIntoView(this.ticketPriority);
      await expect(this.ticketPriority).toBeVisible({ timeout: 10000 });
      await expect(this.ticketPriority).toBeEnabled({ timeout: 5000 });

      if (await this.ticketPriority.isVisible()) {
        await this.ticketPriority.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createTicketPriority);
        await expect(this.createTicketPriority).toBeVisible({ timeout: 10000 });
        const createTicketPriorityText = await this.createTicketPriority.textContent();
        console.log(`✅ ${createTicketPriorityText?.trim()} button is visible after clicking TicketPriority.`);

        return true;
      } else {
        throw new Error('TicketPriority button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyTicketPriority: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to Ticket Field
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.ticketField).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to Ticket Field');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Click on Ticket Priority (converted from your Java method)
  async clickOnTicketPriority() {
    try {
      console.log('🖱️ Clicking on Ticket Priority...');

      await this.scrollIntoView(this.ticketPriority);
      await expect(this.ticketPriority).toBeVisible({ timeout: 10000 });
      await expect(this.ticketPriority).toBeEnabled({ timeout: 5000 });

      if (await this.ticketPriority.isVisible()) {
        await this.ticketPriority.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createTicketPriority);
        await expect(this.createTicketPriority).toBeVisible({ timeout: 10000 });
        const createTicketPriorityText = await this.createTicketPriority.textContent();
        console.log(`✅ ${createTicketPriorityText?.trim()} button is visible after clicking TicketPriority.`);

        return true;
      } else {
        throw new Error('TicketPriority button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in ClickOnTicketPriority: ${error.message}`);
      throw error;
    }
  }

  // Setup Ticket Priority (converted from your Java method)
  async setupTicketPriority(category, priority, defaultPriority, firstResponseWithin, firstResponseTime, trailResponseWithin, trailResponseTime, resolveWithin, resolveTime) {
    try {
      console.log(`🔧 Setting up ticket priority: ${priority} in category: ${category}`);

      const xpath = `//td[normalize-space()='${category.trim()}']/parent::tr//td[contains(.,'${priority.trim()}')]`;
      const existingPriorities = this.page.locator(xpath);
      const count = await existingPriorities.count();

      if (count === 0) {
        console.log(`📝 Ticket Priority '${priority}' not found in category '${category}', creating new priority...`);
        await this.createTicketPriorityHelper(category, priority, defaultPriority, firstResponseWithin, firstResponseTime, trailResponseWithin, trailResponseTime, resolveWithin, resolveTime);
      } else {
        console.log(`✅ ${priority}: Ticket Priority is already created.`);
      }

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in SetupTicketPriority: ${error.message}`);
      throw error;
    }
  }

  // Helper Create Ticket Priority (converted from your Java method)
  async createTicketPriorityHelper(category, priority, defaultPriority, firstResponseWithin, firstResponseTime, trailResponseWithin, trailResponseTime, resolveWithin, resolveTime) {
    try {
      console.log(`🆕 Creating new ticket priority: ${priority} with response times`);

      await expect(this.createTicketPriority).toBeEnabled({ timeout: 10000 });
      await this.scrollIntoView(this.createTicketPriority);
      await this.createTicketPriority.click();

      // Select category
      await expect(this.ticketCategorySelect).toBeVisible({ timeout: 10000 });
      await this.ticketCategorySelect.selectOption({ label: category });
      const selectedCategory = await this.ticketCategorySelect.locator('option:checked').textContent();
      console.log(`✅ ${selectedCategory?.trim()}: Category is selected`);

      // Fill priority name
      await this.priorityName.fill(priority);

      // Fill first response settings
      await this.firstResponse.clear();
      await this.firstResponse.fill(firstResponseWithin);
      await this.firstResponseTime.selectOption({ label: firstResponseTime });

      // Fill trail response settings
      await this.trailResponse.clear();
      await this.trailResponse.fill(trailResponseWithin);
      await this.trailResponseTime.selectOption({ label: trailResponseTime });

      // Fill resolve settings
      await this.resolved.clear();
      await this.resolved.fill(resolveWithin);
      await this.resolvedTime.selectOption({ label: resolveTime });

      // Save ticket priority
      await this.saveTicketPriority.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors after saving
      await this.captureErrorIfPresent();

      // Handle default priority setting if specified
      if (defaultPriority && defaultPriority.trim().toLowerCase() === "yes") {
        console.log(`🎯 Setting ${priority} as default priority...`);

        // Navigate back to Ticket Field and then to Ticket Priority to set default
        await expect(this.ticketFields).toBeEnabled({ timeout: 10000 });
        await this.scrollIntoView(this.ticketFields);
        await this.ticketFields.click();
        await this.page.waitForTimeout(1000);

        await this.ticketPriority.click();
        await this.page.waitForTimeout(1000);

        // Find and click the "Set Default" button for this priority
        const setDefaultXpath = `//td[normalize-space()='${category.trim()}']/parent::tr//td[contains(.,'${priority.trim()}')]/parent::tr//span[contains(text(),'Set Default')]`;
        const setDefaultElement = this.page.locator(setDefaultXpath);

        if (await setDefaultElement.count() > 0) {
          await expect(setDefaultElement).toBeEnabled({ timeout: 5000 });
          await this.scrollIntoView(setDefaultElement);
          await setDefaultElement.click();
          await this.page.waitForTimeout(1000);
          console.log(`✅ ${priority} set as default priority successfully`);
        } else {
          console.log(`⚠️ Set Default button not found for priority: ${priority}`);
        }
      }

      console.log(`✅ Ticket Priority '${priority}' created successfully with response times`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in CreateTicketPriorityHelper: ${error.message}`);
      throw error;
    }
  }

  // Verify Ticket Stage (converted from your Java method)
  async verifyTicketStage() {
    try {
      console.log('🔍 Verifying Ticket Stage...');

      await this.scrollIntoView(this.ticketStage);
      await expect(this.ticketStage).toBeVisible({ timeout: 10000 });
      await expect(this.ticketStage).toBeEnabled({ timeout: 5000 });

      if (await this.ticketStage.isVisible()) {
        await this.ticketStage.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createTicketStage);
        await expect(this.createTicketStage).toBeVisible({ timeout: 10000 });
        const createTicketStageText = await this.createTicketStage.textContent();
        console.log(`✅ ${createTicketStageText?.trim()} button is visible after clicking TicketStage.`);

        return true;
      } else {
        throw new Error('TicketStage button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyTicketStage: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to Ticket Field and then to System Setup (double back navigation)
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.ticketField).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to Ticket Field');

        // Second back navigation to System Setup
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Click on Ticket Stage (converted from your Java method)
  async clickOnTicketStage() {
    try {
      console.log('🖱️ Clicking on Ticket Stage...');

      await this.scrollIntoView(this.ticketStage);
      await expect(this.ticketStage).toBeVisible({ timeout: 10000 });
      await expect(this.ticketStage).toBeEnabled({ timeout: 5000 });

      if (await this.ticketStage.isVisible()) {
        await this.ticketStage.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createTicketStage);
        await expect(this.createTicketStage).toBeVisible({ timeout: 10000 });
        const createTicketStageText = await this.createTicketStage.textContent();
        console.log(`✅ ${createTicketStageText?.trim()} button is visible after clicking TicketStage.`);

        return true;
      } else {
        throw new Error('TicketStage button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in ClickOnTicketStage: ${error.message}`);
      throw error;
    }
  }

  // Setup Ticket Stage (converted from your Java method)
  async setupTicketStage(category, stage, defaultStage, order, isClosed) {
    try {
      console.log(`🔧 Setting up ticket stage: ${stage} in category: ${category}`);

      const xpath = `//td[normalize-space()='${category.trim()}']/parent::tr//td[contains(.,'${stage.trim()}')]`;
      const existingStages = this.page.locator(xpath);
      const count = await existingStages.count();

      if (count === 0) {
        console.log(`📝 Ticket Stage '${stage}' not found in category '${category}', creating new stage...`);
        await this.createTicketStageHelper(category, stage, defaultStage, order, isClosed);
      } else {
        console.log(`✅ ${stage}: Ticket Stage is already created.`);
      }

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in SetupTicketStage: ${error.message}`);
      throw error;
    }
  }

  // Helper Create Ticket Stage (converted from your Java method)
  async createTicketStageHelper(category, stage, defaultStage, order, isClosed) {
    try {
      console.log(`🆕 Creating new ticket stage: ${stage} with order: ${order}`);

      await expect(this.createTicketStage).toBeEnabled({ timeout: 10000 });
      await this.scrollIntoView(this.createTicketStage);
      await this.createTicketStage.click();

      // Select category
      await expect(this.ticketCategorySelect).toBeVisible({ timeout: 10000 });
      await this.ticketCategorySelect.selectOption({ label: category });
      const selectedCategory = await this.ticketCategorySelect.locator('option:checked').textContent();
      console.log(`✅ ${selectedCategory?.trim()}: Category is selected`);

      // Fill stage name
      await this.stage.clear();
      await this.stage.fill(stage);

      // Fill display order
      await this.displayorder.clear();
      await this.displayorder.fill(order);

      // Handle "Is Closed" checkbox
      if (isClosed && isClosed.trim().toLowerCase() === "yes") {
        console.log(`🔒 Setting ${stage} as closed stage...`);
        await expect(this.isclosed).toBeEnabled({ timeout: 5000 });
        await this.scrollIntoView(this.isclosed);
        await this.isclosed.click();
        console.log(`✅ ${stage} marked as closed stage`);
      }

      // Save ticket stage
      await this.saveStage.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors after saving
      await this.captureErrorIfPresent();

      // Handle default stage setting if specified
      if (defaultStage && defaultStage.trim().toLowerCase() === "yes") {
        console.log(`🎯 Setting ${stage} as default stage...`);

        // Navigate back to Ticket Field and then to Ticket Stage to set default
        await expect(this.ticketFields).toBeEnabled({ timeout: 10000 });
        await this.scrollIntoView(this.ticketFields);
        await this.ticketFields.click();
        await this.page.waitForTimeout(1000);

        await this.ticketStage.click();
        await this.page.waitForTimeout(1000);

        // Find and click the "Set Default" button for this stage
        const setDefaultXpath = `//td[normalize-space()='${category.trim()}']/parent::tr//td[contains(.,'${stage.trim()}')]/parent::tr//span[contains(text(),'Set Default')]`;
        const setDefaultElement = this.page.locator(setDefaultXpath);

        if (await setDefaultElement.count() > 0) {
          await expect(setDefaultElement).toBeEnabled({ timeout: 5000 });
          await this.scrollIntoView(setDefaultElement);
          await setDefaultElement.click();
          await this.page.waitForTimeout(1000);
          console.log(`✅ ${stage} set as default stage successfully`);
        } else {
          console.log(`⚠️ Set Default button not found for stage: ${stage}`);
        }
      }

      console.log(`✅ Ticket Stage '${stage}' created successfully with order ${order}`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in CreateTicketStageHelper: ${error.message}`);
      throw error;
    }
  }

  // Verify Dispositions (converted from your Java method)
  async verifyDispositions() {
    try {
      console.log('🔍 Verifying Dispositions...');

      await this.scrollIntoView(this.dispositions);
      await expect(this.dispositions).toBeVisible({ timeout: 10000 });
      await expect(this.dispositions).toBeEnabled({ timeout: 5000 });

      if (await this.dispositions.isVisible()) {
        await this.dispositions.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createDispositionScreen);
        await expect(this.createDispositionScreen).toBeVisible({ timeout: 10000 });
        await expect(this.createDispositionScreen).toBeEnabled({ timeout: 5000 });
        const createDispositionScreenText = await this.createDispositionScreen.textContent();
        console.log(`✅ ${createDispositionScreenText?.trim()} button is visible after clicking Dispositions.`);

        // Scroll to back button to make it visible
        await this.scrollIntoView(this.backButtonIcon);
        await expect(this.backButtonIcon).toBeVisible({ timeout: 10000 });

        return true;
      } else {
        throw new Error('Dispositions button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyDispositions: ${error.message}`);
      throw error;
    }
  }

  // Verify Disposition Question (converted from your Java method)
  async verifyDispositionQuestion() {
    try {
      console.log('🔍 Verifying Disposition Question...');

      await this.scrollIntoView(this.dispositionQuestion);
      await expect(this.dispositionQuestion).toBeVisible({ timeout: 10000 });
      await expect(this.dispositionQuestion).toBeEnabled({ timeout: 5000 });

      if (await this.dispositionQuestion.isVisible()) {
        await this.dispositionQuestion.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createDispositionQuestion);
        await expect(this.createDispositionQuestion).toBeVisible({ timeout: 10000 });
        await expect(this.createDispositionQuestion).toBeEnabled({ timeout: 5000 });
        const createDispositionQuestionText = await this.createDispositionQuestion.textContent();
        console.log(`✅ ${createDispositionQuestionText?.trim()} button is visible after clicking DispositionQuestion.`);

        return true;
      } else {
        throw new Error('DispositionQuestion button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyDispositionQuestion: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to Disposition Screen and then to System Setup (double back navigation)
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.dispositionScreen).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to Disposition Screen');

        // Second back navigation to System Setup
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Verify Documents (converted from your Java method)
  async verifyDocuments() {
    try {
      console.log('🔍 Verifying Documents...');

      await this.scrollIntoView(this.documents);
      await expect(this.documents).toBeVisible({ timeout: 10000 });
      await expect(this.documents).toBeEnabled({ timeout: 5000 });

      if (await this.documents.isVisible()) {
        await this.documents.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.AddNewDoc);
        await expect(this.AddNewDoc).toBeVisible({ timeout: 10000 });
        const addNewDocumentText = await this.AddNewDoc.textContent();
        console.log(`✅ ${addNewDocumentText?.trim()} button is visible after clicking Documents.`);

        return true;
      } else {
        throw new Error('Documents button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyDocuments: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to System Setup
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Verify Emails (converted from your Java method)
  async verifyEmails() {
    try {
      console.log('🔍 Verifying Emails...');

      // Check if Email is displayed, if not verify Channels first
      if (!(await this.emails.isVisible())) {
        console.log('📧 Email not visible, verifying Channels first...');
        await this.verifyChannels();
      }

      await this.scrollIntoView(this.emails);
      await expect(this.emails).toBeVisible({ timeout: 10000 });
      await expect(this.emails).toBeEnabled({ timeout: 5000 });

      if (await this.emails.isVisible()) {
        await this.emails.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.emailRouting);
        await expect(this.emailRouting).toBeVisible({ timeout: 10000 });
        const emailRoutingText = await this.emailRouting.textContent();
        console.log(`✅ ${emailRoutingText?.trim()} button is visible after clicking Emails.`);

        return true;
      } else {
        throw new Error('Emails button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyEmails: ${error.message}`);
      throw error;
    }
  }

  // Verify Inbound Emails (converted from your Java method)
  async verifyInboundEmails() {
    try {
      console.log('🔍 Verifying Inbound Emails...');

      await this.scrollIntoView(this.inboundEmails);
      await expect(this.inboundEmails).toBeVisible({ timeout: 10000 });
      await expect(this.inboundEmails).toBeEnabled({ timeout: 5000 });

      if (await this.inboundEmails.isVisible()) {
        await this.inboundEmails.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.inboundEmailHeaders);
        await expect(this.inboundEmailHeaders).toBeVisible({ timeout: 10000 });
        const inboundEmailHeadersText = await this.inboundEmailHeaders.textContent();
        console.log(`✅ ${inboundEmailHeadersText?.trim()} button is visible after clicking InboundEmails.`);

        return true;
      } else {
        throw new Error('InboundEmails button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyInboundEmails: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to Email Templates and then to System Setup (double back navigation)
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.emailTemplates).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to Email Templates');

        // Second back navigation to System Setup
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Verify Canned Responses (enhanced with availability check)
  async verifyCannedResponses() {
    try {
      console.log('🔍 Verifying Canned Responses...');

      // Check if Canned Responses element is available
      const cannedResponsesCount = await this.cannedResponses.count();
      if (cannedResponsesCount === 0) {
        console.log('⚠️ Canned Responses element not found on this page');
        return false;
      }

      await this.scrollIntoView(this.cannedResponses);
      await expect(this.cannedResponses).toBeVisible({ timeout: 10000 });
      await expect(this.cannedResponses).toBeEnabled({ timeout: 5000 });

      if (await this.cannedResponses.isVisible()) {
        await this.cannedResponses.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.addCannedResponses);
        await expect(this.addCannedResponses).toBeVisible({ timeout: 10000 });
        const addCannedResponsesText = await this.addCannedResponses.textContent();
        console.log(`✅ ${addCannedResponsesText?.trim()} button is visible after clicking CannedResponses.`);

        return true;
      } else {
        throw new Error('CannedResponses button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyCannedResponses: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to System Setup
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Verify Message Template (enhanced with proper availability check)
  async verifyMessageTemplate() {
    try {
      console.log('🔍 Verifying Message Template...');

      // Check if Message Template element is available first
      const messageTemplateCount = await this.messageTemplate.count();
      if (messageTemplateCount === 0) {
        console.log('⚠️ Message Template element not found on this page');
        return false;
      }

      // Check if the element is visible before trying to interact
      try {
        await expect(this.messageTemplate).toBeVisible({ timeout: 3000 });
      } catch (visibilityError) {
        console.log('⚠️ Message Template element not visible on this page');
        return false;
      }

      await this.scrollIntoView(this.messageTemplate);
      await expect(this.messageTemplate).toBeEnabled({ timeout: 5000 });

      if (await this.messageTemplate.isVisible()) {
        await this.messageTemplate.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        // Check if createMessageTemplate element exists before trying to verify it
        const createTemplateCount = await this.createMessageTemplate.count();
        if (createTemplateCount === 0) {
          console.log('⚠️ Message Template sub-elements not found on this page');
          return false;
        }

        await this.scrollIntoView(this.createMessageTemplate);
        await expect(this.createMessageTemplate).toBeVisible({ timeout: 10000 });
        const createTemplateText = await this.createMessageTemplate.textContent();
        console.log(`✅ ${createTemplateText?.trim()} button is visible after clicking Message Template.`);

        return true;
      } else {
        console.log('⚠️ Message Template button is not visible');
        return false;
      }
    } catch (error) {
      console.log(`⚠️ Message Template verification failed: ${error.message}`);
      return false;
    } finally {
      // Navigate back to System Setup only if we actually clicked on something
      try {
        const systemSetupVisible = await this.systemSetup.isVisible();
        if (!systemSetupVisible) {
          await this.scrollIntoView(this.backButtonIcon);
          await this.backButtonIcon.click();
          await this.page.waitForTimeout(1000);
          console.log('↩️ Navigated back to System Setup');
        }
      } catch (backError) {
        // Silently handle back navigation errors
      }
    }
  }

  // Verify Workflows (enhanced method with proper availability check)
  async verifyWorkflows() {
    try {
      console.log('🔍 Verifying Workflows...');

      // Check if Workflows element is available first
      const workflowsCount = await this.workflows.count();
      if (workflowsCount === 0) {
        console.log('⚠️ Workflows element not found on this page');
        return false;
      }

      // Check if the element is visible before trying to interact
      try {
        await expect(this.workflows).toBeVisible({ timeout: 3000 });
      } catch (visibilityError) {
        console.log('⚠️ Workflows element not visible on this page');
        return false;
      }

      await this.scrollIntoView(this.workflows);
      await expect(this.workflows).toBeEnabled({ timeout: 5000 });

      if (await this.workflows.isVisible()) {
        await this.workflows.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        // Check if createRules element exists before trying to verify it
        const createRulesCount = await this.createRules.count();
        if (createRulesCount === 0) {
          console.log('⚠️ Workflows sub-elements not found on this page');
          return false;
        }

        // Verify main Workflows element
        await this.scrollIntoView(this.createRules);
        await expect(this.createRules).toBeVisible({ timeout: 10000 });
        const createRulesText = await this.createRules.textContent();
        console.log(`✅ ${createRulesText?.trim()} button is visible after clicking Workflows.`);

        // Verify Workflows sub-elements by clicking on each one
        const workflowSubElements = [
          { locator: "//a[contains(text(),'Rules')] | //button[contains(text(),'Rules')] | //label[contains(text(),'Rules')] | //div[contains(text(),'Rules')]", name: "Rules" },
          { locator: "//a[contains(text(),'New Rule')] | //button[contains(text(),'New Rule')] | //label[contains(text(),'New Rule')] | //div[contains(text(),'New Rule')]", name: "New Rule" },
          { locator: "//a[contains(text(),'Create Workflow')] | //button[contains(text(),'Create Workflow')] | //label[contains(text(),'Create Workflow')]", name: "Create Workflow" },
          { locator: "//a[contains(text(),'Workflow Rules')] | //button[contains(text(),'Workflow Rules')] | //label[contains(text(),'Workflow Rules')]", name: "Workflow Rules" },
          { locator: "//a[contains(text(),'Automation')] | //button[contains(text(),'Automation')] | //label[contains(text(),'Automation')]", name: "Automation" }
        ];

        for (const subElement of workflowSubElements) {
          try {
            const element = this.page.locator(subElement.locator).first();
            const count = await element.count();
            if (count > 0) {
              await this.scrollIntoView(element);
              await element.click();
              await this.page.waitForTimeout(2000);
              console.log(`✅ ${subElement.name} clicked successfully in Workflows.`);

              // Capture any errors after clicking
              await this.captureErrorIfPresent();

              // Navigate back using back button
              try {
                await this.scrollIntoView(this.backButtonIcon);
                await this.backButtonIcon.click();
                await this.page.waitForTimeout(1000);
                console.log(`↩️ Navigated back from ${subElement.name} to Workflows`);
              } catch (backError) {
                console.log(`ℹ️ Back button not found for ${subElement.name}, using browser back`);
                await this.page.goBack();
                await this.page.waitForTimeout(1000);
              }
            } else {
              console.log(`⚠️ ${subElement.name} sub-element not found in Workflows.`);
            }
          } catch (error) {
            console.log(`⚠️ ${subElement.name} sub-element click failed: ${error.message}`);
          }
        }

        return true;
      } else {
        console.log('⚠️ Workflows button is not visible');
        return false;
      }
    } catch (error) {
      console.log(`⚠️ Workflows verification failed: ${error.message}`);
      return false;
    } finally {
      // Navigate back to System Setup only if we actually clicked on something
      try {
        const systemSetupVisible = await this.systemSetup.isVisible();
        if (!systemSetupVisible) {
          await this.scrollIntoView(this.backButtonIcon);
          await this.backButtonIcon.click();
          await this.page.waitForTimeout(1000);
          console.log('↩️ Navigated back to System Setup');
        }
      } catch (backError) {
        // Silently handle back navigation errors
      }
    }
  }

  // Verify Channels (enhanced method with proper availability check)
  async verifyChannels() {
    try {
      console.log('🔍 Verifying Channels...');

      // Check if Channels button is available
      const channelsCount = await this.channels.count();
      if (channelsCount === 0) {
        console.log('⚠️ Channels button not found on this page');
        return false;
      }

      // Check if the element is visible before trying to interact
      try {
        await expect(this.channels).toBeVisible({ timeout: 3000 });
      } catch (visibilityError) {
        console.log('⚠️ Channels element not visible on this page');
        return false;
      }

      await this.scrollIntoView(this.channels);
      await expect(this.channels).toBeEnabled({ timeout: 5000 });

      if (await this.channels.isVisible()) {
        await this.channels.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        // Verify channel elements are visible
        await this.scrollIntoView(this.channelsElements);
        await expect(this.channelsElements.first()).toBeVisible({ timeout: 10000 });

        // Get all channel names
        const channelNames = await this.channelsElements.allTextContents();
        console.log(`✅ Channel Names: ${channelNames.join('/')} are visible after expanding Channels.`);

        // Verify Channels sub-elements by clicking on each one
        const channelSubElements = [
          { element: this.phone, name: "Phone", subElements: [
            { element: this.plivoSettings, name: "Plivo Settings" },
            { element: this.setupIVR, name: "Setup IVR" },
            { element: this.plivoPurchasedNum, name: "Plivo Purchased Numbers" },
            { element: this.presetCallerID, name: "Preset Caller ID Management" }
          ]},
          { element: this.sms, name: "SMS", subElements: [
            { element: this.smsProviderSettings, name: "SMS Provider Settings" }
          ]},
          { element: this.email, name: "Email", subElements: [
            { element: this.emailRouting, name: "Email Routing" }
          ]},
          { element: this.webPost, name: "Web Post", subElements: [
            { element: this.newMapping, name: "New Mapping" },
            { element: this.logs, name: "Logs" }
          ]},
          { element: this.whatsAppProvider, name: "WhatsApp", subElements: [
            { element: this.whatsAppProviderSetting, name: "WhatsApp Provider Settings" }
          ]}
        ];

        for (const channel of channelSubElements) {
          try {
            const channelCount = await channel.element.count();
            if (channelCount > 0) {
              // Click on the main channel element
              await this.scrollIntoView(channel.element);
              await channel.element.click();
              await this.page.waitForTimeout(2000);
              console.log(`✅ ${channel.name} channel clicked and expanded successfully.`);

              // Click on each sub-element and verify
              for (const subElement of channel.subElements) {
                try {
                  const subCount = await subElement.element.count();
                  if (subCount > 0) {
                    await this.scrollIntoView(subElement.element);
                    await subElement.element.click();
                    await this.page.waitForTimeout(2000);
                    console.log(`✅ ${subElement.name} clicked successfully in ${channel.name}.`);

                    // Capture any errors after clicking
                    await this.captureErrorIfPresent();

                    // Navigate back using back button
                    try {
                      await this.scrollIntoView(this.backButtonIcon);
                      await this.backButtonIcon.click();
                      await this.page.waitForTimeout(1000);
                      console.log(`↩️ Navigated back from ${subElement.name} to ${channel.name}`);
                    } catch (backError) {
                      console.log(`ℹ️ Back button not found for ${subElement.name}, using browser back`);
                      await this.page.goBack();
                      await this.page.waitForTimeout(1000);
                    }
                  } else {
                    console.log(`⚠️ ${subElement.name} sub-element not found in ${channel.name}.`);
                  }
                } catch (error) {
                  console.log(`⚠️ ${subElement.name} sub-element click failed: ${error.message}`);
                }
              }

              // Navigate back to Channels main page
              try {
                await this.scrollIntoView(this.backButtonIcon);
                await this.backButtonIcon.click();
                await this.page.waitForTimeout(1000);
                console.log(`↩️ Navigated back from ${channel.name} to Channels`);
              } catch (backError) {
                console.log(`ℹ️ Back button not found for ${channel.name}, using browser back`);
                await this.page.goBack();
                await this.page.waitForTimeout(1000);
              }
            } else {
              console.log(`⚠️ ${channel.name} channel not found.`);
            }
          } catch (error) {
            console.log(`⚠️ ${channel.name} channel verification failed: ${error.message}`);
          }
        }

        return true;
      } else {
        console.log('⚠️ Channels button is not visible');
        return false;
      }
    } catch (error) {
      console.log(`⚠️ Channels verification failed: ${error.message}`);
      return false;
    }
  }

  // Verify Manage Account (enhanced method with proper availability check)
  async verifyManageAccount() {
    try {
      console.log('🔍 Verifying Manage Account...');

      // Check if Manage Account button is available
      const manageAccountCount = await this.manageAccount.count();
      if (manageAccountCount === 0) {
        console.log('⚠️ Manage Account button not found on this page');
        return false;
      }

      // Check if the element is visible before trying to interact
      try {
        await expect(this.manageAccount).toBeVisible({ timeout: 3000 });
      } catch (visibilityError) {
        console.log('⚠️ Manage Account element not visible on this page');
        return false;
      }

      await this.scrollIntoView(this.manageAccount);
      await expect(this.manageAccount).toBeEnabled({ timeout: 5000 });

      if (await this.manageAccount.isVisible()) {
        await this.manageAccount.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        // Verify main Manage Account element
        await this.scrollIntoView(this.notifications);
        await expect(this.notifications).toBeVisible({ timeout: 10000 });
        const notificationsText = await this.notifications.textContent();
        console.log(`✅ ${notificationsText?.trim()} button is visible after clicking Manage Account.`);

        // Verify Manage Account sub-elements by clicking on each one
        const manageAccountSubElements = [
          { locator: "//a[contains(text(),'Notifications')] | //button[contains(text(),'Notifications')] | //label[contains(text(),'Notifications')] | //div[contains(text(),'Notifications')]", name: "Notifications" },
          { locator: "//a[contains(text(),'API Access Tokens')] | //button[contains(text(),'API Access Tokens')] | //label[contains(text(),'API Access Tokens')] | //div[contains(text(),'API Access Tokens')]", name: "API Access Tokens" },
          { locator: "//a[contains(text(),'Account Settings')] | //button[contains(text(),'Account Settings')] | //label[contains(text(),'Account Settings')]", name: "Account Settings" },
          { locator: "//a[contains(text(),'User Management')] | //button[contains(text(),'User Management')] | //label[contains(text(),'User Management')]", name: "User Management" },
          { locator: "//a[contains(text(),'Billing')] | //button[contains(text(),'Billing')] | //label[contains(text(),'Billing')]", name: "Billing" },
          { locator: "//a[contains(text(),'Security')] | //button[contains(text(),'Security')] | //label[contains(text(),'Security')]", name: "Security" }
        ];

        for (const subElement of manageAccountSubElements) {
          try {
            const element = this.page.locator(subElement.locator).first();
            const count = await element.count();
            if (count > 0) {
              await this.scrollIntoView(element);
              await element.click();
              await this.page.waitForTimeout(2000);
              console.log(`✅ ${subElement.name} clicked successfully in Manage Account.`);

              // Capture any errors after clicking
              await this.captureErrorIfPresent();

              // Navigate back using back button
              try {
                await this.scrollIntoView(this.backButtonIcon);
                await this.backButtonIcon.click();
                await this.page.waitForTimeout(1000);
                console.log(`↩️ Navigated back from ${subElement.name} to Manage Account`);
              } catch (backError) {
                console.log(`ℹ️ Back button not found for ${subElement.name}, using browser back`);
                await this.page.goBack();
                await this.page.waitForTimeout(1000);
              }
            } else {
              console.log(`⚠️ ${subElement.name} sub-element not found in Manage Account.`);
            }
          } catch (error) {
            console.log(`⚠️ ${subElement.name} sub-element click failed: ${error.message}`);
          }
        }

        return true;
      } else {
        console.log('⚠️ Manage Account button is not visible');
        return false;
      }
    } catch (error) {
      console.log(`⚠️ Manage Account verification failed: ${error.message}`);
      return false;
    } finally {
      // Navigate back to System Setup only if we actually clicked on something
      try {
        const systemSetupVisible = await this.systemSetup.isVisible();
        if (!systemSetupVisible) {
          await this.scrollIntoView(this.backButtonIcon);
          await this.backButtonIcon.click();
          await this.page.waitForTimeout(1000);
          console.log('↩️ Navigated back to System Setup');
        }
      } catch (backError) {
        // Silently handle back navigation errors
      }
    }
  }

  // Verify Tags (converted from your Java method)
  async verifyTags() {
    try {
      console.log('🔍 Verifying Tags...');

      await this.scrollIntoView(this.tags);
      await expect(this.tags).toBeVisible({ timeout: 10000 });
      await expect(this.tags).toBeEnabled({ timeout: 5000 });

      if (await this.tags.isVisible()) {
        await this.tags.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.addNewTag);
        await expect(this.addNewTag).toBeVisible({ timeout: 10000 });
        const addNewTagText = await this.addNewTag.textContent();
        console.log(`✅ ${addNewTagText?.trim()} button is visible after clicking Tags.`);

        return true;
      } else {
        throw new Error('Tags button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyTags: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to System Setup
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Verify WhatsApp (converted from your Java method)
  async verifyWhatsApp() {
    try {
      console.log('🔍 Verifying WhatsApp...');

      await this.scrollIntoView(this.whatsApp);
      await expect(this.whatsApp).toBeVisible({ timeout: 10000 });
      await expect(this.whatsApp).toBeEnabled({ timeout: 5000 });

      if (await this.whatsApp.isVisible()) {
        await this.whatsApp.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.inboundMessages);
        await expect(this.inboundMessages).toBeVisible({ timeout: 10000 });
        const inboundMessagesText = await this.inboundMessages.textContent();
        console.log(`✅ ${inboundMessagesText?.trim()} button is visible after clicking WhatsApp.`);

        // Scroll to back button to make it visible
        await this.scrollIntoView(this.backButtonIcon);
        await expect(this.backButtonIcon).toBeVisible({ timeout: 10000 });

        return true;
      } else {
        throw new Error('WhatsApp button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyWhatsApp: ${error.message}`);
      throw error;
    }
  }

  // Verify WhatsApp Templates (converted from your Java method)
  async verifyWhatsAppTemplates() {
    try {
      console.log('🔍 Verifying WhatsApp Templates...');

      await this.scrollIntoView(this.templates);
      await expect(this.templates).toBeVisible({ timeout: 10000 });
      await expect(this.templates).toBeEnabled({ timeout: 5000 });

      if (await this.templates.isVisible()) {
        await this.templates.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createTemplates);
        await expect(this.createTemplates).toBeVisible({ timeout: 10000 });
        const createTemplatesText = await this.createTemplates.textContent();
        console.log(`✅ ${createTemplatesText?.trim()} button is visible after clicking Templates.`);

        return true;
      } else {
        throw new Error('Templates button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyWhatsAppTemplates: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to Inbound Messages and then to System Setup (double back navigation)
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.inboundMessages).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to Inbound Messages');

        // Second back navigation to System Setup
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Verify Workflow (converted from your Java method)
  async verifyWorkflow() {
    try {
      console.log('🔍 Verifying Workflow...');

      await this.scrollIntoView(this.workflows);
      await expect(this.workflows).toBeVisible({ timeout: 10000 });
      await expect(this.workflows).toBeEnabled({ timeout: 5000 });

      if (await this.workflows.isVisible()) {
        await this.workflows.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createRules);
        await expect(this.createRules).toBeVisible({ timeout: 10000 });
        const createRulesText = await this.createRules.textContent();
        console.log(`✅ ${createRulesText?.trim()} button is visible after clicking Workflows.`);

        return true;
      } else {
        throw new Error('Workflows button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyWorkflow: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to System Setup
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Verify Channels (converted from your Java method)
  async verifyChannels() {
    try {
      console.log('🔍 Verifying Channels...');

      await this.scrollIntoView(this.channels);
      await expect(this.channels).toBeVisible({ timeout: 10000 });

      if (await this.channels.isVisible()) {
        await this.channels.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        // Wait for all channel elements to be visible
        await expect(this.channelsElements.first()).toBeVisible({ timeout: 10000 });
        const channelElements = await this.channelsElements.all();

        // Verify each channel element is displayed
        for (const channelElement of channelElements) {
          await expect(channelElement).toBeVisible();
          const channelText = await channelElement.textContent();
          console.log(`✅ Channel Name: ${channelText?.trim()} is visible after expanding Channels.`);
        }

        return true;
      } else {
        throw new Error('Channels button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyChannels: ${error.message}`);
      throw error;
    }
  }

  // Verify Phone (converted from your Java method)
  async verifyPhone() {
    try {
      console.log('🔍 Verifying Phone...');

      // Check if Phone is displayed, if not verify Channels first
      if (!(await this.phone.isVisible())) {
        console.log('📞 Phone not visible, verifying Channels first...');
        await this.verifyChannels();
      }

      await this.scrollIntoView(this.phone);
      await expect(this.phone).toBeVisible({ timeout: 10000 });
      await expect(this.phone).toBeEnabled({ timeout: 5000 });

      if (await this.phone.isVisible()) {
        await this.phone.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.providerSettings);
        await expect(this.providerSettings).toBeVisible({ timeout: 10000 });
        const providerSettingsText = await this.providerSettings.textContent();
        console.log(`✅ ${providerSettingsText?.trim()} buttons are visible after clicking Phone.`);

        return true;
      } else {
        throw new Error('ProviderSettings button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyPhone: ${error.message}`);
      throw error;
    }
  }

  // Verify Plivo Settings (converted from your Java method)
  async verifyPlivoSettings() {
    try {
      console.log('🔍 Verifying Plivo Settings...');

      await this.scrollIntoView(this.plivoSettings);
      await expect(this.plivoSettings).toBeVisible({ timeout: 10000 });

      if (await this.plivoSettings.isVisible()) {
        await this.plivoSettings.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.voicemail);
        await expect(this.voicemail).toBeVisible({ timeout: 10000 });
        console.log(`✅ Voicemail button is visible after expanding PlivoSettings.`);

        return true;
      } else {
        throw new Error('PlivoSettings button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyPlivoSettings: ${error.message}`);
      throw error;
    }
  }

  // Verify Setup IVR (converted from your Java method)
  async verifySetupIVR() {
    try {
      console.log('🔍 Verifying Setup IVR...');

      await this.scrollIntoView(this.setupIVR);
      await expect(this.setupIVR).toBeVisible({ timeout: 10000 });
      await expect(this.setupIVR).toBeEnabled({ timeout: 5000 });

      if (await this.setupIVR.isVisible()) {
        await this.setupIVR.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createNewIVR);
        await expect(this.createNewIVR).toBeVisible({ timeout: 10000 });
        await expect(this.createNewIVR).toBeEnabled({ timeout: 5000 });
        const createNewIVRText = await this.createNewIVR.textContent();
        console.log(`✅ ${createNewIVRText?.trim()} button is visible after click on SetupIVR.`);

        return true;
      } else {
        throw new Error('SetupIVR button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifySetupIVR: ${error.message}`);
      throw error;
    } finally {
      // Navigate back
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        console.log('↩️ Navigated back from Setup IVR');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Click on Setup IVR (converted from your Java method)
  async clickOnSetupIVR() {
    try {
      console.log('🖱️ Clicking on Setup IVR...');

      await this.scrollIntoView(this.setupIVR);
      await expect(this.setupIVR).toBeVisible({ timeout: 10000 });
      await expect(this.setupIVR).toBeEnabled({ timeout: 5000 });

      if (await this.setupIVR.isVisible()) {
        await this.setupIVR.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.createNewIVR);
        await expect(this.createNewIVR).toBeVisible({ timeout: 10000 });
        await expect(this.createNewIVR).toBeEnabled({ timeout: 5000 });
        const createNewIVRText = await this.createNewIVR.textContent();
        console.log(`✅ ${createNewIVRText?.trim()} button is visible after click on SetupIVR.`);

        return true;
      } else {
        throw new Error('SetupIVR button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in ClickOnSetupIVR: ${error.message}`);
      throw error;
    }
  }

  // Create IVR (converted from your Java method)
  async createIVR(ivrName) {
    try {
      console.log(`🆕 Creating IVR: ${ivrName}`);

      const expectedMessage = "Success\nIVR created successfully";

      await this.scrollIntoView(this.createNewIVR);
      await expect(this.createNewIVR).toBeVisible({ timeout: 10000 });
      await expect(this.createNewIVR).toBeEnabled({ timeout: 5000 });

      if (await this.setupIVR.isVisible()) {
        await this.createNewIVR.click();
        await this.page.waitForTimeout(1000);

        await this.ivrName.fill(ivrName);

        await this.scrollIntoView(this.createButton);
        await this.createButton.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        // Verify success message
        await expect(this.successMessage).toBeVisible({ timeout: 10000 });
        const actualMessageDisplayed = await this.successMessage.textContent();
        const actualMessage = actualMessageDisplayed?.trim() || '';

        if (!actualMessage.includes(expectedMessage)) {
          throw new Error(`IVR creation success message validation failed. Expected to contain: '${expectedMessage}', but found: '${actualMessage}'`);
        }

        console.log(`✅ IVR '${ivrName}' created successfully`);

        // Toggle recording
        await this.toggleRecording();

        return true;
      } else {
        const errorMessage = await this.successMessage.textContent();
        throw new Error(`Error: ${errorMessage?.trim()}`);
      }
    } catch (error) {
      console.error(`❌ Exception occurred in CreateIVR: ${error.message}`);
      throw error;
    }
  }

  // Verify Enable IVR (converted from your Java method)
  async verifyEnableIVR() {
    try {
      console.log('🔍 Verifying Enable IVR toggle...');

      await this.scrollIntoView(this.toggleLabel);
      await expect(this.toggleLabel).toBeVisible({ timeout: 10000 });

      const isChecked = await this.toggleInput.isChecked();
      const expectedStateText = isChecked ?
        await this.toggleLabel.getAttribute("data-on") :
        await this.toggleLabel.getAttribute("data-off");
      const actualStateText = (await this.toggleLabel.textContent())?.trim();

      console.log(`Expected Toggle State: ${expectedStateText}`);
      console.log(`Actual Toggle State: ${actualStateText}`);

      if (actualStateText !== expectedStateText) {
        throw new Error(`Enable IVR toggle state verification failed. Expected: '${expectedStateText}', but found: '${actualStateText}'`);
      }

      console.log('✅ Enable IVR toggle state verified successfully');
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred while verifying Enable IVR state: ${error.message}`);
      throw error;
    }
  }

  // Toggle Recording (converted from your Java method)
  async toggleRecording() {
    try {
      console.log('🎙️ Toggling recording...');

      await this.scrollIntoView(this.recordingCheckboxIndicator);
      await expect(this.recordingCheckboxIndicator).toBeVisible({ timeout: 10000 });
      await this.recordingCheckboxIndicator.click();

      console.log('✅ Recording toggle clicked.');
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred while toggling recording: ${error.message}`);
      throw error;
    }
  }

  // Select Plivo Number (converted from your Java method)
  async selectPlivoNumber(plivoNumber) {
    try {
      console.log(`📞 Selecting Plivo number: ${plivoNumber}`);

      await expect(this.ivrNumberDropDown).toBeVisible({ timeout: 10000 });

      // Get all available options
      const options = await this.ivrNumberDropDown.locator('option').all();
      const availableNumbers = [];

      for (const option of options) {
        const text = await option.textContent();
        if (text) {
          availableNumbers.push(text.trim());
        }
      }

      console.log(`Available numbers: ${availableNumbers.join(', ')}`);

      if (availableNumbers.includes(plivoNumber)) {
        await this.ivrNumberDropDown.selectOption({ label: plivoNumber });
        await expect(this.addNumberButton).toBeEnabled({ timeout: 5000 });
        await this.addNumberButton.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        // Verify the number was added
        const addedNumberLocator = this.page.locator(`//div[normalize-space()='${plivoNumber}']`);
        await expect(addedNumberLocator).toBeVisible({ timeout: 10000 });
        const verifiedNumber = await addedNumberLocator.textContent();

        if (!availableNumbers.includes(plivoNumber)) {
          throw new Error(`The new Plivo number '${plivoNumber}' is not available in the dropdown list.`);
        }

        console.log(`✅ Plivo number '${plivoNumber}' selected and added successfully`);
        return true;
      } else {
        throw new Error(`Plivo number '${plivoNumber}' not found in available options: ${availableNumbers.join(', ')}`);
      }
    } catch (error) {
      console.error(`❌ Exception occurred in selectPlivoNumber: ${error.message}`);
      throw error;
    }
  }

  // Select Welcome File (converted from your Java method)
  async selectWelcomeFile(welcomeFile) {
    try {
      console.log(`🎵 Selecting welcome file: ${welcomeFile}`);

      await expect(this.welcomeMessage).toBeVisible({ timeout: 10000 });

      // Get all available options
      const options = await this.welcomeMessage.locator('option').all();
      const availableWelcomeFiles = [];

      for (const option of options) {
        const text = await option.textContent();
        if (text) {
          availableWelcomeFiles.push(text.trim());
        }
      }

      console.log(`Available welcome files: ${availableWelcomeFiles.join(', ')}`);

      if (availableWelcomeFiles.includes(welcomeFile)) {
        await this.welcomeMessage.selectOption({ label: welcomeFile });

        // Verify selection
        const selectedOption = await this.welcomeMessage.locator('option:checked').textContent();
        const verifiedWelcomeFile = selectedOption?.trim() || '';

        if (!verifiedWelcomeFile.includes(welcomeFile)) {
          throw new Error(`Welcome File '${welcomeFile}' selection verification failed`);
        }

        console.log(`✅ Welcome File '${welcomeFile}' selected successfully`);
        return true;
      } else {
        throw new Error(`Welcome file '${welcomeFile}' not found in available options: ${availableWelcomeFiles.join(', ')}`);
      }
    } catch (error) {
      console.error(`❌ Exception occurred in selectWelcomeFile: ${error.message}`);
      throw error;
    }
  }

  // Select Music on Hold (converted from your Java method)
  async selectMusicOnHold(holdMusic) {
    try {
      console.log(`🎵 Selecting music on hold: ${holdMusic}`);

      await expect(this.musicOnHold).toBeVisible({ timeout: 10000 });

      // Get all available options
      const options = await this.musicOnHold.locator('option').all();
      const availableHoldMusic = [];

      for (const option of options) {
        const text = await option.textContent();
        if (text) {
          availableHoldMusic.push(text.trim());
        }
      }

      console.log(`Available hold music: ${availableHoldMusic.join(', ')}`);

      if (availableHoldMusic.includes(holdMusic)) {
        await this.musicOnHold.selectOption({ label: holdMusic });

        // Verify selection
        const selectedOption = await this.musicOnHold.locator('option:checked').textContent();
        const verifiedHoldMusicFile = selectedOption?.trim() || '';

        if (!verifiedHoldMusicFile.includes(holdMusic)) {
          throw new Error(`Hold Music '${holdMusic}' selection verification failed`);
        }

        // Save the settings
        await this.scrollIntoView(this.saveWelHold);
        await this.saveWelHold.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors after saving
        await this.captureErrorIfPresent();

        console.log(`✅ Music on Hold '${holdMusic}' selected and saved successfully`);
        return true;
      } else {
        throw new Error(`Hold music '${holdMusic}' not found in available options: ${availableHoldMusic.join(', ')}`);
      }
    } catch (error) {
      console.error(`❌ Exception occurred in selectMusicOnHold: ${error.message}`);
      throw error;
    }
  }

  // Select Working Days (converted from your Java method)
  async selectWorkingDays(fromDay, toDay) {
    try {
      console.log(`📅 Selecting working days: ${fromDay} to ${toDay}`);

      // Select start day
      await expect(this.startDay).toBeVisible({ timeout: 10000 });

      const fromOptions = await this.startDay.locator('option').all();
      const availableFromDays = [];

      for (const option of fromOptions) {
        const text = await option.textContent();
        if (text) {
          availableFromDays.push(text.trim());
        }
      }

      if (availableFromDays.includes(fromDay)) {
        await this.startDay.selectOption({ label: fromDay });

        const selectedFromOption = await this.startDay.locator('option:checked').textContent();
        const verifiedFromDay = selectedFromOption?.trim() || '';

        if (!verifiedFromDay.includes(fromDay)) {
          throw new Error(`From day '${fromDay}' selection verification failed`);
        }

        console.log(`✅ ${verifiedFromDay} is selected as start day`);
      } else {
        throw new Error(`From day '${fromDay}' not found in available options: ${availableFromDays.join(', ')}`);
      }

      // Select end day
      await expect(this.finishDay).toBeVisible({ timeout: 10000 });

      const toOptions = await this.finishDay.locator('option').all();
      const availableToDays = [];

      for (const option of toOptions) {
        const text = await option.textContent();
        if (text) {
          availableToDays.push(text.trim());
        }
      }

      if (availableToDays.includes(toDay)) {
        await this.finishDay.selectOption({ label: toDay });

        const selectedToOption = await this.finishDay.locator('option:checked').textContent();
        const verifiedToDay = selectedToOption?.trim() || '';

        if (!verifiedToDay.includes(toDay)) {
          throw new Error(`To day '${toDay}' selection verification failed`);
        }

        console.log(`✅ ${verifiedToDay} is selected as end day`);
      } else {
        throw new Error(`To day '${toDay}' not found in available options: ${availableToDays.join(', ')}`);
      }

      console.log(`✅ Working days selected: ${fromDay} to ${toDay}`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in selectWorkingDays: ${error.message}`);
      throw error;
    }
  }

  // Set Time (converted from your Java method)
  async setTime(fromTimeRaw, toTimeRaw) {
    try {
      console.log(`⏰ Setting time: ${fromTimeRaw} to ${toTimeRaw}`);

      await this.setTimeValue(this.startTime, this.fromHrs, this.fromMin, this.fromToggle, fromTimeRaw);
      await this.setTimeValue(this.endTime, this.toHrs, this.toMin, this.toToggle, toTimeRaw);

      console.log(`✅ Time set successfully: ${fromTimeRaw} to ${toTimeRaw}`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in setTime: ${error.message}`);
      throw error;
    }
  }

  // Helper method to set individual time values (converted from your Java method)
  async setTimeValue(timeField, hourField, minuteField, ampmToggle, rawTime) {
    try {
      // Convert Excel time (e.g. "14:00:00") → "02:00 PM"
      const time12h = this.convertTo12Hour(rawTime);
      const parts = time12h.split(" ");
      const timeParts = parts[0].split(":");
      const hour = timeParts[0];
      const minute = timeParts[1];
      const ampm = parts[1];

      await this.scrollIntoView(timeField);
      await expect(timeField).toBeEnabled({ timeout: 10000 });
      await timeField.click();

      await expect(hourField).toBeVisible({ timeout: 5000 });
      await hourField.press('Backspace');
      await hourField.fill(hour);
      await hourField.press('Tab');

      await expect(minuteField).toBeVisible({ timeout: 5000 });
      await minuteField.press('Backspace');
      await minuteField.fill(minute);
      await minuteField.press('Tab');

      const currentAmPm = await ampmToggle.textContent();
      if (currentAmPm?.trim().toUpperCase() !== ampm.toUpperCase()) {
        await ampmToggle.click();
        await this.page.waitForTimeout(500);
      }

      // Save and close by clicking body
      await this.body.click();
      await this.page.waitForTimeout(500);

      console.log(`✅ Time value set: ${rawTime} → ${time12h}`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in setTimeValue: ${error.message}`);
      throw error;
    }
  }

  // Helper method to convert 24-hour to 12-hour format (converted from your Java method)
  convertTo12Hour(time24h) {
    try {
      // Parse time like "14:00:00" or "14:00"
      const timeParts = time24h.split(':');
      let hours = parseInt(timeParts[0]);
      const minutes = timeParts[1] || '00';

      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12; // 0 should be 12

      const formattedHours = hours.toString().padStart(2, '0');
      return `${formattedHours}:${minutes} ${ampm}`;
    } catch (error) {
      throw new Error(`Time conversion failed: ${time24h} - ${error.message}`);
    }
  }

  // Select Time Matches (converted from your Java method)
  async selectTimeMatches(timeMatches) {
    try {
      console.log(`⏰ Selecting time matches: ${timeMatches}`);

      await expect(this.timeMatch).toBeVisible({ timeout: 10000 });

      // Get all available options
      const options = await this.timeMatch.locator('option').all();
      const availableTimeMatches = [];

      for (const option of options) {
        const text = await option.textContent();
        if (text) {
          availableTimeMatches.push(text.trim());
        }
      }

      console.log(`Available time matches: ${availableTimeMatches.join(', ')}`);

      if (availableTimeMatches.includes(timeMatches)) {
        await this.timeMatch.selectOption({ label: timeMatches });

        // Verify selection
        const selectedOption = await this.timeMatch.locator('option:checked').textContent();
        const verifiedTimeMatch = selectedOption?.trim() || '';

        if (!verifiedTimeMatch.includes(timeMatches)) {
          throw new Error(`Time matches '${timeMatches}' selection verification failed`);
        }

        console.log(`✅ Time matches '${timeMatches}' selected successfully`);
        return true;
      } else {
        throw new Error(`Time matches '${timeMatches}' not found in available options: ${availableTimeMatches.join(', ')}`);
      }
    } catch (error) {
      console.error(`❌ Exception occurred in selectTimeMatches: ${error.message}`);
      throw error;
    }
  }

  // Select Time Not Matches (converted from your Java method)
  async selectTimeNotMatches(timeNotMatches) {
    try {
      console.log(`⏰ Selecting time not matches: ${timeNotMatches}`);

      await expect(this.timeNotMatch).toBeVisible({ timeout: 10000 });

      // Get all available options
      const options = await this.timeNotMatch.locator('option').all();
      const availableTimeNotMatches = [];

      for (const option of options) {
        const text = await option.textContent();
        if (text) {
          availableTimeNotMatches.push(text.trim());
        }
      }

      console.log(`Available time not matches: ${availableTimeNotMatches.join(', ')}`);

      if (availableTimeNotMatches.includes(timeNotMatches)) {
        await this.timeNotMatch.selectOption({ label: timeNotMatches });

        // Verify selection
        const selectedOption = await this.timeNotMatch.locator('option:checked').textContent();
        const verifiedTimeNotMatch = selectedOption?.trim() || '';

        if (!verifiedTimeNotMatch.includes(timeNotMatches)) {
          throw new Error(`Time not matches '${timeNotMatches}' selection verification failed`);
        }

        console.log(`✅ Time not matches '${timeNotMatches}' selected successfully`);
        return true;
      } else {
        throw new Error(`Time not matches '${timeNotMatches}' not found in available options: ${availableTimeNotMatches.join(', ')}`);
      }
    } catch (error) {
      console.error(`❌ Exception occurred in selectTimeNotMatches: ${error.message}`);
      throw error;
    }
  }

  // Save Office Hour (converted from your Java method)
  async saveOfficeHour() {
    try {
      console.log('💾 Saving office hour...');

      await this.scrollIntoView(this.saveOfficeHour);
      await expect(this.saveOfficeHour).toBeEnabled({ timeout: 10000 });
      await this.saveOfficeHour.click();
      await this.page.waitForTimeout(2000);

      console.log('✅ Office hour saved successfully');
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in saveOfficeHour: ${error.message}`);
      throw error;
    }
  }

  // Verify Enable Night Mode (converted from your Java method)
  async verifyEnableNightMode() {
    try {
      console.log('🌙 Verifying Enable Night Mode toggle...');

      await this.scrollIntoView(this.toggleLabelNM);
      await expect(this.toggleLabelNM).toBeVisible({ timeout: 10000 });

      const isChecked = await this.toggleInputNM.isChecked();
      const expectedStateText = isChecked ?
        await this.toggleLabelNM.getAttribute("data-on") :
        await this.toggleLabelNM.getAttribute("data-off");
      const actualStateText = (await this.toggleLabelNM.textContent())?.trim();

      console.log(`Expected Night Mode Toggle State: ${expectedStateText}`);
      console.log(`Actual Night Mode Toggle State: ${actualStateText}`);

      if (actualStateText !== expectedStateText) {
        throw new Error(`Enable Night Mode toggle state verification failed. Expected: '${expectedStateText}', but found: '${actualStateText}'`);
      }

      console.log('✅ Enable Night Mode toggle state verified successfully');
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred while verifying Enable Night Mode state: ${error.message}`);
      throw error;
    }
  }

  // Add Sub Items (converted from your Java method)
  async addSubItems(voicePrompt, queue) {
    try {
      console.log(`🌳 Adding sub items - Voice Prompt: ${voicePrompt}, Queue: ${queue}`);

      let dynamicXpath = '';
      let elementName = '';

      // Click Add Sub Item button
      try {
        await expect(this.addSubItem).toBeEnabled({ timeout: 10000 });
        await this.addSubItem.click();
        await expect(this.selectNodeTypeScreen).toBeVisible({ timeout: 10000 });
        console.log('✅ Add Sub Item button clicked and selection screen visible');
      } catch (error) {
        console.error(`❌ Failed to click 'Add Sub Item' button or wait for selection screen: ${error.message}`);
        throw new Error(`Pre-requisite for AddSubitems failed: ${error.message}`);
      }

      // Determine which element to click based on parameters
      if (voicePrompt && voicePrompt.trim() !== '') {
        dynamicXpath = `//label[@class='radio-inline'][normalize-space()='${voicePrompt.trim()}']`;
        elementName = `Voice Prompt Type: ${voicePrompt}`;
      } else if (queue && queue.trim() !== '') {
        dynamicXpath = `//label[normalize-space()='${queue.trim()}']`;
        elementName = `Queue Type: ${queue}`;
      } else {
        throw new Error("Both 'voicePrompt' and 'queue' parameters are empty or null. Cannot select sub-item type.");
      }

      // Click the determined element
      try {
        const elementToClick = this.page.locator(dynamicXpath);
        await expect(elementToClick).toBeEnabled({ timeout: 10000 });
        await elementToClick.click();
        await this.page.waitForTimeout(1000);

        console.log(`✅ ${elementName} selected successfully`);
        return true;
      } catch (error) {
        console.error(`❌ Exception occurred while trying to click ${elementName}: ${error.message}`);
        throw new Error(`Failed to click ${elementName}: ${error.message}`);
      }
    } catch (error) {
      console.error(`❌ Exception occurred in addSubItems: ${error.message}`);
      throw error;
    }
  }

  // Create Voice Prompt (converted from your Java method)
  async createVP(promptName, keyValue, fileName) {
    try {
      console.log(`🎤 Creating Voice Prompt: ${promptName}, Key: ${keyValue}, File: ${fileName}`);

      // Fill prompt name
      await expect(this.voicePrompt).toBeEnabled({ timeout: 10000 });
      await this.voicePrompt.fill(promptName);

      // Handle Key Press selection
      const keyPressEnabled = await this.keyPress.isEnabled();
      if (!keyPressEnabled) {
        console.log('⚠️ Key Press field is disabled');
      } else {
        // Get all available key options
        const keyOptions = await this.keyPress.locator('option').all();
        const availableKeys = [];

        for (const option of keyOptions) {
          const text = await option.textContent();
          if (text) {
            availableKeys.push(text.trim());
          }
        }

        console.log(`Available keys: ${availableKeys.join(', ')}`);

        if (availableKeys.includes(keyValue)) {
          await this.keyPress.selectOption({ label: keyValue });

          // Verify selection
          const selectedKeyOption = await this.keyPress.locator('option:checked').textContent();
          const verifiedKeyValue = selectedKeyOption?.trim() || '';

          if (!verifiedKeyValue.includes(keyValue)) {
            throw new Error(`Key value '${keyValue}' selection verification failed`);
          }

          console.log(`✅ ${verifiedKeyValue} is selected as key`);
        } else {
          throw new Error(`Key value '${keyValue}' not found in available options: ${availableKeys.join(', ')}`);
        }
      }

      // Select current file
      await expect(this.currentFile).toBeVisible({ timeout: 10000 });

      const fileOptions = await this.currentFile.locator('option').all();
      const availableFiles = [];

      for (const option of fileOptions) {
        const text = await option.textContent();
        if (text) {
          availableFiles.push(text.trim());
        }
      }

      console.log(`Available files: ${availableFiles.join(', ')}`);

      if (availableFiles.includes(fileName)) {
        await this.currentFile.selectOption({ label: fileName });

        // Verify selection
        const selectedFileOption = await this.currentFile.locator('option:checked').textContent();
        const verifiedSelectedFile = selectedFileOption?.trim() || '';

        if (!verifiedSelectedFile.includes(fileName)) {
          throw new Error(`File name '${fileName}' selection verification failed`);
        }

        console.log(`✅ ${verifiedSelectedFile} is selected as file`);
      } else {
        throw new Error(`File name '${fileName}' not found in available options: ${availableFiles.join(', ')}`);
      }

      // Enable Voice Prompt
      await expect(this.enablePrompt).toBeEnabled({ timeout: 10000 });
      await this.enablePrompt.click();
      console.log('✅ Voice Prompt enabled');

      // Save Voice Prompt
      await expect(this.savePrompt).toBeEnabled({ timeout: 10000 });
      await this.savePrompt.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors
      await this.captureErrorIfPresent();

      // Scroll to IVR Tree
      await this.scrollIntoView(this.ivrTree);
      await expect(this.ivrTree).toBeVisible({ timeout: 10000 });

      console.log(`✅ Voice Prompt '${promptName}' created successfully`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in createVP: ${error.message}`);
      throw error;
    }
  }

  // Edit IVR (converted from your Java method)
  async editIVR() {
    try {
      console.log('✏️ Editing IVR...');

      await expect(this.editIVR).toBeEnabled({ timeout: 10000 });
      await this.editIVR.click();
      await this.page.waitForTimeout(2000);

      console.log('✅ IVR edit mode activated');
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in editIVR: ${error.message}`);
      throw error;
    }
  }

  // Verify Plivo Purchased Numbers (converted from your Java method)
  async verifyPlivoPurchasedNumbers() {
    try {
      console.log('🔍 Verifying Plivo Purchased Numbers...');

      await this.scrollIntoView(this.plivoPurchasedNum);
      await expect(this.plivoPurchasedNum).toBeVisible({ timeout: 10000 });
      await expect(this.plivoPurchasedNum).toBeEnabled({ timeout: 5000 });

      if (await this.plivoPurchasedNum.isVisible()) {
        await this.plivoPurchasedNum.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.number);
        await expect(this.number).toBeVisible({ timeout: 10000 });
        await expect(this.number).toBeEnabled({ timeout: 5000 });
        const numberText = await this.number.textContent();
        console.log(`✅ ${numberText?.trim()} button is visible after click on PlivoPurchasedNum.`);

        return true;
      } else {
        throw new Error('PlivoPurchasedNum button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyPlivoPurchasedNumbers: ${error.message}`);
      throw error;
    } finally {
      // Navigate back
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        console.log('↩️ Navigated back from Plivo Purchased Numbers');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Verify Preset Caller ID Management (converted from your Java method)
  async verifyPresetCallerIdManagement() {
    try {
      console.log('🔍 Verifying Preset Caller ID Management...');

      await this.scrollIntoView(this.presetCallerID);
      await expect(this.presetCallerID).toBeVisible({ timeout: 10000 });
      await expect(this.presetCallerID).toBeEnabled({ timeout: 5000 });

      if (await this.presetCallerID.isVisible()) {
        await this.presetCallerID.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.addPreset);
        await expect(this.addPreset).toBeVisible({ timeout: 10000 });
        await expect(this.addPreset).toBeEnabled({ timeout: 5000 });
        const addPresetText = await this.addPreset.textContent();
        console.log(`✅ ${addPresetText?.trim()} button is visible after expanding PresetCallerID.`);

        return true;
      } else {
        throw new Error('PlivoSettings button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyPresetCallerIdManagement: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to System Setup (double back navigation)
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await this.page.waitForTimeout(1000);

        await this.scrollIntoView(this.systemSetup);
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Verify SMS (converted from your Java method)
  async verifySMS() {
    try {
      console.log('🔍 Verifying SMS...');

      // Check if SMS is displayed, if not verify Channels first
      if (!(await this.sms.isVisible())) {
        console.log('📱 SMS not visible, verifying Channels first...');
        await this.verifyChannels();
      }

      await this.scrollIntoView(this.sms);
      await expect(this.sms).toBeVisible({ timeout: 10000 });
      await expect(this.sms).toBeEnabled({ timeout: 5000 });

      if (await this.sms.isVisible()) {
        await this.sms.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.smsProviderSettings);
        await expect(this.smsProviderSettings).toBeVisible({ timeout: 10000 });
        const smsProviderSettingsText = await this.smsProviderSettings.textContent();
        console.log(`✅ ${smsProviderSettingsText?.trim()} buttons are visible after clicking SMS.`);

        return true;
      } else {
        throw new Error('SMS button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifySMS: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to System Setup
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await this.scrollIntoView(this.systemSetup);
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Verify Email Routing (converted from your Java method)
  async verifyEmailRouting() {
    try {
      console.log('🔍 Verifying Email Routing...');

      // Check if Email is displayed, if not verify Channels first
      if (!(await this.email.isVisible())) {
        console.log('📧 Email not visible, verifying Channels first...');
        await this.verifyChannels();
      }

      await this.scrollIntoView(this.email);
      await expect(this.email).toBeVisible({ timeout: 10000 });
      await expect(this.email).toBeEnabled({ timeout: 5000 });

      if (await this.email.isVisible()) {
        await this.email.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.emailRouting);
        await expect(this.emailRouting).toBeVisible({ timeout: 10000 });
        const emailRoutingText = await this.emailRouting.textContent();
        console.log(`✅ ${emailRoutingText?.trim()} buttons are visible after clicking Email.`);

        return true;
      } else {
        throw new Error('Email button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyEmailRouting: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to System Setup
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await this.scrollIntoView(this.systemSetup);
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Verify Web Post (converted from your Java method)
  async verifyWebPost() {
    try {
      console.log('🔍 Verifying Web Post...');

      // Check if Web Post is displayed, if not verify Channels first
      if (!(await this.webPost.isVisible())) {
        console.log('🌐 Web Post not visible, verifying Channels first...');
        await this.verifyChannels();
      }

      await this.scrollIntoView(this.webPost);
      await expect(this.webPost).toBeVisible({ timeout: 10000 });
      await expect(this.webPost).toBeEnabled({ timeout: 5000 });

      if (await this.webPost.isVisible()) {
        await this.webPost.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.newMapping);
        await expect(this.newMapping).toBeVisible({ timeout: 10000 });
        const newMappingText = await this.newMapping.textContent();
        console.log(`✅ ${newMappingText?.trim()} buttons are visible after clicking WebPost.`);

        return true;
      } else {
        throw new Error('WebPost button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyWebPost: ${error.message}`);
      throw error;
    }
  }

  // Verify Logs (converted from your Java method)
  async verifyLogs() {
    try {
      console.log('🔍 Verifying Logs...');

      await this.scrollIntoView(this.logs);
      await expect(this.logs).toBeVisible({ timeout: 10000 });
      await expect(this.logs).toBeEnabled({ timeout: 5000 });

      if (await this.logs.isVisible()) {
        await this.logs.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.logCriteria);
        await expect(this.logCriteria).toBeVisible({ timeout: 10000 });
        const logCriteriaText = await this.logCriteria.textContent();
        console.log(`✅ ${logCriteriaText?.trim()} buttons are visible after clicking Logs.`);

        return true;
      } else {
        throw new Error('Logs button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyLogs: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to Web Post and then to System Setup (double back navigation)
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await expect(this.newMapping).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to Web Post');

        // Second back navigation to System Setup
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await this.scrollIntoView(this.systemSetup);
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Verify WhatsApp Provider (converted from your Java method)
  async verifyWhatsAppProvider() {
    try {
      console.log('🔍 Verifying WhatsApp Provider...');

      // Check if WhatsApp Provider is displayed, if not verify Channels first
      if (!(await this.whatsAppProvider.isVisible())) {
        console.log('💬 WhatsApp Provider not visible, verifying Channels first...');
        await this.verifyChannels();
      }

      await this.scrollIntoView(this.whatsAppProvider);
      await expect(this.whatsAppProvider).toBeVisible({ timeout: 10000 });
      await expect(this.whatsAppProvider).toBeEnabled({ timeout: 5000 });

      if (await this.whatsAppProvider.isVisible()) {
        await this.whatsAppProvider.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.whatsAppProviderSetting);
        await expect(this.whatsAppProviderSetting).toBeVisible({ timeout: 10000 });
        const whatsAppProviderSettingText = await this.whatsAppProviderSetting.textContent();
        console.log(`✅ ${whatsAppProviderSettingText?.trim()} buttons are visible after clicking WhatsAppProvider.`);

        return true;
      } else {
        throw new Error('WhatsAppProvider button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyWhatsAppProvider: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to System Setup
      try {
        await this.scrollIntoView(this.backButtonIcon);
        await this.backButtonIcon.click();
        await this.scrollIntoView(this.systemSetup);
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Verify Manage Account (converted from your Java method)
  async verifyManageAccount() {
    try {
      console.log('🔍 Verifying Manage Account...');

      await this.scrollIntoView(this.manageAccount);
      await expect(this.manageAccount).toBeVisible({ timeout: 10000 });
      await expect(this.manageAccount).toBeEnabled({ timeout: 5000 });

      if (await this.manageAccount.isVisible()) {
        await this.manageAccount.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await this.scrollIntoView(this.notifications);
        await expect(this.notifications).toBeVisible({ timeout: 10000 });
        const notificationsText = await this.notifications.textContent();
        console.log(`✅ ${notificationsText?.trim()} buttons are visible after expanding ManageAccount.`);

        return true;
      } else {
        throw new Error('ManageAccount button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyManageAccount: ${error.message}`);
      throw error;
    }
  }

  // Verify Notifications (converted from your Java method)
  async verifyNotifications() {
    try {
      console.log('🔍 Verifying Notifications...');

      await this.scrollIntoView(this.notifications);
      await expect(this.notifications).toBeVisible({ timeout: 10000 });
      await expect(this.notifications).toBeEnabled({ timeout: 5000 });

      if (await this.notifications.isVisible()) {
        await this.notifications.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        console.log('✅ Notifications verified successfully.');
      } else {
        throw new Error('Notifications button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyNotifications: ${error.message}`);
      throw error;
    }
  }

  // Verify Categories (converted from your Java method)
  async verifyCategories() {
    try {
      console.log('🔍 Verifying Categories...');

      await this.scrollIntoView(this.categories);
      await expect(this.categories).toBeVisible({ timeout: 10000 });
      await expect(this.categories).toBeEnabled({ timeout: 5000 });

      if (await this.categories.isVisible()) {
        await this.categories.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await expect(this.createCategory).toBeVisible({ timeout: 10000 });
        const createCategoryText = await this.createCategory.textContent();
        console.log(`✅ ${createCategoryText?.trim()} button is visible after clicking Categories.`);
        return true;
      } else {
        throw new Error('Categories button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyCategories: ${error.message}`);
      throw error;
    } finally {
      // Navigate back to System Setup
      try {
        await this.scrollIntoView(this.backButton);
        await this.backButton.click();
        await expect(this.systemSetup).toBeVisible({ timeout: 10000 });
        console.log('↩️ Navigated back to System Setup');
      } catch (backError) {
        console.log('ℹ️ Back button not found, using browser back');
        await this.page.goBack();
        await this.page.waitForTimeout(2000);
      }
    }
  }

  // Click Categories (converted from your Java method)
  async clickCategories() {
    try {
      console.log('🖱️ Clicking on Categories...');

      await this.scrollIntoView(this.categories);
      await expect(this.categories).toBeVisible({ timeout: 10000 });
      await expect(this.categories).toBeEnabled({ timeout: 5000 });

      if (await this.categories.isVisible()) {
        await this.categories.click();
        await this.page.waitForTimeout(2000);

        // Capture any errors
        await this.captureErrorIfPresent();

        await expect(this.createCategory).toBeVisible({ timeout: 10000 });
        const createCategoryText = await this.createCategory.textContent();
        console.log(`✅ ${createCategoryText?.trim()} button is visible after clicking Categories.`);
        return true;
      } else {
        throw new Error('Categories button is not visible.');
      }
    } catch (error) {
      console.error(`❌ Exception occurred in ClickCategories: ${error.message}`);
      throw error;
    }
  }

  // Setup Categories (converted from your Java method)
  async setupCategories(categoryName) {
    try {
      console.log(`🔧 Setting up category: ${categoryName}`);

      const xpath = `//td[normalize-space()='${categoryName}']`;
      const existingFields = this.page.locator(xpath);
      const count = await existingFields.count();

      if (count === 0) {
        console.log(`📝 Category '${categoryName}' not found, creating new category...`);
        await this.createCategoryHelper(categoryName);
      } else {
        const existingField = existingFields.first();
        await this.scrollIntoView(existingField);
        console.log(`✅ ${categoryName}: Category is already created.`);
      }

      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in SetupCategories: ${error.message}`);
      throw error;
    }
  }

  // Helper Create Categories (converted from your Java method)
  async createCategoryHelper(categoryName) {
    try {
      console.log(`🆕 Creating new category: ${categoryName}`);

      await expect(this.createCategory).toBeEnabled({ timeout: 10000 });
      await this.scrollIntoView(this.createCategory);
      await this.createCategory.click();

      await expect(this.categoryName).toBeVisible({ timeout: 10000 });
      await this.categoryName.clear();
      await this.categoryName.fill(categoryName);

      await this.scrollIntoView(this.saveCategory);
      await this.saveCategory.click();
      await this.page.waitForTimeout(2000);

      // Capture any errors after saving
      await this.captureErrorIfPresent();

      console.log(`✅ Category '${categoryName}' created successfully`);
      return true;
    } catch (error) {
      console.error(`❌ Exception occurred in CreateCategoryHelper: ${error.message}`);
      throw error;
    }
  }

  // Test Lead sub-elements (following your pattern)
  async testLeadSubElements() {
    try {
      console.log('🔍 Testing Lead sub-elements...');
      
      const leadElements = [
        { element: this.leadField, name: 'Lead Field' },
        { element: this.leadStage, name: 'Lead Stage' },
        { element: this.leadStatus, name: 'Lead Status' },
        { element: this.leadLostReason, name: 'Lead Lost Reason' }
      ];
      
      const results = [];
      
      for (const leadElement of leadElements) {
        try {
          await this.scrollIntoView(leadElement.element);
          await expect(leadElement.element).toBeVisible({ timeout: 5000 });
          await expect(leadElement.element).toBeEnabled({ timeout: 3000 });
          
          if (await leadElement.element.isVisible()) {
            await leadElement.element.click();
            await this.page.waitForTimeout(1500);
            
            await this.captureErrorIfPresent();
            console.log(`✅ ${leadElement.name} clicked successfully`);
            
            // Navigate back
            await this.page.goBack();
            await this.page.waitForTimeout(1000);
            
            results.push({ name: leadElement.name, success: true });
          }
        } catch (error) {
          console.log(`⚠️ ${leadElement.name} failed: ${error.message}`);
          results.push({ name: leadElement.name, success: false, error: error.message });
        }
      }
      
      return results;
    } catch (error) {
      console.error(`❌ Exception occurred in testLeadSubElements: ${error.message}`);
      throw error;
    }
  }

  // Test Ticket sub-elements (following your pattern)
  async testTicketSubElements() {
    try {
      console.log('🔍 Testing Ticket sub-elements...');
      
      const ticketElements = [
        { element: this.ticketField, name: 'Ticket Field' },
        { element: this.ticketType, name: 'Ticket Type' },
        { element: this.ticketPriority, name: 'Ticket Priority' },
        { element: this.ticketStage, name: 'Ticket Stage' }
      ];
      
      const results = [];
      
      for (const ticketElement of ticketElements) {
        try {
          await this.scrollIntoView(ticketElement.element);
          await expect(ticketElement.element).toBeVisible({ timeout: 5000 });
          await expect(ticketElement.element).toBeEnabled({ timeout: 3000 });
          
          if (await ticketElement.element.isVisible()) {
            await ticketElement.element.click();
            await this.page.waitForTimeout(1500);
            
            await this.captureErrorIfPresent();
            console.log(`✅ ${ticketElement.name} clicked successfully`);
            
            // Navigate back
            await this.page.goBack();
            await this.page.waitForTimeout(1000);
            
            results.push({ name: ticketElement.name, success: true });
          }
        } catch (error) {
          console.log(`⚠️ ${ticketElement.name} failed: ${error.message}`);
          results.push({ name: ticketElement.name, success: false, error: error.message });
        }
      }
      
      return results;
    } catch (error) {
      console.error(`❌ Exception occurred in testTicketSubElements: ${error.message}`);
      throw error;
    }
  }
}

// Export SystemSetupPage as CommonJS for compatibility with require in test files
module.exports = SystemSetupPage;
