const { expect } = require('@playwright/test');
const BasePage = require('./BasePage');


class Addupdatecontact_POm extends BasePage {
  constructor(page) {
    super(page);
    this.page = page;

    // Document management elements
    this.searchandAddContact = page.locator("//label[@class='page m-0 p-l-5 fs-14 hov-pointer']");
    this.searchandAddContactPopUp = page.locator("//label[@class='page m-0 p-l-5 fs-14 hov-pointer']");
    this.SearchContact = page.locator("//input[@id='contactSearch']");
    this.AddNewContact = page.locator("//input[@id='contactNewAdd']");
    this.SelectFieldName = page.locator("//select[@id='searchBy_contact']");
    this.FieldValue = page.locator("//input[@id='newserchtext']");
    this.ContactSearchButton = page.locator("//button[@id='contactSearchWio']");
    this.CompanyName = page.locator("//input[@id='wioCompany']");
    this.FirstName = page.locator("//input[@id='firstName']");
    this.LastName = page.locator("//input[@id='lastName']");
    this.Phoneno = page.locator("//input[@id='phone']");
    this.Email = page.locator("//div//input[@id='email']");
    this.SaveButton = page.locator("//button[@id='addContactSaveWio']");
    this.CloseButton = page.locator("//i[@class='fa fa-times fa-lg info close-wio hov-pointer']");
  }