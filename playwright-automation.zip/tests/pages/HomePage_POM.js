const { expect } = require('@playwright/test');
const BasePage = require('./BasePage');
const AdminSideBar = require('../utils/AdminSideBar');
const ErrorUtil = require('../utils/ErrorUtil');

/**
 * HomePage_POM - Page Object Model for Home Page functionality
 * Converted from Java Selenium to Playwright JavaScript
 * Handles home page verification, campaigns, and navigation
 */
class HomePage_POM extends BasePage {
  
  /**
   * Constructor to initialize page and utilities
   * @param {import('@playwright/test').Page} page - Playwright page object
   */
  constructor(page) {
    super(page);
    this.page = page;
    this.adminSideBar = new AdminSideBar(page);
    this.errorUtil = new ErrorUtil(page);
    
    // Define locators (converted from your Java @FindBy annotations)
    this.back = page.locator("//i[@class='fa fa-arrow-circle-left fa-lg']");
    this.overview = page.locator("//h4[normalize-space()='Overview']");
    this.home = page.locator("//span[@class='page admin-home']");
    this.campaignsAndContacts = page.locator("//label[normalize-space()='Campaigns & Contacts']");
    this.campaignsAndContactsPage = page.locator("//div[@class='col-xs-12 col-sm-12 col-lg-12']//div[@class='box box-info']");
    
    // Active Campaign elements
    this.activeCamp = page.locator("//div[contains(text(),'Active Campaigns')]");
    this.activeCampPage = page.locator("//div[@class='tab-content']");
    this.archivedActiveCamp = page.locator("//a[@id='viewArchiveCampaigns']");
    this.archivedCampPage = page.locator("//div[@class='tab-content p-0']");
    
    // Archived Campaign elements
    this.archivedCamp = page.locator("//div[contains(text(),'Archived Campaigns')]");

    // All Contacts elements
    this.allContacts = page.locator("//div[contains(text(),'All Contacts')]");
    this.allContactsPage = page.locator("//label[normalize-space()='All Contacts']");

    // Add Contact elements
    this.addContact = page.locator("//div[contains(text(),'Add Contact')]");
    this.addContactForm = page.locator("(//div[@class='box box-info'])[3]");
    this.addContactPageText = page.locator("//label[normalize-space()='Add Contact']");

    // Leads & Tickets elements
    this.leadsAndTickets = page.locator("//label[normalize-space()='Leads & Tickets']");
    this.leadsAndTicketsItems = page.locator("//div[@id='campleadBody']");

    // Lead Follow Up elements
    this.leadFollowUp = page.locator("//div[contains(text(),'Lead Follow Up')]");
    this.leadFollowUpPage = page.locator("(//div[@class='box box-info'])[3]");

    // Manage All Leads elements
    this.manageAllLeads = page.locator("//div[contains(text(),'Manage All Leads')]");
    this.manageAllLeadsPage = page.locator("(//div[@class='box box-info'])[3]");

    // Ticket Follow Up elements
    this.ticketFollowUp = page.locator("//div[contains(text(),'Ticket Follow Up')]");
    this.ticketFollowUpPage = page.locator("(//div[@class='box box-info'])[3]");

    // Manage All Tickets elements
    this.manageAllTickets = page.locator("//div[contains(text(),'Manage All Tickets')]");
    this.manageAllTicketsPage = page.locator("(//div[@class='box box-info'])[3]");

    // Others section elements
    this.others = page.locator("//label[normalize-space()='Others']");
    this.othersElements = page.locator("//div[@id='campotherBody']");

    // My Preferences elements
    this.myPreference = page.locator("//div[contains(text(),'My Preferences')]");
    this.myPreferencePage = page.locator("//section[@class='content animated fadeIn']//div[@class='box box-info']");

    // Phone Preferences elements
    this.phonePreferences = page.locator("//div[contains(text(),'Phone Preferences')]");
    this.phonePreferencesPage = page.locator("//div[@id='voiceBody']");

    // Import elements
    this.import = page.locator("//div[@class='card-panel-text'][normalize-space()='Import']");
    this.importListPage = page.locator("//div[@class='tab-content p-0']");
    this.importList = page.locator("//a[@id='importNewList']");

    // Append To An Existing List elements
    this.appendToAnExistingList = page.locator("//a[@id='appenedExistingList']");
    this.appendToAnExistingListPage = page.locator("//div[@class='tab-content p-0']");

    // Import Logs elements
    this.importLogs = page.locator("//a[@id='viewImportLog']");
    this.importLogsPage = page.locator("//div[@class='tab-content p-0']");

    // Imported List elements
    this.importedList = page.locator("//a[@id='viewImportedList']");
    this.importedListPage = page.locator("//div[@class='tab-content p-0']");

    // Web Form Import elements
    this.webFormImport = page.locator("//div[contains(text(),'Web Form Import')]");
    this.webFormCampaignMapping = page.locator("//div[@class='tab-content']");

    // Logs elements
    this.logs = page.locator("//a[normalize-space()='Logs']");
    this.webPostLogCriteria = page.locator("//div[@class='tab-content']");

    // Reports elements
    this.reports = page.locator("//div[contains(text(),'Reports')]");
    this.reportsHeader = page.locator("//h4[normalize-space()='Reports']");
    this.reportsItems = page.locator("//section[@class='content animated fadeIn']");

    // Outbound Summary elements
    this.outboundSummary = page.locator("//div[contains(text(),'Outbound Summary')]");
    this.outboundSummaryCriteria = page.locator("(//div[@class='box box-info'])[3]");
    this.expendOutboundCalls = page.locator("//label[normalize-space()='Outbound Calls']");

    // Outbound Details elements
    this.outboundDetails = page.locator("//div[@class='card-panel-text text-left'][normalize-space()='Outbound Detail']");
    this.outboundDetailsCriteria = page.locator("(//div[@class='box box-info'])[3]");

    // Inbound Calls elements
    this.inboundCalls = page.locator("//label[normalize-space()='Inbound Calls']");
    this.inboundDetail = page.locator("//div[contains(text(),'Inbound Detail')]");
    this.inboundDetailCriteria = page.locator("(//div[@class='box box-info'])[3]");

    // Lead Report elements
    this.leadReport = page.locator("//label[normalize-space()='Lead Report']");
    this.leadSummary = page.locator("//div[contains(text(),'Lead Summary')]");
    this.leadSummaryReport = page.locator("(//div[@class='box box-info'])[3]");
    this.leadDetail = page.locator("//div[contains(text(),'Lead Detail')]");
    this.leadDetailReport = page.locator("(//div[@class='box box-info'])[3]");

    // Agent elements
    this.agent = page.locator("//label[normalize-space()='Agent']");
    this.agentSummary = page.locator("//div[contains(text(),'Agent Summary')]");
    this.agentSummaryReport = page.locator("(//div[@class='box box-info'])[3]");
    this.agentDetail = page.locator("//div[contains(text(),'Agent Detail Report')]");
    this.agentDetailReport = page.locator("(//div[@class='box box-info'])[3]");
    this.systemUser = page.locator("//div[contains(text(),'System User Report')]");
    this.systemUserReport = page.locator("(//div[@class='box box-info'])[3]");
    this.agentTimeByCampaign = page.locator("//div[contains(text(),'Agent Time Report (By Campaign)')]");
    this.agentTimeByCampaignCriteria = page.locator("(//div[@class='box box-info'])[3]");
    this.agentTimeByAgent = page.locator("//div[contains(text(),'Agent Time Report (By Agent)')]");
    this.agentTimeByAgentCriteria = page.locator("(//div[@class='box box-info'])[3]");

    // Contact elements
    this.contact = page.locator("//label[normalize-space()='Contact']");
    this.statusReport = page.locator("//div[contains(text(),'Status Report')]");
    this.statusReportCriteria = page.locator("(//div[@class='box box-info'])[3]");
    this.importListReport = page.locator("//div[contains(text(),'Imported List Report')]");
    this.importListReportPage = page.locator("(//div[@class='box box-info'])[3]");
    this.contactWebPostLog = page.locator("//div[contains(text(),'Contact Web Post Log')]");
    this.contactWebPostLogCriteria = page.locator("(//div[@class='box box-info'])[3]");

    // Custom elements
    this.custom = page.locator("//label[normalize-space()='Custom']");
    this.customReportsPages = page.locator("(//div[@class='box box-info'])[3]");
  }

  /**
   * Verify Home page functionality
   * Converted from your Java VerifyHome() method
   */
  async verifyHome() {
    try {
      console.log('🏠 Verifying Home page functionality...');
      
      await this.home.scrollIntoViewIfNeeded();
      
      // Click Home to ensure page loads correctly
      await this.home.click();
      await this.errorUtil.captureErrorIfPresent();
      
      await this.campaignsAndContacts.scrollIntoViewIfNeeded();
      console.log('✅ CampaignsAndContacts element is visible after clicking Home.');

      // Now check if CampaignsAndContactsPage is displayed
      await expect(this.campaignsAndContactsPage).toBeVisible({ timeout: 30000 });
      
      const isDisplayed = await this.campaignsAndContactsPage.isVisible();
      if (!isDisplayed) {
        throw new Error("CampaignsAndContactsPage section is not visible.");
      }
      
      console.log('✅ CampaignsAndContactsPage section is visible.');
      console.log('✅ Home page verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyHome: ${error.message}`);
      throw new Error(`Exception occurred in VerifyHome: ${error.message}`);
    }
  }

  /**
   * Verify Active Campaign functionality
   * Converted from your Java VerifyActiveCampaign() method
   */
  async verifyActiveCampaign() {
    try {
      console.log('📊 Verifying Active Campaign functionality...');
      
      await this.activeCamp.scrollIntoViewIfNeeded();
      await expect(this.activeCamp).toBeVisible({ timeout: 30000 });
      await expect(this.activeCamp).toBeEnabled({ timeout: 30000 });
      
      const isDisplayed = await this.activeCamp.isVisible();
      if (isDisplayed) {
        await this.activeCamp.click();
        await this.errorUtil.captureErrorIfPresent();
        
        await this.activeCampPage.scrollIntoViewIfNeeded();
        await expect(this.activeCampPage).toBeVisible({ timeout: 30000 });
        
        const pageDisplayed = await this.activeCampPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("ActivedCampPage is not displayed.");
        }
        
        console.log('✅ ActivedCampPage button is visible after clicking ActiveCamp.');
      } else {
        throw new Error("ActiveCamp button is not visible.");
      }
      
      console.log('✅ Active Campaign verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyActiveCampaign: ${error.message}`);
      throw new Error(`Exception occurred in VerifyActiveCampaign: ${error.message}`);
    }
  }

  /**
   * Verify Archived Campaigns at Active Campaigns
   * Converted from your Java VerifyArchievedCampAtActiveCampaigns() method
   */
  async verifyArchivedCampAtActiveCampaigns() {
    try {
      console.log('📁 Verifying Archived Campaigns at Active Campaigns...');
      
      await this.archivedActiveCamp.scrollIntoViewIfNeeded();
      await expect(this.archivedActiveCamp).toBeVisible({ timeout: 30000 });
      await expect(this.archivedActiveCamp).toBeEnabled({ timeout: 30000 });
      
      const isDisplayed = await this.archivedActiveCamp.isVisible();
      if (isDisplayed) {
        await this.archivedActiveCamp.click();
        await this.errorUtil.captureErrorIfPresent();
        
        await this.archivedCampPage.scrollIntoViewIfNeeded();
        await expect(this.archivedCampPage).toBeVisible({ timeout: 30000 });
        
        const pageDisplayed = await this.archivedCampPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("ArchivedCampPage is not displayed.");
        }
        
        console.log('✅ ArchivedCampPage button is visible after clicking ArchivedActiveCamp.');
      } else {
        throw new Error("ArchivedActiveCamp button is not visible.");
      }
      
      console.log('✅ Archived Campaigns at Active Campaigns verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in Verify Archived Campaigns At Active Campaigns: ${error.message}`);
      throw new Error(`Exception occurred in Verify Archived Campaigns At Active Campaigns: ${error.message}`);
    } finally {
      // Navigation back to overview (equivalent to your finally block)
      await this.navigateBackToOverview();
    }
  }

  /**
   * Verify Archived Campaign functionality
   * Converted from your Java VerifyArchievedCampaign() method
   */
  async verifyArchivedCampaign() {
    try {
      console.log('🗄️ Verifying Archived Campaign functionality...');
      
      await this.archivedCamp.scrollIntoViewIfNeeded();
      await expect(this.archivedCamp).toBeVisible({ timeout: 30000 });
      await expect(this.archivedCamp).toBeEnabled({ timeout: 30000 });
      
      const isDisplayed = await this.archivedCamp.isVisible();
      if (isDisplayed) {
        await this.archivedCamp.click();
        await this.errorUtil.captureErrorIfPresent();
        
        await this.archivedCampPage.scrollIntoViewIfNeeded();
        await expect(this.archivedCampPage).toBeVisible({ timeout: 30000 });
        
        const pageDisplayed = await this.archivedCampPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("ArchivedCampPage is not displayed.");
        }
        
        console.log('✅ ArchivedCampPage button is visible after clicking ArchivedCampaign.');
      } else {
        throw new Error("ArchivedCampaign button is not visible.");
      }
      
      console.log('✅ Archived Campaign verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyArchivedCampaign: ${error.message}`);
      throw new Error(`Exception occurred in VerifyArchivedCampaign: ${error.message}`);
    } finally {
      // Navigation back to overview (equivalent to your finally block)
      await this.navigateBackToOverviewSingle();
    }
  }

  /**
   * Navigate back to overview (double back navigation)
   * Helper method for complex navigation back to overview
   */
  async navigateBackToOverview() {
    try {
      console.log('🔙 Navigating back to overview (double back)...');
      
      // First back button click
      await this.back.scrollIntoViewIfNeeded();
      await this.adminSideBar.clickOnBackButton();
      await expect(this.activeCampPage).toBeVisible({ timeout: 30000 });
      
      // Second back button click
      await this.back.scrollIntoViewIfNeeded();
      await this.adminSideBar.clickOnBackButton();
      
      // Wait for overview to be visible
      await this.overview.scrollIntoViewIfNeeded();
      await expect(this.overview).toBeVisible({ timeout: 30000 });
      
      console.log('✅ Successfully navigated back to overview');
    } catch (error) {
      console.error(`❌ Error navigating back to overview: ${error.message}`);
      throw error;
    }
  }

  /**
   * Navigate back to overview (single back navigation)
   * Helper method for simple navigation back to overview
   */
  async navigateBackToOverviewSingle() {
    try {
      console.log('🔙 Navigating back to overview (single back)...');
      
      // Single back button click
      await this.back.scrollIntoViewIfNeeded();
      await this.adminSideBar.clickOnBackButton();
      
      // Wait for overview to be visible
      await this.overview.scrollIntoViewIfNeeded();
      await expect(this.overview).toBeVisible({ timeout: 30000 });
      
      console.log('✅ Successfully navigated back to overview');
    } catch (error) {
      console.error(`❌ Error navigating back to overview: ${error.message}`);
      throw error;
    }
  }

  /**
   * Verify all home page elements are present
   * Enhanced method to verify page readiness
   */
  async verifyHomePageElements() {
    try {
      console.log('🔍 Verifying all home page elements...');
      
      await expect(this.home).toBeVisible({ timeout: 30000 });
      await expect(this.campaignsAndContacts).toBeVisible({ timeout: 30000 });
      await expect(this.activeCamp).toBeVisible({ timeout: 30000 });
      await expect(this.archivedCamp).toBeVisible({ timeout: 30000 });
      
      console.log('✅ All home page elements are present');
      return true;
    } catch (error) {
      console.error(`❌ Home page elements verification failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get campaign statistics
   * Enhanced method to get campaign information
   * @returns {Object} Campaign statistics
   */
  async getCampaignStatistics() {
    try {
      console.log('📊 Getting campaign statistics...');
      
      const stats = {
        activeCampaignsVisible: false,
        archivedCampaignsVisible: false,
        campaignsAndContactsVisible: false
      };

      stats.activeCampaignsVisible = await this.activeCamp.isVisible();
      stats.archivedCampaignsVisible = await this.archivedCamp.isVisible();
      stats.campaignsAndContactsVisible = await this.campaignsAndContacts.isVisible();

      console.log('📈 Campaign statistics:', stats);
      return stats;
    } catch (error) {
      console.error(`❌ Error getting campaign statistics: ${error.message}`);
      return {
        activeCampaignsVisible: false,
        archivedCampaignsVisible: false,
        campaignsAndContactsVisible: false,
        error: error.message
      };
    }
  }

  /**
   * Wait for home page to load completely
   * Enhanced method for page load verification
   */
  async waitForHomePageLoad() {
    try {
      console.log('⏳ Waiting for home page to load completely...');
      
      await this.page.waitForLoadState('networkidle', { timeout: 30000 });
      await expect(this.overview).toBeVisible({ timeout: 30000 });
      await expect(this.home).toBeVisible({ timeout: 30000 });
      
      console.log('✅ Home page loaded completely');
    } catch (error) {
      console.error(`❌ Error waiting for home page load: ${error.message}`);
      throw error;
    }
  }

  /**
   * Navigate to home page
   * Enhanced method for home navigation
   */
  async navigateToHome() {
    try {
      console.log('🏠 Navigating to home page...');

      await this.home.scrollIntoViewIfNeeded();
      await this.home.click();
      await this.waitForHomePageLoad();

      console.log('✅ Successfully navigated to home page');
    } catch (error) {
      console.error(`❌ Error navigating to home page: ${error.message}`);
      throw error;
    }
  }

  /**
   * Verify All Contacts functionality
   * Converted from your Java VerifyAllContact() method
   */
  async verifyAllContact() {
    try {
      console.log('👥 Verifying All Contacts functionality...');

      await this.allContacts.scrollIntoViewIfNeeded();
      await expect(this.allContacts).toBeVisible({ timeout: 30000 });
      await expect(this.allContacts).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.allContacts.isVisible();
      if (isDisplayed) {
        await this.allContacts.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.allContactsPage.scrollIntoViewIfNeeded();
        await expect(this.allContactsPage).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.allContactsPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("AllContactsPage is not displayed.");
        }

        console.log('✅ AllContactsPage button is visible after clicking AllContacts.');
      } else {
        throw new Error("AllContacts button is not visible.");
      }

      console.log('✅ All Contacts verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyAllContact: ${error.message}`);
      throw new Error(`Exception occurred in VerifyAllContact: ${error.message}`);
    } finally {
      // Navigation back to overview (equivalent to your finally block)
      await this.navigateBackToOverviewSingle();
    }
  }

  /**
   * Verify Add Contact functionality
   * Converted from your Java VerifyAddContact() method
   */
  async verifyAddContact() {
    try {
      console.log('➕ Verifying Add Contact functionality...');

      await this.addContact.scrollIntoViewIfNeeded();
      await expect(this.addContact).toBeVisible({ timeout: 30000 });
      await expect(this.addContact).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.addContact.isVisible();
      if (isDisplayed) {
        await this.addContact.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.addContactForm.scrollIntoViewIfNeeded();
        await expect(this.addContactForm).toBeVisible({ timeout: 30000 });

        const formDisplayed = await this.addContactForm.isVisible();
        if (!formDisplayed) {
          throw new Error("AddContact Form is not displayed.");
        }

        console.log('✅ AddContact Form is visible after clicking AddContact.');
      } else {
        throw new Error("AddContact button is not visible.");
      }

      console.log('✅ Add Contact verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyAddContact: ${error.message}`);
      throw new Error(`Exception occurred in VerifyAddContact: ${error.message}`);
    } finally {
      // Navigation back to overview (equivalent to your finally block)
      await this.navigateBackToOverviewSingle();
    }
  }

  /**
   * Verify Leads & Tickets functionality
   * Converted from your Java VerifyLeadsAndTickets() method
   */
  async verifyLeadsAndTickets() {
    try {
      console.log('🎯 Verifying Leads & Tickets functionality...');

      await this.leadsAndTickets.scrollIntoViewIfNeeded();
      await expect(this.leadsAndTickets).toBeVisible({ timeout: 30000 });

      const isDisplayed = await this.leadsAndTickets.isVisible();
      if (isDisplayed) {
        await this.leadsAndTickets.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.leadsAndTicketsItems.scrollIntoViewIfNeeded();
        await expect(this.leadsAndTicketsItems).toBeVisible({ timeout: 30000 });

        const itemsDisplayed = await this.leadsAndTicketsItems.isVisible();
        if (!itemsDisplayed) {
          throw new Error("LeadsAndTickets items are not displayed.");
        }

        console.log('✅ LeadsAndTickets items are visible after clicking LeadsAndTickets.');
      } else {
        throw new Error("LeadsAndTickets button is not expandable.");
      }

      console.log('✅ Leads & Tickets verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyLeadsAndTickets: ${error.message}`);
      throw new Error(`Exception occurred in VerifyLeadsAndTickets: ${error.message}`);
    }
  }

  /**
   * Verify Lead Follow Up functionality
   * Converted from your Java VerifyLeadFollowUp() method
   */
  async verifyLeadFollowUp() {
    try {
      console.log('📊 Verifying Lead Follow Up functionality...');

      // Check if LeadFollowUp is displayed, if not expand Leads & Tickets
      const isLeadFollowUpVisible = await this.leadFollowUp.isVisible();
      if (!isLeadFollowUpVisible) {
        await this.verifyLeadsAndTickets();
      }

      await this.leadFollowUp.scrollIntoViewIfNeeded();
      await expect(this.leadFollowUp).toBeVisible({ timeout: 30000 });
      await expect(this.leadFollowUp).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.leadFollowUp.isVisible();
      if (isDisplayed) {
        await this.leadFollowUp.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.leadFollowUpPage.scrollIntoViewIfNeeded();
        await expect(this.leadFollowUpPage).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.leadFollowUpPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("LeadFollowUpPage is not displayed.");
        }

        console.log('✅ LeadFollowUpPage is visible after clicking LeadFollowUp.');
      } else {
        throw new Error("LeadFollowUp button is not visible.");
      }

      console.log('✅ Lead Follow Up verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyLeadFollowUp: ${error.message}`);
      throw new Error(`Exception occurred in VerifyLeadFollowUp: ${error.message}`);
    } finally {
      // Navigation back to overview (equivalent to your finally block)
      await this.navigateBackToOverviewSingle();
    }
  }

  /**
   * Verify Manage All Leads functionality
   * Converted from your Java VerifyManageAllLeads() method
   */
  async verifyManageAllLeads() {
    try {
      console.log('📋 Verifying Manage All Leads functionality...');

      // Check if LeadFollowUp is displayed, if not expand Leads & Tickets
      const isLeadFollowUpVisible = await this.leadFollowUp.isVisible();
      if (!isLeadFollowUpVisible) {
        await this.verifyLeadsAndTickets();
      }

      await this.manageAllLeads.scrollIntoViewIfNeeded();
      await expect(this.manageAllLeads).toBeVisible({ timeout: 30000 });
      await expect(this.manageAllLeads).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.manageAllLeads.isVisible();
      if (isDisplayed) {
        await this.manageAllLeads.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.manageAllLeadsPage.scrollIntoViewIfNeeded();
        await expect(this.manageAllLeadsPage).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.manageAllLeadsPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("ManageAllLeadsPage is not displayed.");
        }

        console.log('✅ ManageAllLeadsPage is visible after clicking ManageAllLeads.');
      } else {
        throw new Error("ManageAllLeads button is not visible.");
      }

      console.log('✅ Manage All Leads verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyManageAllLeads: ${error.message}`);
      throw new Error(`Exception occurred in VerifyManageAllLeads: ${error.message}`);
    } finally {
      // Navigation back to overview (equivalent to your finally block)
      await this.navigateBackToOverviewSingle();
    }
  }

  /**
   * Verify Ticket Follow Up functionality
   * Converted from your Java VerifyTicketFollowUp() method
   */
  async verifyTicketFollowUp() {
    try {
      console.log('🎫 Verifying Ticket Follow Up functionality...');

      // Check if LeadFollowUp is displayed, if not expand Leads & Tickets
      const isLeadFollowUpVisible = await this.leadFollowUp.isVisible();
      if (!isLeadFollowUpVisible) {
        await this.verifyLeadsAndTickets();
      }

      await this.ticketFollowUp.scrollIntoViewIfNeeded();
      await expect(this.ticketFollowUp).toBeVisible({ timeout: 30000 });
      await expect(this.ticketFollowUp).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.ticketFollowUp.isVisible();
      if (isDisplayed) {
        await this.ticketFollowUp.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.ticketFollowUpPage.scrollIntoViewIfNeeded();
        await expect(this.ticketFollowUpPage).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.ticketFollowUpPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("TicketFollowUpPage is not displayed.");
        }

        console.log('✅ TicketFollowUpPage is visible after clicking TicketFollowUp.');
      } else {
        throw new Error("TicketFollowUp button is not visible.");
      }

      console.log('✅ Ticket Follow Up verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyTicketFollowUp: ${error.message}`);
      throw new Error(`Exception occurred in VerifyTicketFollowUp: ${error.message}`);
    } finally {
      // Navigation back to overview (equivalent to your finally block)
      await this.navigateBackToOverviewSingle();
    }
  }

  /**
   * Verify Manage All Tickets functionality
   * Converted from your Java VerifyManageAllTickets() method
   */
  async verifyManageAllTickets() {
    try {
      console.log('🎟️ Verifying Manage All Tickets functionality...');

      // Check if LeadFollowUp is displayed, if not expand Leads & Tickets
      const isLeadFollowUpVisible = await this.leadFollowUp.isVisible();
      if (!isLeadFollowUpVisible) {
        await this.verifyLeadsAndTickets();
      }

      await this.manageAllTickets.scrollIntoViewIfNeeded();
      await expect(this.manageAllTickets).toBeVisible({ timeout: 30000 });
      await expect(this.manageAllTickets).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.manageAllTickets.isVisible();
      if (isDisplayed) {
        await this.manageAllTickets.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.manageAllTicketsPage.scrollIntoViewIfNeeded();
        await expect(this.manageAllTicketsPage).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.manageAllTicketsPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("ManageAllTicketsPage is not displayed.");
        }

        console.log('✅ ManageAllTicketsPage is visible after clicking ManageAllTickets.');
      } else {
        throw new Error("ManageAllTickets button is not visible.");
      }

      console.log('✅ Manage All Tickets verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyManageAllTickets: ${error.message}`);
      throw new Error(`Exception occurred in VerifyManageAllTickets: ${error.message}`);
    } finally {
      // Navigation back to overview (equivalent to your finally block)
      await this.navigateBackToOverviewSingle();
    }
  }

  /**
   * Verify Others functionality
   * Converted from your Java VerifyOthers() method
   */
  async verifyOthers() {
    try {
      console.log('🔧 Verifying Others functionality...');

      await this.others.scrollIntoViewIfNeeded();
      await expect(this.others).toBeVisible({ timeout: 30000 });

      const isDisplayed = await this.others.isVisible();
      if (isDisplayed) {
        await this.others.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.othersElements.scrollIntoViewIfNeeded();
        await expect(this.othersElements).toBeVisible({ timeout: 30000 });

        const elementsDisplayed = await this.othersElements.isVisible();
        if (!elementsDisplayed) {
          throw new Error("Others elements are not displayed.");
        }

        console.log('✅ Others elements are visible after clicking Others.');
      } else {
        throw new Error("Others button is not expandable.");
      }

      console.log('✅ Others verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyOthers: ${error.message}`);
      throw new Error(`Exception occurred in VerifyOthers: ${error.message}`);
    }
  }

  /**
   * Verify My Preferences functionality
   * Converted from your Java VerifyMyPreference() method
   */
  async verifyMyPreference() {
    try {
      console.log('⚙️ Verifying My Preferences functionality...');

      // Check if MyPreference is displayed, if not expand Others
      const isMyPreferenceVisible = await this.myPreference.isVisible();
      if (!isMyPreferenceVisible) {
        await this.verifyOthers();
      }

      await this.myPreference.scrollIntoViewIfNeeded();
      await expect(this.myPreference).toBeVisible({ timeout: 30000 });
      await expect(this.myPreference).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.myPreference.isVisible();
      if (isDisplayed) {
        await this.myPreference.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.myPreferencePage.scrollIntoViewIfNeeded();
        await expect(this.myPreferencePage).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.myPreferencePage.isVisible();
        if (!pageDisplayed) {
          throw new Error("MyPreferencePage is not displayed.");
        }

        console.log('✅ MyPreferencePage is visible after clicking MyPreference.');
      } else {
        throw new Error("MyPreference button is not visible.");
      }

      console.log('✅ My Preferences verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyMyPreference: ${error.message}`);
      throw new Error(`Exception occurred in VerifyMyPreference: ${error.message}`);
    } finally {
      // Navigation back to overview (equivalent to your finally block)
      await this.navigateBackToOverviewSingle();
    }
  }

  /**
   * Verify Phone Preferences functionality
   * Converted from your Java VerifyPhonePreferences() method
   */
  async verifyPhonePreferences() {
    try {
      console.log('📞 Verifying Phone Preferences functionality...');

      // Check if PhonePreferences is displayed, if not expand Others
      const isPhonePreferencesVisible = await this.phonePreferences.isVisible();
      if (!isPhonePreferencesVisible) {
        await this.verifyOthers();
      }

      await this.phonePreferences.scrollIntoViewIfNeeded();
      await expect(this.phonePreferences).toBeVisible({ timeout: 30000 });
      await expect(this.phonePreferences).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.phonePreferences.isVisible();
      if (isDisplayed) {
        await this.phonePreferences.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.phonePreferencesPage.scrollIntoViewIfNeeded();
        await expect(this.phonePreferencesPage).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.phonePreferencesPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("PhonePreferencesPage is not displayed.");
        }

        console.log('✅ PhonePreferencesPage is visible after clicking PhonePreferences.');
      } else {
        throw new Error("PhonePreferences button is not visible.");
      }

      console.log('✅ Phone Preferences verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyPhonePreferences: ${error.message}`);
      throw new Error(`Exception occurred in VerifyPhonePreferences: ${error.message}`);
    } finally {
      // Navigation back to overview (equivalent to your finally block)
      await this.navigateBackToOverviewSingle();
    }
  }

  /**
   * Verify Import functionality
   * Converted from your Java VerifyImport() method
   */
  async verifyImport() {
    try {
      console.log('📥 Verifying Import functionality...');

      // Check if Import is displayed, if not expand Others
      const isImportVisible = await this.import.isVisible();
      if (!isImportVisible) {
        await this.verifyOthers();
      }

      await this.import.scrollIntoViewIfNeeded();
      await expect(this.import).toBeVisible({ timeout: 30000 });
      await expect(this.import).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.import.isVisible();
      if (isDisplayed) {
        await this.import.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.importListPage.scrollIntoViewIfNeeded();
        await expect(this.importListPage).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.importListPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("ImportListPage is not displayed.");
        }

        console.log('✅ ImportList is visible after clicking Import.');
      } else {
        throw new Error("Import button is not visible.");
      }

      console.log('✅ Import verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyImport: ${error.message}`);
      throw new Error(`Exception occurred in VerifyImport: ${error.message}`);
    } finally {
      // Navigation back (equivalent to your finally block - just scroll to back button)
      await this.back.scrollIntoViewIfNeeded();
      await expect(this.back).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Append To An Existing List functionality
   * Converted from your Java VerifyAppendToAnExistingList() method
   */
  async verifyAppendToAnExistingList() {
    try {
      console.log('📋 Verifying Append To An Existing List functionality...');

      // Check if AppendToAnExistingList is displayed, if not expand Others
      const isAppendVisible = await this.appendToAnExistingList.isVisible();
      if (!isAppendVisible) {
        await this.verifyOthers();
      }

      await this.appendToAnExistingList.scrollIntoViewIfNeeded();
      await expect(this.appendToAnExistingList).toBeVisible({ timeout: 30000 });
      await expect(this.appendToAnExistingList).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.appendToAnExistingList.isVisible();
      if (isDisplayed) {
        await this.appendToAnExistingList.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.appendToAnExistingListPage.scrollIntoViewIfNeeded();
        await expect(this.appendToAnExistingListPage).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.appendToAnExistingListPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("AppendToAnExistingListPage is not displayed.");
        }

        console.log('✅ AppendToAnExistingListPage is visible after clicking AppendToAnExistingList.');
      } else {
        throw new Error("AppendToAnExistingList button is not visible.");
      }

      console.log('✅ Append To An Existing List verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyAppendToAnExistingList: ${error.message}`);
      throw new Error(`Exception occurred in VerifyAppendToAnExistingList: ${error.message}`);
    } finally {
      // Navigation back to ImportList (equivalent to your finally block)
      await this.back.scrollIntoViewIfNeeded();
      await this.adminSideBar.clickOnBackButton();
      await this.importList.scrollIntoViewIfNeeded();
      await expect(this.importList).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Import Logs functionality
   * Converted from your Java VerifyImportLogs() method
   */
  async verifyImportLogs() {
    try {
      console.log('📊 Verifying Import Logs functionality...');

      // Check if ImportLogs is displayed, if not expand Others
      const isImportLogsVisible = await this.importLogs.isVisible();
      if (!isImportLogsVisible) {
        await this.verifyOthers();
      }

      await this.importLogs.scrollIntoViewIfNeeded();
      await expect(this.importLogs).toBeVisible({ timeout: 30000 });
      await expect(this.importLogs).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.importLogs.isVisible();
      if (isDisplayed) {
        await this.importLogs.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.importLogsPage.scrollIntoViewIfNeeded();
        await expect(this.importLogsPage).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.importLogsPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("ImportLogsPage is not displayed.");
        }

        console.log('✅ ImportLogsPage is visible after clicking ImportLogs.');
      } else {
        throw new Error("ImportLogs button is not visible.");
      }

      console.log('✅ Import Logs verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyImportLogs: ${error.message}`);
      throw new Error(`Exception occurred in VerifyImportLogs: ${error.message}`);
    } finally {
      // Navigation back to ImportList (equivalent to your finally block)
      await this.back.scrollIntoViewIfNeeded();
      await this.adminSideBar.clickOnBackButton();
      await this.importList.scrollIntoViewIfNeeded();
      await expect(this.importList).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Imported List functionality
   * Converted from your Java VerifyImportedList() method
   */
  async verifyImportedList() {
    try {
      console.log('📄 Verifying Imported List functionality...');

      // Check if ImportedList is displayed, if not expand Others
      const isImportedListVisible = await this.importedList.isVisible();
      if (!isImportedListVisible) {
        await this.verifyOthers();
      }

      await this.importedList.scrollIntoViewIfNeeded();
      await expect(this.importedList).toBeVisible({ timeout: 30000 });
      await expect(this.importedList).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.importedList.isVisible();
      if (isDisplayed) {
        await this.importedList.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.importedListPage.scrollIntoViewIfNeeded();
        await expect(this.importedListPage).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.importedListPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("ImportedListPage is not displayed.");
        }

        console.log('✅ ImportedListPage is visible after clicking ImportedList.');
      } else {
        throw new Error("ImportedList button is not visible.");
      }

      console.log('✅ Imported List verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyImportedList: ${error.message}`);
      throw new Error(`Exception occurred in VerifyImportedList: ${error.message}`);
    } finally {
      // Double navigation back to Overview (equivalent to your finally block)
      await this.back.scrollIntoViewIfNeeded();
      await this.adminSideBar.clickOnBackButton();
      await this.importList.scrollIntoViewIfNeeded();
      await expect(this.importList).toBeVisible({ timeout: 30000 });
      await this.adminSideBar.clickOnBackButton();
      await this.overview.scrollIntoViewIfNeeded();
      await expect(this.overview).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Web Form Import functionality
   * Converted from your Java VerifyWebFormImport() method
   */
  async verifyWebFormImport() {
    try {
      console.log('🌐 Verifying Web Form Import functionality...');

      // Check if WebFormImport is displayed, if not expand Others
      const isWebFormImportVisible = await this.webFormImport.isVisible();
      if (!isWebFormImportVisible) {
        await this.verifyOthers();
      }

      await this.webFormImport.scrollIntoViewIfNeeded();
      await expect(this.webFormImport).toBeVisible({ timeout: 30000 });
      await expect(this.webFormImport).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.webFormImport.isVisible();
      if (isDisplayed) {
        await this.webFormImport.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.webFormCampaignMapping.scrollIntoViewIfNeeded();
        await expect(this.webFormCampaignMapping).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.webFormCampaignMapping.isVisible();
        if (!pageDisplayed) {
          throw new Error("WebFormCampaignMapping is not displayed.");
        }

        console.log('✅ WebFormCampaignMapping is visible after clicking WebFormImport.');
      } else {
        throw new Error("WebFormImport button is not visible.");
      }

      console.log('✅ Web Form Import verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyWebFormImport: ${error.message}`);
      throw new Error(`Exception occurred in VerifyWebFormImport: ${error.message}`);
    } finally {
      // Navigation to back button (equivalent to your finally block)
      await this.back.scrollIntoViewIfNeeded();
      await expect(this.back).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Logs functionality
   * Converted from your Java VerifyLogs() method
   */
  async verifyLogs() {
    try {
      console.log('📋 Verifying Logs functionality...');

      // Check if Logs is displayed, if not expand Others
      const isLogsVisible = await this.logs.isVisible();
      if (!isLogsVisible) {
        await this.verifyOthers();
      }

      await this.logs.scrollIntoViewIfNeeded();
      await expect(this.logs).toBeVisible({ timeout: 30000 });
      await expect(this.logs).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.logs.isVisible();
      if (isDisplayed) {
        await this.logs.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.webPostLogCriteria.scrollIntoViewIfNeeded();
        await expect(this.webPostLogCriteria).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.webPostLogCriteria.isVisible();
        if (!pageDisplayed) {
          throw new Error("WebPostLogCriteria is not displayed.");
        }

        console.log('✅ WebPostLogCriteria is visible after clicking Logs.');
      } else {
        throw new Error("Logs button is not visible.");
      }

      console.log('✅ Logs verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyLogs: ${error.message}`);
      throw new Error(`Exception occurred in VerifyLogs: ${error.message}`);
    } finally {
      // Complex navigation back to Overview (equivalent to your finally block)
      await this.back.scrollIntoViewIfNeeded();
      await this.adminSideBar.clickOnBackButton();
      await this.webFormCampaignMapping.scrollIntoViewIfNeeded();
      await expect(this.webFormCampaignMapping).toBeVisible({ timeout: 30000 });
      await this.adminSideBar.clickOnBackButton();
      await this.overview.scrollIntoViewIfNeeded();
      await expect(this.overview).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Reports functionality
   * Converted from your Java VerifyReports() method
   */
  async verifyReports() {
    try {
      console.log('📊 Verifying Reports functionality...');

      // Check if Reports is displayed, if not expand Others
      const isReportsVisible = await this.reports.isVisible();
      if (!isReportsVisible) {
        await this.verifyOthers();
      }

      await this.reports.scrollIntoViewIfNeeded();
      await expect(this.reports).toBeVisible({ timeout: 30000 });
      await expect(this.reports).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.reports.isVisible();
      if (isDisplayed) {
        await this.reports.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.reportsItems.scrollIntoViewIfNeeded();
        await expect(this.reportsItems).toBeVisible({ timeout: 30000 });

        const itemsDisplayed = await this.reportsItems.isVisible();
        if (!itemsDisplayed) {
          throw new Error("ReportsItems are not displayed.");
        }

        console.log('✅ ReportsItems are visible after clicking Reports.');
      } else {
        throw new Error("Reports button is not visible.");
      }

      console.log('✅ Reports verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyReports: ${error.message}`);
      throw new Error(`Exception occurred in VerifyReports: ${error.message}`);
    } finally {
      // Navigation to Reports Header (equivalent to your finally block)
      await this.reportsHeader.scrollIntoViewIfNeeded();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Outbound Summary functionality
   * Converted from your Java VerifyOutboundSummary() method
   */
  async verifyOutboundSummary() {
    try {
      console.log('📞 Verifying Outbound Summary functionality...');

      // Check if OutboundSummary is displayed, if not expand Outbound Calls
      const isOutboundSummaryVisible = await this.outboundSummary.isVisible();
      if (!isOutboundSummaryVisible) {
        await this.expendOutboundCalls.scrollIntoViewIfNeeded();
        await this.expendOutboundCalls.click();
      }

      await this.outboundSummary.scrollIntoViewIfNeeded();
      await expect(this.outboundSummary).toBeVisible({ timeout: 30000 });
      await expect(this.outboundSummary).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.outboundSummary.isVisible();
      if (isDisplayed) {
        await this.outboundSummary.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.outboundSummaryCriteria.scrollIntoViewIfNeeded();
        await expect(this.outboundSummaryCriteria).toBeVisible({ timeout: 30000 });

        const criteriaDisplayed = await this.outboundSummaryCriteria.isVisible();
        if (!criteriaDisplayed) {
          throw new Error("OutboundSummaryCriteria is not displayed.");
        }

        console.log('✅ OutboundSummaryCriteria is visible after clicking OutboundSummary.');
      } else {
        throw new Error("OutboundSummary button is not visible.");
      }

      console.log('✅ Outbound Summary verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyOutboundSummary: ${error.message}`);
      throw new Error(`Exception occurred in VerifyOutboundSummary: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Outbound Details functionality
   * Converted from your Java VerifyOutboundDetails() method
   */
  async verifyOutboundDetails() {
    try {
      console.log('📋 Verifying Outbound Details functionality...');

      // Check if OutboundDetails is displayed, if not expand Outbound Calls
      const isOutboundDetailsVisible = await this.outboundDetails.isVisible();
      if (!isOutboundDetailsVisible) {
        await this.expendOutboundCalls.scrollIntoViewIfNeeded();
        await this.expendOutboundCalls.click();
      }

      await this.outboundDetails.scrollIntoViewIfNeeded();
      await expect(this.outboundDetails).toBeVisible({ timeout: 30000 });
      await expect(this.outboundDetails).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.outboundDetails.isVisible();
      if (isDisplayed) {
        await this.outboundDetails.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.outboundDetailsCriteria.scrollIntoViewIfNeeded();
        await expect(this.outboundDetailsCriteria).toBeVisible({ timeout: 30000 });

        const criteriaDisplayed = await this.outboundDetailsCriteria.isVisible();
        if (!criteriaDisplayed) {
          throw new Error("OutboundDetailsCriteria is not displayed.");
        }

        console.log('✅ OutboundDetailsCriteria is visible after clicking OutboundDetails.');
      } else {
        throw new Error("OutboundDetails button is not visible.");
      }

      console.log('✅ Outbound Details verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyOutboundDetails: ${error.message}`);
      throw new Error(`Exception occurred in VerifyOutboundDetails: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Inbound Detail functionality
   * Converted from your Java VerifyInboundDetail() method
   */
  async verifyInboundDetail() {
    try {
      console.log('📞 Verifying Inbound Detail functionality...');

      // Check if InboundDetail is displayed, if not expand Inbound Calls
      const isInboundDetailVisible = await this.inboundDetail.isVisible();
      if (!isInboundDetailVisible) {
        await this.inboundCalls.scrollIntoViewIfNeeded();
        await this.inboundCalls.click();
      }

      await this.inboundDetail.scrollIntoViewIfNeeded();
      await expect(this.inboundDetail).toBeVisible({ timeout: 30000 });
      await expect(this.inboundDetail).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.inboundDetail.isVisible();
      if (isDisplayed) {
        await this.inboundDetail.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.inboundDetailCriteria.scrollIntoViewIfNeeded();
        await expect(this.inboundDetailCriteria).toBeVisible({ timeout: 30000 });

        const criteriaDisplayed = await this.inboundDetailCriteria.isVisible();
        if (!criteriaDisplayed) {
          throw new Error("InboundDetailCriteria is not displayed.");
        }

        console.log('✅ InboundDetailCriteria is visible after clicking InboundDetail.');
      } else {
        throw new Error("InboundDetail button is not visible.");
      }

      console.log('✅ Inbound Detail verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyInboundDetail: ${error.message}`);
      throw new Error(`Exception occurred in VerifyInboundDetail: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Lead Summary functionality
   * Converted from your Java VerifyLeadSummary() method
   */
  async verifyLeadSummary() {
    try {
      console.log('📊 Verifying Lead Summary functionality...');

      // Check if LeadSummary is displayed, if not expand Lead Report
      const isLeadSummaryVisible = await this.leadSummary.isVisible();
      if (!isLeadSummaryVisible) {
        await this.leadReport.scrollIntoViewIfNeeded();
        await this.leadReport.click();
      }

      await this.leadSummary.scrollIntoViewIfNeeded();
      await expect(this.leadSummary).toBeVisible({ timeout: 30000 });
      await expect(this.leadSummary).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.leadSummary.isVisible();
      if (isDisplayed) {
        await this.leadSummary.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.leadSummaryReport.scrollIntoViewIfNeeded();
        await expect(this.leadSummaryReport).toBeVisible({ timeout: 30000 });

        const reportDisplayed = await this.leadSummaryReport.isVisible();
        if (!reportDisplayed) {
          throw new Error("LeadSummaryReport is not displayed.");
        }

        console.log('✅ LeadSummaryReport is visible after clicking LeadSummary.');
      } else {
        throw new Error("LeadSummary button is not visible.");
      }

      console.log('✅ Lead Summary verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyLeadSummary: ${error.message}`);
      throw new Error(`Exception occurred in VerifyLeadSummary: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Lead Detail functionality
   * Converted from your Java VerifyLeadDetail() method
   */
  async verifyLeadDetail() {
    try {
      console.log('📋 Verifying Lead Detail functionality...');

      // Check if LeadDetail is displayed, if not expand Lead Report
      const isLeadDetailVisible = await this.leadDetail.isVisible();
      if (!isLeadDetailVisible) {
        await this.leadReport.scrollIntoViewIfNeeded();
        await this.leadReport.click();
      }

      await this.leadDetail.scrollIntoViewIfNeeded();
      await expect(this.leadDetail).toBeVisible({ timeout: 30000 });
      await expect(this.leadDetail).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.leadDetail.isVisible();
      if (isDisplayed) {
        await this.leadDetail.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.leadDetailReport.scrollIntoViewIfNeeded();
        await expect(this.leadDetailReport).toBeVisible({ timeout: 30000 });

        const reportDisplayed = await this.leadDetailReport.isVisible();
        if (!reportDisplayed) {
          throw new Error("LeadDetailReport is not displayed.");
        }

        console.log('✅ LeadDetailReport is visible after clicking LeadDetail.');
      } else {
        throw new Error("LeadDetail button is not visible.");
      }

      console.log('✅ Lead Detail verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyLeadDetail: ${error.message}`);
      throw new Error(`Exception occurred in VerifyLeadDetail: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Agent Summary functionality
   * Converted from your Java VerifyAgentSummary() method
   */
  async verifyAgentSummary() {
    try {
      console.log('👤 Verifying Agent Summary functionality...');

      // Check if AgentSummary is displayed, if not expand Agent
      const isAgentSummaryVisible = await this.agentSummary.isVisible();
      if (!isAgentSummaryVisible) {
        await this.agent.scrollIntoViewIfNeeded();
        await this.agent.click();
      }

      await this.agentSummary.scrollIntoViewIfNeeded();
      await expect(this.agentSummary).toBeVisible({ timeout: 30000 });
      await expect(this.agentSummary).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.agentSummary.isVisible();
      if (isDisplayed) {
        await this.agentSummary.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.agentSummaryReport.scrollIntoViewIfNeeded();
        await expect(this.agentSummaryReport).toBeVisible({ timeout: 30000 });

        const reportDisplayed = await this.agentSummaryReport.isVisible();
        if (!reportDisplayed) {
          throw new Error("AgentSummaryReport is not displayed.");
        }

        console.log('✅ AgentSummaryReport is visible after clicking AgentSummary.');
      } else {
        throw new Error("AgentSummary button is not visible.");
      }

      console.log('✅ Agent Summary verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyAgentSummary: ${error.message}`);
      throw new Error(`Exception occurred in VerifyAgentSummary: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Agent Detail functionality
   * Converted from your Java VerifyAgentDetail() method
   */
  async verifyAgentDetail() {
    try {
      console.log('📋 Verifying Agent Detail functionality...');

      // Check if AgentDetail is displayed, if not expand Agent
      const isAgentDetailVisible = await this.agentDetail.isVisible();
      if (!isAgentDetailVisible) {
        await this.agent.scrollIntoViewIfNeeded();
        await this.agent.click();
      }

      await this.agentDetail.scrollIntoViewIfNeeded();
      await expect(this.agentDetail).toBeVisible({ timeout: 30000 });
      await expect(this.agentDetail).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.agentDetail.isVisible();
      if (isDisplayed) {
        await this.agentDetail.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.agentDetailReport.scrollIntoViewIfNeeded();
        await expect(this.agentDetailReport).toBeVisible({ timeout: 30000 });

        const reportDisplayed = await this.agentDetailReport.isVisible();
        if (!reportDisplayed) {
          throw new Error("AgentDetailReport is not displayed.");
        }

        console.log('✅ AgentDetailReport is visible after clicking AgentDetail.');
      } else {
        throw new Error("AgentDetail button is not visible.");
      }

      console.log('✅ Agent Detail verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyAgentDetail: ${error.message}`);
      throw new Error(`Exception occurred in VerifyAgentDetail: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify System User functionality
   * Converted from your Java VerifySystemUser() method
   */
  async verifySystemUser() {
    try {
      console.log('🔧 Verifying System User functionality...');

      // Check if SystemUser is displayed, if not expand Agent
      const isSystemUserVisible = await this.systemUser.isVisible();
      if (!isSystemUserVisible) {
        await this.agent.scrollIntoViewIfNeeded();
        await this.agent.click();
      }

      await this.systemUser.scrollIntoViewIfNeeded();
      await expect(this.systemUser).toBeVisible({ timeout: 30000 });
      await expect(this.systemUser).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.systemUser.isVisible();
      if (isDisplayed) {
        await this.systemUser.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.systemUserReport.scrollIntoViewIfNeeded();
        await expect(this.systemUserReport).toBeVisible({ timeout: 30000 });

        const reportDisplayed = await this.systemUserReport.isVisible();
        if (!reportDisplayed) {
          throw new Error("SystemUserReport is not displayed.");
        }

        console.log('✅ SystemUserReport is visible after clicking SystemUser.');
      } else {
        throw new Error("SystemUser button is not visible.");
      }

      console.log('✅ System User verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifySystemUser: ${error.message}`);
      throw new Error(`Exception occurred in VerifySystemUser: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Agent Time By Campaign functionality
   * Converted from your Java VerifyAgentTimeByCampaign() method
   */
  async verifyAgentTimeByCampaign() {
    try {
      console.log('⏰ Verifying Agent Time By Campaign functionality...');

      // Check if AgentTimeByCampaign is displayed, if not expand Agent
      const isAgentTimeByCampaignVisible = await this.agentTimeByCampaign.isVisible();
      if (!isAgentTimeByCampaignVisible) {
        await this.agent.scrollIntoViewIfNeeded();
        await this.agent.click();
      }

      await this.agentTimeByCampaign.scrollIntoViewIfNeeded();
      await expect(this.agentTimeByCampaign).toBeVisible({ timeout: 30000 });
      await expect(this.agentTimeByCampaign).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.agentTimeByCampaign.isVisible();
      if (isDisplayed) {
        await this.agentTimeByCampaign.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.agentTimeByCampaignCriteria.scrollIntoViewIfNeeded();
        await expect(this.agentTimeByCampaignCriteria).toBeVisible({ timeout: 30000 });

        const criteriaDisplayed = await this.agentTimeByCampaignCriteria.isVisible();
        if (!criteriaDisplayed) {
          throw new Error("AgentTimeByCampaignCriteria is not displayed.");
        }

        console.log('✅ AgentTimeByCampaignCriteria is visible after clicking AgentTimeByCampaign.');
      } else {
        throw new Error("AgentTimeByCampaign button is not visible.");
      }

      console.log('✅ Agent Time By Campaign verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyAgentTimeByCampaign: ${error.message}`);
      throw new Error(`Exception occurred in VerifyAgentTimeByCampaign: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Agent Time By Agent functionality
   * Converted from your Java VerifyAgentTimeByAgent() method
   */
  async verifyAgentTimeByAgent() {
    try {
      console.log('👤 Verifying Agent Time By Agent functionality...');

      // Check if AgentTimeByAgent is displayed, if not expand Agent
      const isAgentTimeByAgentVisible = await this.agentTimeByAgent.isVisible();
      if (!isAgentTimeByAgentVisible) {
        await this.agent.scrollIntoViewIfNeeded();
        await this.agent.click();
      }

      await this.agentTimeByAgent.scrollIntoViewIfNeeded();
      await expect(this.agentTimeByAgent).toBeVisible({ timeout: 30000 });
      await expect(this.agentTimeByAgent).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.agentTimeByAgent.isVisible();
      if (isDisplayed) {
        await this.agentTimeByAgent.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.agentTimeByAgentCriteria.scrollIntoViewIfNeeded();
        await expect(this.agentTimeByAgentCriteria).toBeVisible({ timeout: 30000 });

        const criteriaDisplayed = await this.agentTimeByAgentCriteria.isVisible();
        if (!criteriaDisplayed) {
          throw new Error("AgentTimeByAgentCriteria is not displayed.");
        }

        console.log('✅ AgentTimeByAgentCriteria is visible after clicking AgentTimeByAgent.');
      } else {
        throw new Error("AgentTimeByAgent button is not visible.");
      }

      console.log('✅ Agent Time By Agent verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyAgentTimeByAgent: ${error.message}`);
      throw new Error(`Exception occurred in VerifyAgentTimeByAgent: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Status Report functionality
   * Converted from your Java VerifyStatusReport() method
   */
  async verifyStatusReport() {
    try {
      console.log('📊 Verifying Status Report functionality...');

      // Check if StatusReport is displayed, if not expand Contact
      const isStatusReportVisible = await this.statusReport.isVisible();
      if (!isStatusReportVisible) {
        await this.contact.scrollIntoViewIfNeeded();
        await this.contact.click();
      }

      await this.statusReport.scrollIntoViewIfNeeded();
      await expect(this.statusReport).toBeVisible({ timeout: 30000 });
      await expect(this.statusReport).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.statusReport.isVisible();
      if (isDisplayed) {
        await this.statusReport.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.statusReportCriteria.scrollIntoViewIfNeeded();
        await expect(this.statusReportCriteria).toBeVisible({ timeout: 30000 });

        const criteriaDisplayed = await this.statusReportCriteria.isVisible();
        if (!criteriaDisplayed) {
          throw new Error("StatusReportCriteria is not displayed.");
        }

        console.log('✅ StatusReportCriteria is visible after clicking StatusReport.');
      } else {
        throw new Error("StatusReport button is not visible.");
      }

      console.log('✅ Status Report verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyStatusReport: ${error.message}`);
      throw new Error(`Exception occurred in VerifyStatusReport: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Import List Report functionality
   * Converted from your Java VerifyImportListReport() method
   */
  async verifyImportListReport() {
    try {
      console.log('📋 Verifying Import List Report functionality...');

      // Check if ImportListReport is displayed, if not expand Contact
      const isImportListReportVisible = await this.importListReport.isVisible();
      if (!isImportListReportVisible) {
        await this.contact.scrollIntoViewIfNeeded();
        await this.contact.click();
      }

      await this.importListReport.scrollIntoViewIfNeeded();
      await expect(this.importListReport).toBeVisible({ timeout: 30000 });
      await expect(this.importListReport).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.importListReport.isVisible();
      if (isDisplayed) {
        await this.importListReport.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.importListReportPage.scrollIntoViewIfNeeded();
        await expect(this.importListReportPage).toBeVisible({ timeout: 30000 });

        const pageDisplayed = await this.importListReportPage.isVisible();
        if (!pageDisplayed) {
          throw new Error("ImportListReportPage is not displayed.");
        }

        console.log('✅ ImportListReportPage is visible after clicking ImportListReport.');
      } else {
        throw new Error("ImportListReport button is not visible.");
      }

      console.log('✅ Import List Report verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyImportListReport: ${error.message}`);
      throw new Error(`Exception occurred in VerifyImportListReport: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Contact Web Post Log functionality
   * Converted from your Java VerifyContactWebPostLog() method
   */
  async verifyContactWebPostLog() {
    try {
      console.log('🌐 Verifying Contact Web Post Log functionality...');

      // Check if ContactWebPostLog is displayed, if not expand Contact
      const isContactWebPostLogVisible = await this.contactWebPostLog.isVisible();
      if (!isContactWebPostLogVisible) {
        await this.contact.scrollIntoViewIfNeeded();
        await this.contact.click();
      }

      await this.contactWebPostLog.scrollIntoViewIfNeeded();
      await expect(this.contactWebPostLog).toBeVisible({ timeout: 30000 });
      await expect(this.contactWebPostLog).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await this.contactWebPostLog.isVisible();
      if (isDisplayed) {
        await this.contactWebPostLog.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.contactWebPostLogCriteria.scrollIntoViewIfNeeded();
        await expect(this.contactWebPostLogCriteria).toBeVisible({ timeout: 30000 });

        const criteriaDisplayed = await this.contactWebPostLogCriteria.isVisible();
        if (!criteriaDisplayed) {
          throw new Error("ContactWebPostLogCriteria is not displayed.");
        }

        console.log('✅ ContactWebPostLogCriteria is visible after clicking ContactWebPostLog.');
      } else {
        throw new Error("ContactWebPostLog button is not visible.");
      }

      console.log('✅ Contact Web Post Log verification completed successfully');
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyContactWebPostLog: ${error.message}`);
      throw new Error(`Exception occurred in VerifyContactWebPostLog: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Verify Custom Report functionality
   * Converted from your Java VerifyCustomReport() method
   * @param {string} reportName - Name of the custom report to verify
   */
  async verifyCustomReport(reportName) {
    try {
      console.log(`🔧 Verifying Custom Report functionality: ${reportName}...`);

      // Create dynamic locator for custom report name
      const customReportName = this.page.locator(`//div[contains(text(),'${reportName}')]`);

      // Check if CustomReportName is displayed, if not expand Custom
      const isCustomReportNameVisible = await customReportName.isVisible();
      if (!isCustomReportNameVisible) {
        await this.custom.scrollIntoViewIfNeeded();
        await this.custom.click();
      }

      await customReportName.scrollIntoViewIfNeeded();
      await expect(customReportName).toBeVisible({ timeout: 30000 });
      await expect(customReportName).toBeEnabled({ timeout: 30000 });

      const isDisplayed = await customReportName.isVisible();
      if (isDisplayed) {
        await customReportName.click();
        await this.errorUtil.captureErrorIfPresent();

        await this.customReportsPages.scrollIntoViewIfNeeded();
        await expect(this.customReportsPages).toBeVisible({ timeout: 30000 });

        const pagesDisplayed = await this.customReportsPages.isVisible();
        if (!pagesDisplayed) {
          throw new Error("CustomReportsPages is not displayed.");
        }

        console.log(`✅ CustomReportsPages is visible after clicking ${reportName}.`);
      } else {
        throw new Error(`${reportName}: button is not visible.`);
      }

      console.log(`✅ Custom Report verification completed successfully: ${reportName}`);
    } catch (error) {
      console.error(`❌ Exception occurred in VerifyCustomReport for ${reportName}: ${error.message}`);
      throw new Error(`Exception occurred in VerifyCustomReport for ${reportName}: ${error.message}`);
    } finally {
      // Navigation back to Reports Header (equivalent to your finally block)
      await this.adminSideBar.clickOnBackButton();
      await expect(this.reportsHeader).toBeVisible({ timeout: 30000 });
    }
  }

  /**
   * Get all available custom reports
   * Enhanced method to get list of custom reports
   * @returns {Array} Array of custom report names
   */
  async getAvailableCustomReports() {
    try {
      console.log('📋 Getting available custom reports...');

      // Expand Custom section if not already expanded
      const isCustomExpanded = await this.page.locator("//div[contains(@class,'custom-reports-expanded')]").isVisible();
      if (!isCustomExpanded) {
        await this.custom.scrollIntoViewIfNeeded();
        await this.custom.click();
        await this.page.waitForTimeout(2000); // Wait for expansion
      }

      // Get all custom report elements
      const customReportElements = await this.page.locator("//label[normalize-space()='Custom']/following-sibling::div//div[contains(@class,'report-item')]").all();

      const customReports = [];
      for (let i = 0; i < customReportElements.length; i++) {
        const element = customReportElements[i];
        const text = await element.textContent();
        if (text && text.trim()) {
          customReports.push(text.trim());
        }
      }

      console.log(`✅ Found ${customReports.length} custom reports:`, customReports);
      return customReports;
    } catch (error) {
      console.error(`❌ Error getting custom reports: ${error.message}`);
      return [];
    }
  }

  /**
   * Verify multiple custom reports
   * Enhanced method to test multiple custom reports
   * @param {Array} reportNames - Array of report names to verify
   */
  async verifyMultipleCustomReports(reportNames) {
    try {
      console.log(`🔧 Verifying multiple custom reports: ${reportNames.join(', ')}...`);

      for (const reportName of reportNames) {
        console.log(`📊 Testing custom report: ${reportName}`);
        await this.verifyCustomReport(reportName);
        console.log(`✅ Completed testing: ${reportName}`);
      }

      console.log('✅ All custom reports verified successfully');
    } catch (error) {
      console.error(`❌ Error verifying multiple custom reports: ${error.message}`);
      throw error;
    }
  }

  // ==========================================
  // HIGH-LEVEL BUSINESS METHODS (POM Best Practices)
  // ==========================================

  /**
   * Verify Campaigns Tab functionality (High-level POM method)
   * Handles complete verification workflow - calls existing methods
   */
  async verifyCampaignsTab() {
    try {
      console.log('📢 Verifying Campaigns Tab functionality...');

      // Use existing campaign verification methods
      await this.verifyActiveCampaign();
      await this.verifyArchivedCampAtActiveCampaigns();
      await this.verifyArchivedCampaign();

      console.log('✅ Campaigns Tab verification completed successfully');

    } catch (error) {
      console.error(`❌ Campaigns Tab verification failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Verify Contacts Tab functionality (High-level POM method)
   * Handles complete verification workflow - calls existing methods
   */
  async verifyContactsTab() {
    try {
      console.log('👥 Verifying Contacts Tab functionality...');

      // Use existing contact verification methods
      await this.verifyAllContact();
      await this.verifyAddContact();

      console.log('✅ Contacts Tab verification completed successfully');

    } catch (error) {
      console.error(`❌ Contacts Tab verification failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Verify Leads Tab functionality (High-level POM method)
   * Handles complete verification workflow - calls existing methods
   */
  async verifyLeadsTab() {
    try {
      console.log('🎯 Verifying Leads Tab functionality...');

      // Use existing lead verification methods
      await this.verifyLeadsAndTickets();
      await this.verifyLeadFollowUp();
      await this.verifyManageAllLeads();

      console.log('✅ Leads Tab verification completed successfully');

    } catch (error) {
      console.error(`❌ Leads Tab verification failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Verify Tickets Tab functionality (High-level POM method)
   * Handles complete verification workflow - calls existing methods
   */
  async verifyTicketsTab() {
    try {
      console.log('🎫 Verifying Tickets Tab functionality...');

      // Use existing ticket verification methods
      await this.verifyTicketFollowUp();
      await this.verifyManageAllTickets();

      console.log('✅ Tickets Tab verification completed successfully');

    } catch (error) {
      console.error(`❌ Tickets Tab verification failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Verify Reports Tab functionality (High-level POM method)
   * Handles complete verification workflow - calls existing methods
   */
  async verifyReportsTab() {
    try {
      console.log('📊 Verifying Reports Tab functionality...');

      // Use existing reports verification methods
      await this.verifyOutboundSummary();
      await this.verifyLeadSummary();
      await this.verifyAgentSummary();

      console.log('✅ Reports Tab verification completed successfully');

    } catch (error) {
      console.error(`❌ Reports Tab verification failed: ${error.message}`);
      throw error;
    }
  }
}

module.exports = HomePage_POM;
