const { expect } = require('@playwright/test');
const BasePage = require('./BasePage');
const ExcelUtils = require('../utils/ExcelUtils');

/**
 * DocumentsPage - Page Object Model for Document Management functionality
 * Handles ALL document-related operations including navigation, creation, and verification
 */
class DocumentsPage extends BasePage {
  constructor(page) {
    super(page);
    this.page = page;

    // Navigation elements (use more specific selector to avoid strict mode violation)
    this.systemSetupButton = page.locator("//span[normalize-space()='System Setup'][contains(@class,'page')]").first();
    this.documentsTab = page.locator("//label[normalize-space()='Documents'] | //div[contains(text(),'Documents')] | //span[contains(text(),'Documents')]");
    this.backButton = page.locator("//button[contains(@class,'back')] | //i[contains(@class,'fa-arrow-left')] | //span[contains(text(),'Back')]");

    // Document management elements (using SystemSetupPage selectors for consistency)
    this.addNewDocument = page.locator("//label[normalize-space()='Add New Document'] | //button[contains(text(),'Add New Document')] | //a[contains(text(),'Add New Document')]");
    this.category = page.locator("//select[@id='selectCategoryId'] | //select[@id='category'] | //select[@name='category']");
    this.documentName = page.locator("//input[@id='getName'] | //input[@id='documentName'] | //input[@name='name']");
    this.uploadDocument = page.locator("//input[@id='uploadedFile'] | //input[@type='file']");
    this.description = page.locator("//textarea[@id='getDescription'] | //textarea[@id='description'] | //textarea[@name='description']");
    this.saveDocument = page.locator("//button[@id='btnDocumentCreate'] | //button[contains(text(),'Save')] | //button[contains(text(),'Upload')]");
    this.documentsList = page.locator("//table[@id='documentsTable'] | //div[@class='documents-list'] | //tbody//td");
    this.deleteButton = page.locator("//button[contains(@class,'btn-danger')] | //i[contains(@class,'fa-trash')]");
    this.confirmDelete = page.locator("//button[contains(text(),'Yes')] | //button[contains(text(),'Confirm')]");
  }

  /**
   * Complete Document Setup Workflow - High-level POM method
   * Handles the entire document setup process from navigation to creation
   */
  async performCompleteDocumentSetup() {
    try {
      console.log('� Starting complete document setup workflow...');

      // Step 1: Navigate to System Setup
      await this.navigateToSystemSetup();

      // Step 2: Verify and click Documents
      await this.verifyAndClickDocuments();

      // Step 3: Load document data and create documents
      await this.createDocumentsFromExcel();

      console.log('✅ Complete document setup workflow completed successfully');
      return true;
    } catch (error) {
      console.error('❌ Complete document setup workflow failed:', error.message);
      throw error;
    }
  }

  /**
   * Navigate to System Setup section
   */
  async navigateToSystemSetup() {
    try {
      console.log('🔧 Navigating to System Setup...');
      await this.scrollIntoView(this.systemSetupButton);
      await this.safeClick(this.systemSetupButton);
      await this.page.waitForTimeout(2000);
      console.log('✅ Successfully navigated to System Setup');
    } catch (error) {
      console.error('❌ Error navigating to System Setup:', error.message);
      throw error;
    }
  }

  /**
   * Verify Documents functionality and navigate to Documents section
   */
  async verifyAndClickDocuments() {
    try {
      console.log('📄 Verifying and clicking Documents...');

      // Wait a bit for page to load after System Setup click
      await this.page.waitForTimeout(3000);

      // Check if Documents elements are visible
      const isDocumentsVisible = await this.documentsTab.isVisible();

      if (isDocumentsVisible) {
        await this.scrollIntoView(this.documentsTab);
        await expect(this.documentsTab).toBeVisible({ timeout: 10000 });
        await expect(this.documentsTab).toBeEnabled({ timeout: 5000 });
        await this.documentsTab.click();
        await this.page.waitForTimeout(3000);

        // Verify Documents page loaded by checking for any document-related elements
        const documentPageIndicators = [
          this.addNewDocument,
          this.page.locator("//h1[contains(text(),'Document')] | //h2[contains(text(),'Document')] | //div[contains(text(),'Document')]").first()
        ];

        let pageLoaded = false;
        for (const indicator of documentPageIndicators) {
          try {
            await expect(indicator).toBeVisible({ timeout: 5000 });
            console.log('✅ Documents page loaded successfully');
            pageLoaded = true;
            break;
          } catch (error) {
            // Continue to next indicator
            continue;
          }
        }

        if (!pageLoaded) {
          console.log('⚠️ Documents page may not have loaded properly, but continuing...');
        }

        return true;
      } else {
        console.log('⚠️ Documents button not visible - may not be available in this environment');
        return false;
      }
    } catch (error) {
      console.error('❌ Documents verification failed:', error.message);
      console.log('⚠️ Continuing with document creation attempt...');
      return false;
    }
  }

  // Click Add New Document button
  async clickAddNewDocument() {
    try {
      console.log('➕ Clicking Add New Document...');
      await this.safeClick(this.addNewDocument);
      await this.waitForPageLoad();
      console.log('✅ Add New Document form opened');
    } catch (error) {
      console.error('❌ Error clicking Add New Document:', error.message);
      throw error;
    }
  }

  // Upload a new document
  async uploadDocument(documentData) {
    try {
      console.log(`📤 Uploading document: ${documentData.name}`);

      // Fill document details
      if (documentData.category) {
        await this.safeSelect(this.category, documentData.category);
      }

      if (documentData.name) {
        await this.safeType(this.documentName, documentData.name);
      }

      if (documentData.description) {
        await this.safeType(this.description, documentData.description);
      }

      // Upload file if provided
      if (documentData.filePath) {
        await this.uploadDocument.setInputFiles(documentData.filePath);
        console.log(`📁 File selected: ${documentData.filePath}`);
      }

      // Click save button
      await this.safeClick(this.saveDocument);
      await this.waitForPageLoad();

      console.log('✅ Document uploaded successfully');
      return true;
    } catch (error) {
      console.error('❌ Error uploading document:', error.message);
      throw error;
    }
  }

  // Verify document exists in the list
  async verifyDocumentExists(documentName) {
    try {
      console.log(`🔍 Verifying document exists: ${documentName}`);
      
      const documentRow = this.page.locator(`//td[contains(text(),'${documentName}')]`);
      const exists = await documentRow.isVisible();
      
      if (exists) {
        console.log(`✅ Document found: ${documentName}`);
        return true;
      } else {
        console.log(`❌ Document not found: ${documentName}`);
        return false;
      }
    } catch (error) {
      console.error('❌ Error verifying document:', error.message);
      return false;
    }
  }

  // Delete a document
  async deleteDocument(documentName) {
    try {
      console.log(`🗑️ Deleting document: ${documentName}`);
      
      // Find the document row and delete button
      const documentRow = this.page.locator(`//tr[td[contains(text(),'${documentName}')]]`);
      const deleteBtn = documentRow.locator(this.deleteButton);
      
      await this.safeClick(deleteBtn);
      
      // Confirm deletion if confirmation dialog appears
      const confirmBtn = this.confirmDelete;
      const isConfirmVisible = await confirmBtn.isVisible();
      
      if (isConfirmVisible) {
        await this.safeClick(confirmBtn);
      }
      
      await this.waitForPageLoad();
      console.log(`✅ Document deleted: ${documentName}`);
      return true;
    } catch (error) {
      console.error('❌ Error deleting document:', error.message);
      return false;
    }
  }

  // Get list of all documents
  async getDocumentsList() {
    try {
      console.log('📋 Getting documents list...');
      
      const documentRows = this.page.locator("//table[@id='documentsTable']//tr[td]");
      const count = await documentRows.count();
      const documents = [];
      
      for (let i = 0; i < count; i++) {
        const row = documentRows.nth(i);
        const name = await row.locator('td').first().textContent();
        documents.push(name?.trim());
      }
      
      console.log(`📊 Found ${documents.length} documents`);
      return documents;
    } catch (error) {
      console.error('❌ Error getting documents list:', error.message);
      return [];
    }
  }

  // Verify documents page is loaded
  async verifyDocumentsPageLoaded() {
    try {
      console.log('🔍 Verifying Documents page is loaded...');
      
      const isAddButtonVisible = await this.addNewDocument.isVisible();
      const isListVisible = await this.documentsList.isVisible();
      
      if (isAddButtonVisible || isListVisible) {
        console.log('✅ Documents page loaded successfully');
        return true;
      } else {
        console.log('❌ Documents page not loaded properly');
        return false;
      }
    } catch (error) {
      console.error('❌ Error verifying Documents page:', error.message);
      return false;
    }
  }

  /**
   * Load document data from Excel file or return sample data
   * @returns {Array<Object>} Array of document data objects
   */
  loadDocumentDataFromExcel() {
    try {
      console.log('📊 Loading document data from Excel...');

      // Try to read from Excel file, fallback to sample data
      try {
        const excelFilePath = 'tests/data/Field Test Data.xlsx';
        const sheetName = 'Document';
        const dataRows = ExcelUtils.readExcelData(excelFilePath, sheetName);

        if (!dataRows || dataRows.length === 0) {
          throw new Error('No data found in Excel file');
        }

        // Map Excel data to document objects (assuming columns: category, name, filePath, description)
        const documents = [];
        for (let i = 0; i < dataRows.length; i++) {
          const row = dataRows[i];
          if (row && row.length >= 4) {
            const doc = {
              category: row[0] || 'General',
              name: row[1] || `Document ${i + 1}`,
              filePath: row[2] || '',
              description: row[3] || 'Document from Excel'
            };
            documents.push(doc);
          }
        }
        console.log(`✅ Loaded ${documents.length} documents from Excel`);
        return documents;
      } catch (excelError) {
        console.log('⚠️ Excel file not found, using sample data');
        // Return sample document data
        const sampleData = [
          {
            name: 'Test Document 1',
            category: 'General',
            description: 'Test document for automation',
            filePath: 'tests/data/sample.pdf'
          },
          {
            name: 'Test Document 2',
            category: 'Training',
            description: 'Training document for automation',
            filePath: 'tests/data/sample.docx'
          }
        ];
        console.log(`✅ Using ${sampleData.length} sample documents`);
        return sampleData;
      }
    } catch (error) {
      console.error('❌ Error loading document data:', error.message);
      return [];
    }
  }

  /**
   * Create documents using data loaded from Excel
   */
  async createDocumentsFromExcel() {
    const documentData = this.loadDocumentDataFromExcel();
    for (const doc of documentData) {
      const exists = await this.verifyDocumentExists(doc.name || doc.Name);
      if (!exists) {
        await this.clickAddNewDocument();
        await this.uploadDocument(doc);
      } else {
        console.log(`ℹ️ Document already exists: ${doc.name || doc.Name}`);
      }
    }
    console.log('✅ Document creation from Excel finished');
  }
}

module.exports = DocumentsPage;
