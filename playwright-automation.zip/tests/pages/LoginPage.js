const ExcelUtils = require('../utils/ExcelUtils.js');

class LoginPage {
  /**
   * @param {import('@playwright/test').Page} page
   */
  constructor(page) {
    this.page = page;
    this.usernameInput = page.locator('#user_login');
    this.passwordInput = page.locator('#user_password');
    this.loginButton = page.locator('#loginButton');
  }

  async goto() {
    await this.page.goto('https://qc2.devaavaz.biz', {
      timeout: 180000,
      waitUntil: 'domcontentloaded'
    });
  }

  async login(email, password) {
    await this.usernameInput.fill(email);
    await this.passwordInput.fill(password);
    await this.loginButton.click();
  }

  /**
   * Perform complete login process (High-level POM method)
   * Handles everything: navigation, data loading, login execution
   */
  async performLogin() {
    try {
      console.log('🔐 Starting complete login process...');

      // Step 1: Navigate to login page
      await this.navigateToLoginPage();

      // Step 2: Load login credentials from Excel
      const loginData = await this.loadLoginCredentials();

      // Step 3: Perform login
      await this.executeLogin(loginData);

      console.log('✅ Complete login process finished');

    } catch (error) {
      console.error(`❌ Error in performLogin: ${error.message}`);
      throw error;
    }
  }

  /**
   * Navigate to login page
   */
  async navigateToLoginPage() {
    console.log('🌐 Navigating to QC2 environment...');

    // Set browser window
    await this.page.setViewportSize({ width: 1266, height: 618 });
    console.log('✅ Browser set to optimized window size');

    // Navigate to URL
    await this.page.goto('https://qc2.devaavaz.biz/');
    console.log('✅ Successfully navigated to QC2');
  }

  /**
   * Load login credentials from Excel
   */
  async loadLoginCredentials() {
    try {
      console.log('📊 Loading login credentials from Excel...');

      const loginData = LoginPage.getLoginTestDataAsObjects();

      if (!loginData || loginData.length === 0) {
        throw new Error('No login data found in Excel');
      }

      console.log('✅ Login credentials loaded successfully');
      return loginData[0]; // Return first login record

    } catch (error) {
      console.error(`❌ Error loading login credentials: ${error.message}`);
      throw error;
    }
  }

  /**
   * Execute login with provided credentials
   */
  async executeLogin(loginData) {
    try {
      console.log(`🔐 Performing login for user: ${loginData.username || loginData.email || 'Unknown'}`);

      // Enter username
      await this.usernameInput.fill(loginData.username || loginData.email);
      console.log('✅ Username entered successfully');

      // Enter password
      await this.passwordInput.fill(loginData.password);
      console.log('✅ Password entered successfully');

      // Click login
      await this.loginButton.click();
      console.log('✅ Login button clicked');

      // Verify login success
      await this.verifyLoginSuccess();

      console.log('✅ Login executed successfully');

    } catch (error) {
      console.error(`❌ Error executing login: ${error.message}`);
      throw error;
    }
  }

  /**
   * Verify login was successful
   */
  async verifyLoginSuccess() {
    try {
      // Wait for page to load after login
      await this.page.waitForTimeout(3000);

      // Check for obvious error messages first
      const errorSelectors = [
        "//div[contains(@class,'alert-danger')]",
        "//div[contains(@class,'error')]",
        "//span[contains(@class,'error')]",
        "//div[contains(text(),'Invalid')]",
        "//div[contains(text(),'Error')]"
      ];

      let hasError = false;
      let errorText = '';

      for (const selector of errorSelectors) {
        try {
          const errorElements = await this.page.locator(selector).all();
          if (errorElements.length > 0) {
            const text = await errorElements[0].textContent();
            if (text && text.trim().length > 0) {
              hasError = true;
              errorText = text.trim();
              break;
            }
          }
        } catch (e) {
          // Continue checking other selectors
        }
      }

      if (hasError) {
        throw new Error(`Login failed: ${errorText}`);
      }

      // If no errors found, assume login was successful
      console.log('✅ Login verification successful - no error messages found');

    } catch (error) {
      if (error.message.includes('Login failed:')) {
        throw error; // Re-throw login failures
      }

      // For other errors, just log and continue (assume login worked)
      console.log(`⚠️ Login verification had issues but continuing: ${error.message}`);
    }
  }

  static getLoginTestData() {
    try {
      console.log('📊 Reading login test data from Excel...');

      // Read data from Excel file (equivalent to your Java UserCreationUpdationData.class)
      const loginData = ExcelUtils.readExcelData('tests/data/Login Creds Data.xlsx', 'UserLoginData');

      if (loginData.length === 0) {
        throw new Error('No login data found in Excel file. Please add test data to tests/data/Login Creds Data.xlsx');
      }

      console.log(`✅ Successfully loaded ${loginData.length} login test records from Excel`);
      return loginData;
    } catch (error) {
      console.error(`❌ Error reading login test data: ${error.message}`);
      console.error('💡 Make sure to:');
      console.error('   1. Run "npm run setup-data" to create Excel templates');
      console.error('   2. Add your test data to tests/data/Login Creds Data.xlsx');
      throw error;
    }
  }

  static getLoginTestDataAsObjects() {
    try {
      console.log('📊 Reading login test data as objects from Excel...');

      // Read data as objects from Excel file
      const loginData = ExcelUtils.readExcelDataAsObjects('tests/data/Login Creds Data.xlsx', 'UserLoginData');

      if (loginData.length === 0) {
        throw new Error('No login data found in Excel file. Please add test data to tests/data/Login Creds Data.xlsx');
      }

      console.log(`✅ Successfully loaded ${loginData.length} login test objects from Excel`);
      return loginData;
    } catch (error) {
      console.error(`❌ Error reading login test data as objects: ${error.message}`);
      console.error('💡 Make sure to:');
      console.error('   1. Run "npm run setup-data" to create Excel templates');
      console.error('   2. Add your test data to tests/data/Login Creds Data.xlsx');
      throw error;
    }
  }


  static getLoginDataByRole(role) {
    try {
      const loginData = this.getLoginTestDataAsObjects();
      const userData = loginData.find(user => user.role === role);

      if (userData) {
        console.log(`✅ Found login data for role: ${role}`);
        return userData;
      } else {
        console.log(`⚠️ No login data found for role: ${role}`);
        return null;
      }
    } catch (error) {
      console.error(`❌ Error getting login data by role: ${error.message}`);
      return null;
    }
  }


  async loginByRole(role) {
    try {
      const userData = LoginPage.getLoginDataByRole(role);

      if (userData) {
        console.log(`🔐 Logging in as ${role}: ${userData.email}`);
        await this.login(userData.email, userData.password);
      } else {
        throw new Error(`No login data found for role: ${role}`);
      }
    } catch (error) {
      console.error(`❌ Error logging in by role: ${error.message}`);
      throw error;
    }
  }

  /**
   * Validate Excel login data file
   * @returns {boolean} True if Excel file is valid
   */
  static validateLoginDataFile() {
    try {
      console.log('🔍 Validating login data Excel file...');

      const isValid = ExcelUtils.validateExcelFile('tests/data/Login Creds Data.xlsx', 'UserLoginData');

      if (isValid) {
        console.log('✅ Login data Excel file is valid');

        // Also check file info
        const fileInfo = ExcelUtils.getExcelFileInfo('tests/data/Login Creds Data.xlsx');
        console.log(`📋 File info: ${fileInfo.fileName}, Sheets: ${fileInfo.sheetNames.join(', ')}`);
      }

      return isValid;
    } catch (error) {
      console.error(`❌ Error validating login data file: ${error.message}`);
      return false;
    }
  }
}

module.exports = { LoginPage };
