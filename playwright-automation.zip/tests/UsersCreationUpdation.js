const { chromium } = require('playwright');
const AdminSideBar = require('./utils/AdminSideBar.js');
const UserCreationPage = require('./pages/UserCreationPage.js');
const { LoginPage } = require('./pages/LoginPage.js');

/**
 * UsersCreationUpdation Test Class - Only uses UserCreationPage POM
 * Direct equivalent to your Java TestNG class
 *
 * Structure:
 * - @BeforeClass -> setup()
 * - @Test(priority = 1) -> Click_On_SystemSetup()
 * - @Test(priority = 2, dependsOnMethods = "Click_On_SystemSetup") -> Create_Users()
 */
class UsersCreationUpdation {
  constructor() {
    this.driver = null; // equivalent to your static WebDriver driver
    this.Bar = null;    // equivalent to your AdminSideBar Bar
    this.uc = null;     // equivalent to your UserCreation uc
    this.loginPage = null;
  }

  /**
   * @BeforeClass equivalent
   * Setup method - Initialize all page objects
   */
  async setup() {
    console.log('🔧 @BeforeClass: Setting up test class...');
    
    // Initialize browser (equivalent to DriverUtils.getDriver())
    const browser = await chromium.launch({ 
      headless: false,
      args: ['--start-maximized']
    });
    
    const context = await browser.newContext({
      viewport: null
    });
    
    this.driver = await context.newPage();
    
    // Initialize page objects (equivalent to your @BeforeClass)
    this.Bar = new AdminSideBar(this.driver);           // AdminSideBar Bar
    this.uc = new UserCreationPage(this.driver);        // UserCreation uc
    this.loginPage = new LoginPage(this.driver);
    
    console.log('✅ @BeforeClass completed: All page objects initialized');
    return browser; // Return for cleanup
  }

  /**
   * Login prerequisite (run before tests)
   */
  async performLogin() {
    console.log('🔐 Performing login...');
    await this.loginPage.performLogin();
    console.log('✅ Login completed');
  }

  /**
   * @Test(priority = 1)
   * Click_On_SystemSetup() - Exact match to your Java method
   */
  async Click_On_SystemSetup() {
    console.log('🖱️ @Test(priority = 1): Click_On_SystemSetup()');
    
    await this.Bar.clickSystemSetup();
    
    console.log('✅ Test 1 completed: System Setup clicked');
  }

  /**
   * @Test(priority = 2, dependsOnMethods = "Click_On_SystemSetup")
   * Create_Users() - Exact match to your Java method
   * Uses UserCreationPage POM only
   */
  async Create_Users() {
    console.log('👤 @Test(priority = 2, dependsOnMethods = "Click_On_SystemSetup"): Create_Users()');

    // Navigate to Users and process user creation from Excel
    await this.uc.clickUsers();

    // Load test data from Excel (matching your Java DataProvider pattern)
    const userData = await this.loadUserDataFromExcel();

    // Process each user using existingUser method (matches your Java logic)
    for (const user of userData) {
      await this.uc.existingUser(
        user.firstname,
        user.lastname,
        user.role,
        user.email,
        user.password,
        user.timezone,
        user.extension,
        user.phonenumber,
        user.userskill
      );
    }

    console.log('✅ Test 2 completed: User creation finished');
  }

  // Load user data from Excel - matches your Java DataProvider pattern
  async loadUserDataFromExcel() {
    try {
      console.log('📊 Loading user data from Excel...');

      const ExcelUtils = require('./utils/ExcelUtils.js');
      const rawData = ExcelUtils.readExcelData('tests/data/WorkFlow Test Data.xlsx', 'UserCreationData');

      // Convert to format expected by UserCreation methods
      const userData = rawData.map((row, index) => ({
        firstname: row[0] || `User${index + 1}`,
        lastname: row[1] || 'Test',
        role: row[2] || 'admin',
        email: row[3] || `user${index + 1}@test.com`,
        password: row[4] || 'password123',
        timezone: row[5] || 'Asia/Kolkata',
        extension: row[6] || `100${index + 1}`,
        phonenumber: row[7] || `999000000${index + 1}`,
        userskill: row[8] || 'General'
      }));

      console.log(`✅ Loaded ${userData.length} users from Excel`);
      return userData;
    } catch (error) {
      console.error('❌ Error loading user data from Excel:', error.message);
      throw error;
    }
  }

  /**
   * Run all tests in TestNG order
   */
  async runAllTests() {
    let browser;
    
    try {
      console.log('🚀 Starting UsersCreationUpdation test execution...');
      console.log('='.repeat(60));

      // @BeforeClass
      browser = await this.setup();
      
      // Login prerequisite
      await this.performLogin();
      
      console.log('\n=== TestNG Test Execution ===');
      
      // @Test(priority = 1)
      await this.Click_On_SystemSetup();

      // @Test(priority = 2, dependsOnMethods = "Click_On_SystemSetup")
      await this.Create_Users();
      
      console.log('\n🎉 All tests completed successfully!');
      
    } catch (error) {
      console.error(`❌ Test execution failed: ${error.message}`);
      throw error;
    } finally {
      if (browser) {
        console.log('🔒 Closing browser...');
        await browser.close();
        console.log('🔒 Browser closed');
      }
    }
  }
}

// Export for direct execution
module.exports = UsersCreationUpdation;

// Direct execution support
if (require.main === module) {
  const test = new UsersCreationUpdation();
  test.runAllTests().catch(console.error);
}
